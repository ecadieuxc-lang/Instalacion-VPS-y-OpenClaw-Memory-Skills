#!/usr/bin/env bash
set -Eeuo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
EVID="$PACK_DIR/evidence/02-system-base"
STATE="$PACK_DIR/state/current.env"
HELP="$PACK_DIR/evidence/chatgpt-help-context.md"
CONFIG="$PACK_DIR/state/install-config.env"

mkdir -p "$EVID" "$PACK_DIR/state"

status="PASS"

{
  echo "# Tramo 02 — system-base"
  echo
  echo "mode=LIVE_MUTATING_SYSTEM_BASE"
  echo "started_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
} > "$EVID/system-base-report.md"

if [[ "${AVB_LIVE:-0}" != "1" ]]; then
  echo "live_gate=BLOCKED_AVB_LIVE_REQUIRED" >> "$EVID/system-base-report.md"
  echo "final_status=BLOCKED_LIVE_GATE" >> "$EVID/system-base-report.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=02" \
  "AVB_CURRENT_STATUS=BLOCKED_LIVE_GATE" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

if [[ "$(id -u)" -ne 0 ]]; then
  echo "root_required=FAIL" >> "$EVID/system-base-report.md"
  echo "final_status=BLOCKED_ROOT_REQUIRED" >> "$EVID/system-base-report.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=02" \
  "AVB_CURRENT_STATUS=BLOCKED_ROOT_REQUIRED" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

if [[ -f "$CONFIG" ]]; then
  # shellcheck disable=SC1090
  source "$CONFIG"
fi

if [[ -z "${RUNTIME_USER:-}" ]]; then
  read -r -p "Usuario runtime para el asistente [assistant]: " RUNTIME_USER
  RUNTIME_USER="${RUNTIME_USER:-assistant}"
fi

if ! [[ "$RUNTIME_USER" =~ ^[a-z_][a-z0-9_-]{2,30}$ ]]; then
  echo "runtime_user_valid=FAIL" >> "$EVID/system-base-report.md"
  echo "final_status=BLOCKED_INVALID_RUNTIME_USER" >> "$EVID/system-base-report.md"
  exit 1
fi

case "$RUNTIME_USER" in
  root|admin|system|openclaw|www-data|nobody)
    echo "runtime_user_reserved=FAIL" >> "$EVID/system-base-report.md"
    echo "final_status=BLOCKED_RESERVED_RUNTIME_USER" >> "$EVID/system-base-report.md"
    exit 1
    ;;
esac

umask 077
printf 'RUNTIME_USER=%q\n' "$RUNTIME_USER" > "$CONFIG"
chmod 600 "$CONFIG"

echo "runtime_user=$RUNTIME_USER" >> "$EVID/system-base-report.md"
echo "runtime_user_valid=PASS" >> "$EVID/system-base-report.md"

export DEBIAN_FRONTEND=noninteractive

apt-get update >> "$EVID/apt.log" 2>&1
apt-get install -y \
  ca-certificates \
  curl \
  git \
  jq \
  unzip \
  tar \
  gzip \
  nano \
  vim \
  ufw \
  cron \
  lsb-release \
  gnupg \
  >> "$EVID/apt.log" 2>&1

echo "base_packages_installed=PASS" >> "$EVID/system-base-report.md"

if id "$RUNTIME_USER" >/dev/null 2>&1; then
  echo "runtime_user_created=ALREADY_EXISTS" >> "$EVID/system-base-report.md"
else
  adduser --disabled-password --gecos "" "$RUNTIME_USER" >> "$EVID/useradd.log" 2>&1
  echo "runtime_user_created=PASS" >> "$EVID/system-base-report.md"
fi

install -d -o "$RUNTIME_USER" -g "$RUNTIME_USER" -m 700 "/home/$RUNTIME_USER/assistant"
install -d -o "$RUNTIME_USER" -g "$RUNTIME_USER" -m 700 "/home/$RUNTIME_USER/assistant/evidence"
install -d -o "$RUNTIME_USER" -g "$RUNTIME_USER" -m 700 "/home/$RUNTIME_USER/assistant/docs"
install -d -o "$RUNTIME_USER" -g "$RUNTIME_USER" -m 700 "/home/$RUNTIME_USER/assistant/backups"

echo "assistant_dirs_created=PASS" >> "$EVID/system-base-report.md"

# Optional SSH public key for the new runtime user.
echo
echo "SSH opcional: puedes pegar una public key nueva para el usuario runtime."
echo "Debe empezar por ssh-ed25519, ssh-rsa o ecdsa-sha2-."
read -r -p "Public key SSH nueva o ENTER para saltar: " SSH_PUBLIC_KEY || true

if [[ -n "${SSH_PUBLIC_KEY:-}" ]]; then
  if [[ "$SSH_PUBLIC_KEY" =~ ^(ssh-ed25519|ssh-rsa|ecdsa-sha2-) ]]; then
    install -d -o "$RUNTIME_USER" -g "$RUNTIME_USER" -m 700 "/home/$RUNTIME_USER/.ssh"
    touch "/home/$RUNTIME_USER/.ssh/authorized_keys"
    chown "$RUNTIME_USER:$RUNTIME_USER" "/home/$RUNTIME_USER/.ssh/authorized_keys"
    chmod 600 "/home/$RUNTIME_USER/.ssh/authorized_keys"
    if ! grep -qxF "$SSH_PUBLIC_KEY" "/home/$RUNTIME_USER/.ssh/authorized_keys"; then
      printf '%s\n' "$SSH_PUBLIC_KEY" >> "/home/$RUNTIME_USER/.ssh/authorized_keys"
    fi
    echo "ssh_public_key_configured=PASS" >> "$EVID/system-base-report.md"
  else
    echo "ssh_public_key_configured=INVALID_SKIPPED" >> "$EVID/system-base-report.md"
  fi
else
  echo "ssh_public_key_configured=SKIPPED_BY_USER" >> "$EVID/system-base-report.md"
fi


if groups "$RUNTIME_USER" | grep -qw sudo; then
  echo "runtime_has_sudo=FAIL" >> "$EVID/system-base-report.md"
  status="BLOCKED_RUNTIME_HAS_SUDO"
else
  echo "runtime_has_sudo=NO" >> "$EVID/system-base-report.md"
fi

{
  echo
  echo "final_status=$status"
  echo "network_used=YES_APT"
  echo "vps_touched=YES_SYSTEM_BASE"
  echo "secrets_read=NO"
  echo "MARKER=STAGE_02_SYSTEM_BASE_${status}"
} >> "$EVID/system-base-report.md"

printf '%s\n' \
"AVB_CURRENT_STAGE=02" \
"AVB_CURRENT_STATUS=$status" \
"AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
> "$STATE"

cat > "$HELP" <<EOH
# ChatGPT Help Context

Último tramo ejecutado: 02-system-base
Estado del último tramo: $status
Tramo actual/siguiente: 03-tailscale-ufw
Resultado general: $status
Pendientes:
- Configurar Tailscale antes de endurecer firewall.
- Confirmar segunda vía de acceso antes de activar reglas restrictivas.
Comando recomendado para continuar:
- sudo AVB_LIVE=1 bash install.sh --run 03
Archivo de reporte:
- evidence/02-system-base/system-base-report.md
Recordatorio de seguridad:
- No pegar API keys, tokens, QR, .env, creds.json, secrets.json, cookies ni llaves privadas.
EOH

if [[ "$status" == "PASS" ]]; then
  exit 0
fi

exit 1
