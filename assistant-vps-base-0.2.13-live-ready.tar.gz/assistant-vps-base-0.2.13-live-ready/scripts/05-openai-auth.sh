#!/usr/bin/env bash
set -Eeuo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
EVID="$PACK_DIR/evidence/05-openai-auth"
STATE="$PACK_DIR/state/current.env"
HELP="$PACK_DIR/evidence/chatgpt-help-context.md"
CONFIG="$PACK_DIR/state/install-config.env"

mkdir -p "$EVID"

status="PASS"

{
  echo "# Tramo 05 — openai-auth"
  echo
  echo "mode=LIVE_INTERACTIVE_OPENAI_CODEX_OAUTH"
  echo "started_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
} > "$EVID/openai-auth-report.md"

if [[ "${AVB_LIVE:-0}" != "1" ]]; then
  echo "live_gate=BLOCKED_AVB_LIVE_REQUIRED" >> "$EVID/openai-auth-report.md"
  echo "final_status=BLOCKED_LIVE_GATE" >> "$EVID/openai-auth-report.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=05" \
  "AVB_CURRENT_STATUS=BLOCKED_LIVE_GATE" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

if [[ "$(id -u)" -ne 0 ]]; then
  echo "root_required=FAIL" >> "$EVID/openai-auth-report.md"
  echo "final_status=BLOCKED_ROOT_REQUIRED" >> "$EVID/openai-auth-report.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=05" \
  "AVB_CURRENT_STATUS=BLOCKED_ROOT_REQUIRED" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

if [[ ! -f "$CONFIG" ]]; then
  echo "install_config_present=FAIL" >> "$EVID/openai-auth-report.md"
  echo "final_status=BLOCKED_MISSING_INSTALL_CONFIG_RUN_STAGE_02_FIRST" >> "$EVID/openai-auth-report.md"
  exit 1
fi

# shellcheck disable=SC1090
source "$CONFIG"

if [[ -z "${RUNTIME_USER:-}" ]] || ! id "$RUNTIME_USER" >/dev/null 2>&1; then
  echo "runtime_user_valid=FAIL" >> "$EVID/openai-auth-report.md"
  echo "final_status=BLOCKED_RUNTIME_USER_NOT_FOUND" >> "$EVID/openai-auth-report.md"
  exit 1
fi

echo "runtime_user=$RUNTIME_USER" >> "$EVID/openai-auth-report.md"
echo "runtime_user_valid=PASS" >> "$EVID/openai-auth-report.md"

if sudo -iu "$RUNTIME_USER" bash -lc 'env | grep -q "^OPENAI_API_KEY="'; then
  echo "openai_api_key_env=FAIL_PRESENT_NOT_ALLOWED" >> "$EVID/openai-auth-report.md"
  echo "final_status=BLOCKED_OPENAI_API_KEY_ENV_PRESENT" >> "$EVID/openai-auth-report.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=05" \
  "AVB_CURRENT_STATUS=BLOCKED_OPENAI_API_KEY_ENV_PRESENT" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
else
  echo "openai_api_key_env=ABSENT_PASS" >> "$EVID/openai-auth-report.md"
fi

if ! sudo -iu "$RUNTIME_USER" bash -lc 'export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"; command -v openclaw >/dev/null 2>&1'; then
  echo "openclaw_command=FAIL" >> "$EVID/openai-auth-report.md"
  echo "final_status=BLOCKED_OPENCLAW_NOT_FOUND_RUN_STAGE_04_FIRST" >> "$EVID/openai-auth-report.md"
  exit 1
else
  echo "openclaw_command=PASS" >> "$EVID/openai-auth-report.md"
fi

echo
echo "Este tramo abrirá/autenticará OpenAI/Codex con la cuenta ChatGPT del nuevo usuario."
echo "No pegues tokens, URLs OAuth, device codes, emails ni capturas privadas en ChatGPT."
echo "El comando interactivo NO se guardará en evidence para evitar registrar material sensible."
echo

read -r -p "Escribe SI para iniciar login OAuth OpenAI/Codex ahora: " CONFIRM_AUTH

if [[ "$CONFIRM_AUTH" != "SI" ]]; then
  echo "oauth_login=SKIPPED_BY_USER" >> "$EVID/openai-auth-report.md"
  status="PARTIAL_OPENAI_AUTH_SKIPPED"
else
  echo "oauth_login=STARTED_INTERACTIVE_NOT_LOGGED" >> "$EVID/openai-auth-report.md"

  sudo -iu "$RUNTIME_USER" bash -lc '
    set -Eeuo pipefail
    export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"
    openclaw models auth login --provider openai
  '

  echo "oauth_login=COMPLETED_INTERACTIVE" >> "$EVID/openai-auth-report.md"

  if sudo -iu "$RUNTIME_USER" bash -lc '
    set -Eeuo pipefail
    export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"
    openclaw models auth list --provider openai >/dev/null 2>&1
  '; then
    echo "openai_auth_list=PASS" >> "$EVID/openai-auth-report.md"
  else
    echo "openai_auth_list=FAIL" >> "$EVID/openai-auth-report.md"
    status="BLOCKED_OPENAI_AUTH_LIST_FAILED"
  fi

  if sudo -iu "$RUNTIME_USER" bash -lc '
    set -Eeuo pipefail
    export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"
    openclaw models status --probe --probe-provider openai >/dev/null 2>&1
  '; then
    echo "openai_probe=PASS" >> "$EVID/openai-auth-report.md"
  else
    echo "openai_probe=FAIL" >> "$EVID/openai-auth-report.md"
    status="PARTIAL_OPENAI_AUTH_PROBE_FAILED"
  fi
fi

AUTH_DB="/home/$RUNTIME_USER/.openclaw/agents/main/agent/openclaw-agent.sqlite"

if [[ -f "$AUTH_DB" ]]; then
  echo "auth_store_present=PASS" >> "$EVID/openai-auth-report.md"
  stat -c 'auth_store_perms=%a' "$AUTH_DB" >> "$EVID/openai-auth-report.md"
  stat -c 'auth_store_owner=%U:%G' "$AUTH_DB" >> "$EVID/openai-auth-report.md"
else
  echo "auth_store_present=WARNING_NOT_FOUND" >> "$EVID/openai-auth-report.md"
fi

{
  echo
  echo "final_status=$status"
  echo "network_used=YES_OPENAI_OAUTH_IF_CONFIRMED"
  echo "vps_touched=YES_OPENAI_AUTH_IF_CONFIRMED"
  echo "api_key_used=NO"
  echo "secrets_written_to_evidence=NO"
  echo "MARKER=STAGE_05_OPENAI_AUTH_${status}"
} >> "$EVID/openai-auth-report.md"

printf '%s\n' \
"AVB_CURRENT_STAGE=05" \
"AVB_CURRENT_STATUS=$status" \
"AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
> "$STATE"

cat > "$HELP" <<EOH
# ChatGPT Help Context

Último tramo ejecutado: 05-openai-auth
Estado del último tramo: $status
Tramo actual/siguiente: 06-personality
Resultado general: $status
Pendientes:
- Auth OpenAI/Codex es central: si fue saltada, reanudar repetirá este tramo hasta completarla.
- No usar OPENAI_API_KEY como fallback silencioso.
- No pegar tokens, emails, URLs OAuth, device codes ni capturas privadas.
Comando recomendado para continuar:
- sudo AVB_LIVE=1 bash install.sh --run 06
Comando recomendado para reanudar:
- sudo AVB_LIVE=1 bash install.sh --resume
Archivo de reporte:
- evidence/05-openai-auth/openai-auth-report.md
Recordatorio de seguridad:
- No pegar API keys, tokens, device codes, URLs OAuth privadas, QR, .env, creds.json, secrets.json, cookies ni llaves privadas.
EOH

if [[ "$status" == "PASS" || "$status" == PARTIAL_PASS_* ]]; then
  exit 0
fi

exit 1
