#!/usr/bin/env bash
set -Eeuo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
EVID="$PACK_DIR/evidence/10-skills"
STATE="$PACK_DIR/state/current.env"
CONFIG="$PACK_DIR/state/install-config.env"
HELP="$PACK_DIR/evidence/chatgpt-help-context.md"
SKILLS_ROOT="$PACK_DIR/skills"

mkdir -p "$EVID"

status="PASS"
REPORT="$EVID/skills-install-report.md"
LOG="$EVID/skills-install.log"

{
  echo "# Tramo 10 — skills"
  echo
  echo "mode=LIVE_BUNDLED_SKILLS_LOCAL_ONLY"
  echo "started_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "source_policy=LOCAL_BUNDLED_ONLY"
  echo "remote_fallback=DISABLED"
  echo "install_command_policy=openclaw skills install local_path --as slug"
  echo "memory_state_copied=NO"
  echo "secrets_read=NO"
  echo "secret_values_written_to_evidence=NO"
} > "$REPORT"

if [[ "${AVB_LIVE:-0}" != "1" ]]; then
  echo "live_gate=BLOCKED_AVB_LIVE_REQUIRED" >> "$REPORT"
  echo "final_status=BLOCKED_LIVE_GATE" >> "$REPORT"
  printf '%s\n' \
    "AVB_CURRENT_STAGE=10" \
    "AVB_CURRENT_STATUS=BLOCKED_LIVE_GATE" \
    "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    > "$STATE"
  exit 1
fi

if [[ "$(id -u)" -ne 0 ]]; then
  echo "root_required=FAIL" >> "$REPORT"
  echo "final_status=BLOCKED_ROOT_REQUIRED" >> "$REPORT"
  exit 1
fi

if [[ ! -f "$CONFIG" ]]; then
  echo "install_config_present=FAIL" >> "$REPORT"
  echo "final_status=BLOCKED_MISSING_INSTALL_CONFIG_RUN_STAGE_02_FIRST" >> "$REPORT"
  exit 1
fi

# shellcheck disable=SC1090
source "$CONFIG"

if [[ -z "${RUNTIME_USER:-}" ]] || ! id "$RUNTIME_USER" >/dev/null 2>&1; then
  echo "runtime_user_valid=FAIL" >> "$REPORT"
  echo "final_status=BLOCKED_RUNTIME_USER_NOT_FOUND" >> "$REPORT"
  exit 1
fi

if ! sudo -iu "$RUNTIME_USER" bash -lc 'export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"; command -v openclaw >/dev/null 2>&1'; then
  echo "openclaw_command=FAIL" >> "$REPORT"
  echo "final_status=BLOCKED_OPENCLAW_NOT_FOUND_RUN_STAGE_04_FIRST" >> "$REPORT"
  exit 1
fi

SKILLS=(
  "ontology"
  "total-recall"
  "2nd-brain"
  "mindmap-generator"
  "memory-maintenance"
  "self-improving-agent"
)

echo "runtime_user=$RUNTIME_USER" >> "$REPORT"
echo "skills_expected_count=6" >> "$REPORT"

for skill in "${SKILLS[@]}"; do
  if [[ ! -f "$SKILLS_ROOT/$skill/SKILL.md" ]]; then
    echo "skill_${skill}_local_source=FAIL" >> "$REPORT"
    echo "final_status=BLOCKED_MISSING_BUNDLED_SKILL_${skill}" >> "$REPORT"
    exit 1
  fi
  echo "skill_${skill}_local_source=PASS" >> "$REPORT"
done

echo
echo "Tramo 10 instalará 6 skills desde bundle local limpio."
echo "No usará fallback remoto."
echo "Comando oficial: openclaw skills install <local_path> --as <slug>"
echo

read -r -p "Escribe SI para instalar las 6 skills locales ahora o ENTER para saltar: " CONFIRM_SKILLS

if [[ "$CONFIRM_SKILLS" != "SI" ]]; then
  status="PARTIAL_SKILLS_SKIPPED_BY_USER"
  echo "skills_install=SKIPPED_BY_USER" >> "$REPORT"
else
  BUNDLE_ROOT="/home/$RUNTIME_USER/assistant/skill-bundles"
  install -d -o "$RUNTIME_USER" -g "$RUNTIME_USER" -m 700 "$BUNDLE_ROOT"

  installed=0
  failed=0

  for skill in "${SKILLS[@]}"; do
    source_dir="$SKILLS_ROOT/$skill"
    runtime_dir="$BUNDLE_ROOT/$skill"

    rm -rf "$runtime_dir"
    cp -a "$source_dir" "$runtime_dir"
    chown -R "$RUNTIME_USER:$RUNTIME_USER" "$runtime_dir"
    chmod -R go-rwx "$runtime_dir"

    if sudo -iu "$RUNTIME_USER" bash -lc "export PATH=\"\$HOME/.npm-global/bin:\$HOME/.local/bin:\$PATH\"; openclaw skills install '$runtime_dir' --as '$skill'" >> "$LOG" 2>&1; then
      echo "skill_${skill}_install=PASS" >> "$REPORT"
      installed=$((installed+1))
    else
      echo "skill_${skill}_install=FAIL" >> "$REPORT"
      failed=$((failed+1))
    fi
  done

  echo "skills_installed_count=$installed" >> "$REPORT"
  echo "skills_failed_count=$failed" >> "$REPORT"

  if [[ "$installed" -eq 6 && "$failed" -eq 0 ]]; then
    status="PASS"
  else
    status="PARTIAL_SKILLS_INSTALL_INCOMPLETE"
  fi
fi

{
  echo
  echo "final_status=$status"
  echo "network_used=NO_FOR_SKILL_SOURCE"
  echo "remote_clawhub_fallback=NO"
  echo "vps_touched=YES_SKILLS_IF_CONFIRMED"
  echo "MARKER=STAGE_10_SKILLS_${status}"
} >> "$REPORT"

printf '%s\n' \
  "AVB_CURRENT_STAGE=10" \
  "AVB_CURRENT_STATUS=$status" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"


cat > "$HELP" <<EOH
# ChatGPT Help Context

Último tramo ejecutado: 10-skills
Estado del último tramo: $status
Tramo actual/siguiente: 11-memory-init
Resultado general: $status
Pendientes:
- Las skills son centrales: si fueron saltadas o quedaron incompletas, reanudar repetirá tramo 10 antes de continuar.
- Si PASS, inicializar memoria vacía en workspace OpenClaw.
Comando recomendado para continuar:
- sudo AVB_LIVE=1 bash install.sh --run 11
Comando recomendado para reanudar:
- sudo AVB_LIVE=1 bash install.sh --resume
Archivo de reporte:
- evidence/10-skills/skills-install-report.md
Recordatorio de seguridad:
- No pegar API keys, tokens, QR, .env, creds.json, secrets.json, cookies ni llaves privadas.
EOH

if [[ "$status" == "PASS" ]]; then
  exit 0
fi

exit 1
