#!/usr/bin/env bash
set -Eeuo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
EVID="$PACK_DIR/evidence/01-preflight"
STATE="$PACK_DIR/state/current.env"
HELP="$PACK_DIR/evidence/chatgpt-help-context.md"

mkdir -p "$EVID"

status="PASS"
warn="NO"

passfail() {
  local name="$1"
  shift
  if "$@"; then
    echo "$name=PASS" >> "$EVID/preflight-report.md"
  else
    echo "$name=FAIL" >> "$EVID/preflight-report.md"
    status="BLOCKED_PREFLIGHT"
  fi
}

warncheck() {
  local name="$1"
  shift
  if "$@"; then
    echo "$name=PASS" >> "$EVID/preflight-report.md"
  else
    echo "$name=WARNING" >> "$EVID/preflight-report.md"
    warn="YES"
  fi
}

{
  echo "# Tramo 01 — preflight"
  echo
  echo "mode=LIVE_READONLY_PREFLIGHT"
  echo "started_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "user=$(id -un)"
  echo "uid=$(id -u)"
} > "$EVID/preflight-report.md"

passfail "linux_detected" test -f /etc/os-release
passfail "systemd_available" test -d /run/systemd/system
passfail "bash_available" command -v bash
passfail "apt_available" command -v apt-get
passfail "sudo_available" command -v sudo

arch="$(uname -m || true)"
echo "arch=$arch" >> "$EVID/preflight-report.md"
if [[ "$arch" == "x86_64" || "$arch" == "aarch64" ]]; then
  echo "arch_supported=PASS" >> "$EVID/preflight-report.md"
else
  echo "arch_supported=FAIL" >> "$EVID/preflight-report.md"
  status="BLOCKED_PREFLIGHT"
fi

if grep -qi 'ubuntu' /etc/os-release; then
  echo "ubuntu_detected=PASS" >> "$EVID/preflight-report.md"
else
  echo "ubuntu_detected=FAIL" >> "$EVID/preflight-report.md"
  status="BLOCKED_UNSUPPORTED_OS"
fi

mem_kb="$(awk '/MemTotal/ {print $2}' /proc/meminfo 2>/dev/null || echo 0)"
disk_kb="$(df -Pk / | awk 'NR==2 {print $4}' 2>/dev/null || echo 0)"

echo "mem_kb=$mem_kb" >> "$EVID/preflight-report.md"
echo "disk_free_kb=$disk_kb" >> "$EVID/preflight-report.md"

warncheck "memory_min_2gb" test "$mem_kb" -ge 1900000
warncheck "disk_free_min_10gb" test "$disk_kb" -ge 10000000

if [[ -f /var/run/reboot-required ]]; then
  echo "reboot_required=YES" >> "$EVID/preflight-report.md"
  status="BLOCKED_REBOOT_REQUIRED"
else
  echo "reboot_required=NO" >> "$EVID/preflight-report.md"
fi

for p in openclaw node npm tailscale ufw; do
  if command -v "$p" >/dev/null 2>&1; then
    echo "existing_${p}=YES" >> "$EVID/preflight-report.md"
    if [[ "$p" == "openclaw" ]]; then
      echo "existing_installation_block=OPENCLAW_PRESENT" >> "$EVID/preflight-report.md"
      status="BLOCKED_EXISTING_OPENCLAW_INSTALLATION"
    fi
  else
    echo "existing_${p}=NO" >> "$EVID/preflight-report.md"
  fi
done

{
  echo
  echo "warnings=$warn"
  echo "final_status=$status"
  echo "network_used=NO"
  echo "vps_touched=NO"
  echo "secrets_read=NO"
  echo "MARKER=STAGE_01_PREFLIGHT_${status}"
} >> "$EVID/preflight-report.md"

printf '%s\n' \
"AVB_CURRENT_STAGE=01" \
"AVB_CURRENT_STATUS=$status" \
"AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
> "$STATE"

cat > "$HELP" <<EOH
# ChatGPT Help Context

Último tramo ejecutado: 01-preflight
Estado del último tramo: $status
Tramo actual/siguiente: 02-system-base
Resultado general: $status
Pendientes:
- Si PASS, continuar con creación de usuario runtime y paquetes base.
- Si BLOCKED_REBOOT_REQUIRED, reiniciar VPS y luego reanudar.
Comando recomendado para continuar:
- sudo bash install.sh --run 02
Comando recomendado para reanudar:
- sudo bash install.sh --resume
Archivo de reporte:
- evidence/01-preflight/preflight-report.md
Recordatorio de seguridad:
- No pegar API keys, tokens, QR, .env, creds.json, secrets.json, cookies ni llaves privadas.
EOH

if [[ "$status" == "PASS" ]]; then
  exit 0
fi

exit 1
