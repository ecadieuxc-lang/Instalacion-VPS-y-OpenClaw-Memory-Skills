#!/usr/bin/env bash
set -Eeuo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
EVID="$PACK_DIR/evidence/06-personality"
STATE="$PACK_DIR/state/current.env"
HELP="$PACK_DIR/evidence/chatgpt-help-context.md"
CONFIG="$PACK_DIR/state/install-config.env"

mkdir -p "$EVID"

status="PASS"

{
  echo "# Tramo 06 — personality"
  echo
  echo "mode=LIVE_INTERACTIVE_PERSONALITY"
  echo "started_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
} > "$EVID/personality-report.md"

if [[ "${AVB_LIVE:-0}" != "1" ]]; then
  echo "live_gate=BLOCKED_AVB_LIVE_REQUIRED" >> "$EVID/personality-report.md"
  echo "final_status=BLOCKED_LIVE_GATE" >> "$EVID/personality-report.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=06" \
  "AVB_CURRENT_STATUS=BLOCKED_LIVE_GATE" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

if [[ "$(id -u)" -ne 0 ]]; then
  echo "root_required=FAIL" >> "$EVID/personality-report.md"
  echo "final_status=BLOCKED_ROOT_REQUIRED" >> "$EVID/personality-report.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=06" \
  "AVB_CURRENT_STATUS=BLOCKED_ROOT_REQUIRED" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

if [[ ! -f "$CONFIG" ]]; then
  echo "install_config_present=FAIL" >> "$EVID/personality-report.md"
  echo "final_status=BLOCKED_MISSING_INSTALL_CONFIG_RUN_STAGE_02_FIRST" >> "$EVID/personality-report.md"
  exit 1
fi

# shellcheck disable=SC1090
source "$CONFIG"

if [[ -z "${RUNTIME_USER:-}" ]] || ! id "$RUNTIME_USER" >/dev/null 2>&1; then
  echo "runtime_user_valid=FAIL" >> "$EVID/personality-report.md"
  echo "final_status=BLOCKED_RUNTIME_USER_NOT_FOUND" >> "$EVID/personality-report.md"
  exit 1
fi

WORKSPACE="/home/$RUNTIME_USER/.openclaw/workspace"
BACKUP_DIR="/home/$RUNTIME_USER/assistant/backups/personality-$(date -u +%Y%m%dT%H%M%SZ)"

if [[ ! -d "$WORKSPACE" ]]; then
  mkdir -p "$WORKSPACE"
  chown "$RUNTIME_USER:$RUNTIME_USER" "$WORKSPACE"
  chmod 700 "$WORKSPACE"
  echo "workspace_created_if_missing=YES" >> "$EVID/personality-report.md"
else
  echo "workspace_present=PASS" >> "$EVID/personality-report.md"
fi

echo
echo "Configuración de personalidad de la nueva IA."
echo "No uses datos de un asistente anterior ni datos de un dueño anterior. Esto es para el nuevo dueño."
echo

read -r -p "Nombre de la IA: " ASSISTANT_NAME
read -r -p "Nombre del dueño/usuario principal: " OWNER_NAME
read -r -p "Cómo debe tratar al dueño. Ej: por nombre, de usted, compa, etc: " OWNER_TREATMENT
read -r -p "Estilo general. Ej: sobrio, cercano, ejecutivo, técnico simple: " ASSISTANT_STYLE
read -r -p "Nivel de crítica. Ej: suave, honesto, directo, muy crítico: " CRITICISM_LEVEL
read -r -p "Estilo WhatsApp. Ej: breve, natural, formal, con humor suave: " WHATSAPP_STYLE
read -r -p "Frases prohibidas o cosas que debe evitar [opcional]: " FORBIDDEN_PHRASES

ASSISTANT_NAME="${ASSISTANT_NAME:-Assistant}"
OWNER_NAME="${OWNER_NAME:-Usuario}"
OWNER_TREATMENT="${OWNER_TREATMENT:-por nombre}"
ASSISTANT_STYLE="${ASSISTANT_STYLE:-claro, útil y cercano}"
CRITICISM_LEVEL="${CRITICISM_LEVEL:-honesto y respetuoso}"
WHATSAPP_STYLE="${WHATSAPP_STYLE:-breve, natural y claro}"
FORBIDDEN_PHRASES="${FORBIDDEN_PHRASES:-ninguna declarada}"

validate_safe_text() {
  local value="$1"
  if [[ "$value" =~ [\`\;\|\&\<\>\$\\] ]]; then
    return 1
  fi
  return 0
}

for value in "$ASSISTANT_NAME" "$OWNER_NAME" "$OWNER_TREATMENT" "$ASSISTANT_STYLE" "$CRITICISM_LEVEL" "$WHATSAPP_STYLE" "$FORBIDDEN_PHRASES"; do
  if ! validate_safe_text "$value"; then
    echo "input_validation=FAIL_UNSAFE_CHARACTERS" >> "$EVID/personality-report.md"
    echo "final_status=BLOCKED_UNSAFE_PERSONALITY_INPUT" >> "$EVID/personality-report.md"
    exit 1
  fi
done

echo "input_validation=PASS" >> "$EVID/personality-report.md"

mkdir -p "$BACKUP_DIR"
chown "$RUNTIME_USER:$RUNTIME_USER" "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"

for f in AGENTS.md SOUL.md USER.md IDENTITY.md TOOLS.md HEARTBEAT.md MEMORY.md; do
  if [[ -f "$WORKSPACE/$f" ]]; then
    cp -a "$WORKSPACE/$f" "$BACKUP_DIR/$f"
    echo "backup_${f}=PASS" >> "$EVID/personality-report.md"
  else
    echo "backup_${f}=MISSING_CREATED_NEW" >> "$EVID/personality-report.md"
  fi
done

cat > "$WORKSPACE/IDENTITY.md" <<EOID
# Identity

Assistant name: $ASSISTANT_NAME
Primary owner: $OWNER_NAME
Owner treatment: $OWNER_TREATMENT

This assistant is a new personal assistant instance.
It must not claim to be a previous assistant instance.
It must not inherit memories, credentials, private data, phone numbers, accounts, SSH keys, or preferences from previous owner.

Core rule:
- New identity.
- New owner.
- New credentials.
- Empty memory.
- No cloned personality.
EOID

cat > "$WORKSPACE/SOUL.md" <<EOSOUL
# Soul

You are $ASSISTANT_NAME, a personal assistant for $OWNER_NAME.

Style:
- $ASSISTANT_STYLE

Criticism level:
- $CRITICISM_LEVEL

WhatsApp style:
- $WHATSAPP_STYLE

Treatment:
- Address the owner using: $OWNER_TREATMENT

Avoid:
- $FORBIDDEN_PHRASES

Behavior:
- Be useful, practical, direct and safe.
- Ask for clarification only when necessary.
- Do not invent completed actions.
- Do not expose secrets.
- Do not use any previous assistant identity.
- Do not use previous owner's memories or personal context.
EOSOUL

cat > "$WORKSPACE/USER.md" <<EOUSER
# User

Primary user: $OWNER_NAME
Preferred treatment: $OWNER_TREATMENT

Known stable preferences:
- Style expected from assistant: $ASSISTANT_STYLE
- Criticism level: $CRITICISM_LEVEL
- WhatsApp style: $WHATSAPP_STYLE

Memory policy:
- Start empty.
- Learn only from the new owner.
- Do not import memories from a previous assistant, previous owner, or any previous VPS.
EOUSER

cat > "$WORKSPACE/AGENTS.md" <<EOAGENTS
# Agents

Primary assistant:
- Name: $ASSISTANT_NAME
- Owner: $OWNER_NAME
- Runtime user: $RUNTIME_USER

Rules:
- Operate as a personal assistant.
- Keep secrets out of logs and reports.
- Use tools carefully.
- Do not expose OpenClaw publicly.
EOAGENTS

cat > "$WORKSPACE/TOOLS.md" <<EOTOOLS
# Tools

Tool policy:
- Prefer safe local actions.
- Do not use credentials unless configured by the new owner.
- Do not print API keys, tokens, QR codes, cookies, private keys, .env files, creds.json or secrets.json.
- WhatsApp, skills and automations must use new credentials and new sessions only.
EOTOOLS

cat > "$WORKSPACE/HEARTBEAT.md" <<EOHEART
# Heartbeat

Assistant status:
- Identity initialized.
- Personality initialized.
- Memory starts empty.
- Awaiting real credentials and integrations from the new owner.
EOHEART

cat > "$WORKSPACE/MEMORY.md" <<EOMEM
# Memory

Memory state:
- Empty initial memory.
- No imported memories.
- No previous assistant memory.
- No previous owner memory.
- No inherited observations.

Rules:
- Store only information learned from the new owner after installation.
- Do not fabricate memories.
EOMEM

chown -R "$RUNTIME_USER:$RUNTIME_USER" "$WORKSPACE"
chmod 700 "$WORKSPACE"
find "$WORKSPACE" -type f -name '*.md' -exec chmod 600 {} \;

{
  echo "assistant_name_configured=YES"
  echo "owner_name_configured=YES"
  echo "identity_written=PASS"
  echo "soul_written=PASS"
  echo "user_written=PASS"
  echo "agents_written=PASS"
  echo "tools_written=PASS"
  echo "heartbeat_written=PASS"
  echo "memory_written=PASS"
  echo "backup_dir=$BACKUP_DIR"
} >> "$EVID/personality-report.md"

IDENTITY_SCAN_FILE="$EVID/inherited-identity-scan.txt"
: > "$IDENTITY_SCAN_FILE"

if grep -RIEn \
  -e '^Primary owner:[[:space:]]*previous owner$' \
  -e '^Primary user:[[:space:]]*previous owner$' \
  -e '^Owner:[[:space:]]*previous owner$' \
  "$WORKSPACE" > "$IDENTITY_SCAN_FILE" 2>/dev/null; then
  echo "inherited_identity_scan=FAIL" >> "$EVID/personality-report.md"
  echo "inherited_identity_scan_mode=CONTEXTUAL_PREVIOUS_OWNER_HEADINGS_ONLY" >> "$EVID/personality-report.md"
  status="BLOCKED_INHERITED_IDENTITY_SCAN"
else
  echo "inherited_identity_scan=PASS" >> "$EVID/personality-report.md"
  echo "inherited_identity_scan_mode=CONTEXTUAL_PREVIOUS_OWNER_HEADINGS_ONLY" >> "$EVID/personality-report.md"
fi

{
  echo
  echo "final_status=$status"
  echo "network_used=NO"
  echo "vps_touched=YES_OPENCLAW_WORKSPACE"
  echo "secrets_read=NO"
  echo "MARKER=STAGE_06_PERSONALITY_${status}"
} >> "$EVID/personality-report.md"

printf '%s\n' \
"AVB_CURRENT_STAGE=06" \
"AVB_CURRENT_STATUS=$status" \
"AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
> "$STATE"

cat > "$HELP" <<EOH
# ChatGPT Help Context

Último tramo ejecutado: 06-personality
Estado del último tramo: $status
Tramo actual/siguiente: 07-whatsapp
Resultado general: $status
Pendientes:
- Configurar WhatsApp nuevo si el usuario lo quiere.
- Usar QR y sesión nueva.
Comando recomendado para continuar:
- sudo AVB_LIVE=1 bash install.sh --run 07
Comando recomendado para reanudar:
- sudo AVB_LIVE=1 bash install.sh --resume
Archivo de reporte:
- evidence/06-personality/personality-report.md
Recordatorio de seguridad:
- No pegar API keys, tokens, QR, .env, creds.json, secrets.json, cookies ni llaves privadas.
EOH

if [[ "$status" == "PASS" ]]; then
  exit 0
fi

exit 1
