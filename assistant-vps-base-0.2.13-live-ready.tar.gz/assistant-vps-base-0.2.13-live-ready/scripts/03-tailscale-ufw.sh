#!/usr/bin/env bash
set -Eeuo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
EVID="$PACK_DIR/evidence/03-tailscale-ufw"
STATE="$PACK_DIR/state/current.env"
HELP="$PACK_DIR/evidence/chatgpt-help-context.md"

mkdir -p "$EVID"

status="PASS"

{
  echo "# Tramo 03 — tailscale-ufw"
  echo
  echo "mode=LIVE_MUTATING_TAILSCALE_UFW"
  echo "started_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
} > "$EVID/tailscale-ufw-report.md"

if [[ "${AVB_LIVE:-0}" != "1" ]]; then
  echo "live_gate=BLOCKED_AVB_LIVE_REQUIRED" >> "$EVID/tailscale-ufw-report.md"
  echo "final_status=BLOCKED_LIVE_GATE" >> "$EVID/tailscale-ufw-report.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=03" \
  "AVB_CURRENT_STATUS=BLOCKED_LIVE_GATE" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

if [[ "$(id -u)" -ne 0 ]]; then
  echo "root_required=FAIL" >> "$EVID/tailscale-ufw-report.md"
  echo "final_status=BLOCKED_ROOT_REQUIRED" >> "$EVID/tailscale-ufw-report.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=03" \
  "AVB_CURRENT_STATUS=BLOCKED_ROOT_REQUIRED" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

export DEBIAN_FRONTEND=noninteractive

if command -v tailscale >/dev/null 2>&1; then
  echo "tailscale_installed=ALREADY_PRESENT" >> "$EVID/tailscale-ufw-report.md"
else
  echo "tailscale_installed=INSTALLING" >> "$EVID/tailscale-ufw-report.md"
  curl -fsSL https://tailscale.com/install.sh | sh >> "$EVID/tailscale-install.log" 2>&1
  echo "tailscale_installed=PASS" >> "$EVID/tailscale-ufw-report.md"
fi

systemctl enable --now tailscaled >> "$EVID/tailscale-service.log" 2>&1 || true

if tailscale status >/dev/null 2>&1; then
  echo "tailscale_status=PASS" >> "$EVID/tailscale-ufw-report.md"
else
  echo "tailscale_status=LOGIN_REQUIRED" >> "$EVID/tailscale-ufw-report.md"
  echo "Abriendo login Tailscale. Sigue la URL que aparecerá abajo."
  tailscale up
fi

if tailscale ip -4 >/dev/null 2>&1; then
  TS_IP="$(tailscale ip -4 | head -n1)"
  echo "tailscale_ip_present=PASS" >> "$EVID/tailscale-ufw-report.md"
  echo "tailscale_ip_masked=${TS_IP%.*}.x" >> "$EVID/tailscale-ufw-report.md"
else
  echo "tailscale_ip_present=FAIL" >> "$EVID/tailscale-ufw-report.md"
  status="PARTIAL_TAILSCALE_LOGIN_REQUIRED"
fi

if [[ "$status" == "PASS" ]]; then
  echo
  echo "anti_cut_ssh_confirmation_gate=PASS" >> "$EVID/tailscale-ufw-report.md"
  echo "Antes de activar UFW, debes confirmar que tienes una segunda vía de acceso por Tailscale."
  echo "Abre otra terminal y prueba entrar al VPS por su IP Tailscale."
  echo
  read -r -p "Escribe SI para confirmar acceso por Tailscale y configurar UFW seguro: " CONFIRM_TS

  if [[ "$CONFIRM_TS" != "SI" ]]; then
    echo "ufw_configured=SKIPPED_USER_DID_NOT_CONFIRM_TAILSCALE_ACCESS" >> "$EVID/tailscale-ufw-report.md"
    status="PARTIAL_UFW_SKIPPED_PENDING_TAILSCALE_CONFIRMATION"
  else
    # Keep management private after the user confirmed a second Tailscale access path.
    # Allow SSH only through tailscale0 plus Tailscale UDP; do not keep public SSH open.
    ufw --force reset >> "$EVID/ufw.log" 2>&1
    ufw default deny incoming >> "$EVID/ufw.log" 2>&1
    ufw default allow outgoing >> "$EVID/ufw.log" 2>&1
    ufw allow in on tailscale0 to any port 22 proto tcp >> "$EVID/ufw.log" 2>&1
    ufw allow 41641/udp >> "$EVID/ufw.log" 2>&1 || true
    echo "ufw_tailscale_ssh_only=PASS" >> "$EVID/tailscale-ufw-report.md"
    echo "public_ssh_left_open=NO" >> "$EVID/tailscale-ufw-report.md"
    ufw --force enable >> "$EVID/ufw.log" 2>&1
    ufw status verbose > "$EVID/ufw-status.txt" 2>&1 || true

    echo "ufw_configured=PASS" >> "$EVID/tailscale-ufw-report.md"
  fi
fi

{
  echo
  echo "final_status=$status"
  echo "network_used=YES_TAILSCALE"
  echo "vps_touched=YES_TAILSCALE_UFW"
  echo "secrets_read=NO"
  echo "MARKER=STAGE_03_TAILSCALE_UFW_${status}"
} >> "$EVID/tailscale-ufw-report.md"

printf '%s\n' \
"AVB_CURRENT_STAGE=03" \
"AVB_CURRENT_STATUS=$status" \
"AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
> "$STATE"

cat > "$HELP" <<EOH
# ChatGPT Help Context

Último tramo ejecutado: 03-tailscale-ufw
Estado del último tramo: $status
Tramo actual/siguiente: 04-openclaw
Resultado general: $status
Pendientes:
- Si Tailscale quedó pendiente, completar login y reanudar.
- Si UFW fue saltado, confirmar acceso por Tailscale y reintentar tramo 03.
Comando recomendado para continuar:
- sudo AVB_LIVE=1 bash install.sh --run 04
Comando recomendado para reanudar:
- sudo AVB_LIVE=1 bash install.sh --resume
Archivo de reporte:
- evidence/03-tailscale-ufw/tailscale-ufw-report.md
Recordatorio de seguridad:
- No pegar API keys, tokens, QR, .env, creds.json, secrets.json, cookies ni llaves privadas.
EOH

if [[ "$status" == "PASS" ]]; then
  exit 0
fi

exit 1
