#!/usr/bin/env bash
set -Eeuo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
EVID="$PACK_DIR/evidence/04-openclaw"
STATE="$PACK_DIR/state/current.env"
HELP="$PACK_DIR/evidence/chatgpt-help-context.md"
CONFIG="$PACK_DIR/state/install-config.env"

mkdir -p "$EVID"

status="PASS"
SUDOERS_FILE=""

{
  echo "# Tramo 04 — openclaw"
  echo
  echo "mode=LIVE_MUTATING_OPENCLAW"
  echo "started_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
} > "$EVID/openclaw-report.md"

cleanup_temp_sudo() {
  if [[ -n "${SUDOERS_FILE:-}" && -f "$SUDOERS_FILE" ]]; then
    rm -f "$SUDOERS_FILE"
  fi
}
trap cleanup_temp_sudo EXIT

if [[ "${AVB_LIVE:-0}" != "1" ]]; then
  echo "live_gate=BLOCKED_AVB_LIVE_REQUIRED" >> "$EVID/openclaw-report.md"
  echo "final_status=BLOCKED_LIVE_GATE" >> "$EVID/openclaw-report.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=04" \
  "AVB_CURRENT_STATUS=BLOCKED_LIVE_GATE" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

if [[ "$(id -u)" -ne 0 ]]; then
  echo "root_required=FAIL" >> "$EVID/openclaw-report.md"
  echo "final_status=BLOCKED_ROOT_REQUIRED" >> "$EVID/openclaw-report.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=04" \
  "AVB_CURRENT_STATUS=BLOCKED_ROOT_REQUIRED" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

if [[ ! -f "$CONFIG" ]]; then
  echo "install_config_present=FAIL" >> "$EVID/openclaw-report.md"
  echo "final_status=BLOCKED_MISSING_INSTALL_CONFIG_RUN_STAGE_02_FIRST" >> "$EVID/openclaw-report.md"
  exit 1
fi

# shellcheck disable=SC1090
source "$CONFIG"

if [[ -z "${RUNTIME_USER:-}" ]]; then
  echo "runtime_user_present=FAIL" >> "$EVID/openclaw-report.md"
  echo "final_status=BLOCKED_MISSING_RUNTIME_USER" >> "$EVID/openclaw-report.md"
  exit 1
fi

if ! id "$RUNTIME_USER" >/dev/null 2>&1; then
  echo "runtime_user_exists=FAIL" >> "$EVID/openclaw-report.md"
  echo "final_status=BLOCKED_RUNTIME_USER_NOT_FOUND" >> "$EVID/openclaw-report.md"
  exit 1
fi

echo "runtime_user=$RUNTIME_USER" >> "$EVID/openclaw-report.md"
echo "runtime_user_exists=PASS" >> "$EVID/openclaw-report.md"

SUDOERS_FILE="/etc/sudoers.d/assistant-openclaw-install-$RUNTIME_USER"
printf '%s\n' "$RUNTIME_USER ALL=(root) NOPASSWD:ALL" > "$SUDOERS_FILE"
chmod 440 "$SUDOERS_FILE"
visudo -cf "$SUDOERS_FILE" >> "$EVID/sudoers-check.log" 2>&1

echo "temp_sudoers_created=PASS" >> "$EVID/openclaw-report.md"

sudo -iu "$RUNTIME_USER" bash -lc '
  set -Eeuo pipefail
  export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"
  curl -fsSL https://openclaw.ai/install.sh | bash
' >> "$EVID/openclaw-install.log" 2>&1

echo "openclaw_install_exit=0" >> "$EVID/openclaw-report.md"

if sudo -iu "$RUNTIME_USER" bash -lc '
  set -Eeuo pipefail
  export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"
  openclaw update
' >> "$EVID/openclaw-update.log" 2>&1; then
  echo "openclaw_update_latest_attempt=PASS" >> "$EVID/openclaw-report.md"
else
  echo "openclaw_update_latest_attempt=WARNING_FAILED_OR_UNAVAILABLE" >> "$EVID/openclaw-report.md"
fi

cleanup_temp_sudo
trap - EXIT

echo "temp_sudoers_removed=PASS" >> "$EVID/openclaw-report.md"

if sudo -iu "$RUNTIME_USER" bash -lc 'sudo -n true' >/dev/null 2>&1; then
  echo "runtime_no_sudo_after_cleanup=FAIL" >> "$EVID/openclaw-report.md"
  status="BLOCKED_RUNTIME_STILL_HAS_SUDO"
else
  echo "runtime_no_sudo_after_cleanup=PASS" >> "$EVID/openclaw-report.md"
fi

sudo -iu "$RUNTIME_USER" bash -lc '
  set -Eeuo pipefail
  export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"
  command -v openclaw || test -x "$HOME/.npm-global/bin/openclaw"
' >> "$EVID/openclaw-command.log" 2>&1

echo "openclaw_binary_present=PASS" >> "$EVID/openclaw-report.md"

sudo -iu "$RUNTIME_USER" bash -lc '
  set -Eeuo pipefail
  export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"
  openclaw --version
' > "$EVID/openclaw-version.txt" 2>&1

echo "openclaw_version_check=PASS" >> "$EVID/openclaw-report.md"

OPENCLAW_HOME="/home/$RUNTIME_USER/.openclaw"
OPENCLAW_JSON="$OPENCLAW_HOME/openclaw.json"

if [[ ! -d "$OPENCLAW_HOME" ]]; then
  echo "openclaw_home_present=FAIL" >> "$EVID/openclaw-report.md"
  status="BLOCKED_OPENCLAW_HOME_MISSING"
else
  echo "openclaw_home_present=PASS" >> "$EVID/openclaw-report.md"
fi

if [[ -f "$OPENCLAW_JSON" ]]; then
  cp -a "$OPENCLAW_JSON" "$OPENCLAW_JSON.before-stage04-$(date -u +%Y%m%dT%H%M%SZ)"
  echo "openclaw_json_present=PASS" >> "$EVID/openclaw-report.md"

  python3 - "$OPENCLAW_JSON" "$RUNTIME_USER" <<'PY'
import json, sys
from pathlib import Path

path = Path(sys.argv[1])
runtime = sys.argv[2]

try:
    data = json.loads(path.read_text())
except Exception:
    data = {}

def ensure_obj(parent, key):
    if not isinstance(parent.get(key), dict):
        parent[key] = {}
    return parent[key]

agents = ensure_obj(data, "agents")
defaults = ensure_obj(agents, "defaults")
defaults["workspace"] = f"/home/{runtime}/.openclaw/workspace"

model = ensure_obj(defaults, "model")
model["primary"] = "openai/gpt-5.5"
defaults["models_keys"] = ["openai/gpt-5.5"]

gateway = ensure_obj(data, "gateway")
gateway["mode"] = "local"
gateway["bind"] = "loopback"
gateway["port"] = 18789
gateway["tailscale"] = {"mode": "off"}

control = ensure_obj(gateway, "controlUi")
control["allowInsecureAuth"] = False

tools = ensure_obj(data, "tools")
tools["profile"] = "coding"
web = ensure_obj(tools, "web")
search = ensure_obj(web, "search")
search["provider"] = "parallel-free"
search["enabled"] = True

plugins = ensure_obj(data, "plugins")
plugins["allow"] = ["codex"]

data["auth"] = {"profile_providers": ["openai"]}

path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
PY

  chown "$RUNTIME_USER:$RUNTIME_USER" "$OPENCLAW_JSON"
  chmod 600 "$OPENCLAW_JSON"
  echo "openclaw_json_configured=PASS" >> "$EVID/openclaw-report.md"
else
  echo "openclaw_json_present=FAIL" >> "$EVID/openclaw-report.md"
  status="PARTIAL_OPENCLAW_CONFIG_PENDING"
fi

sudo -iu "$RUNTIME_USER" bash -lc '
  set -Eeuo pipefail
  export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"
  openclaw daemon restart
' >> "$EVID/openclaw-daemon.log" 2>&1 || {
  echo "openclaw_daemon_restart=FAIL" >> "$EVID/openclaw-report.md"
  status="PARTIAL_OPENCLAW_DAEMON_RESTART_FAILED"
}

if ! grep -q 'openclaw_daemon_restart=FAIL' "$EVID/openclaw-report.md"; then
  echo "openclaw_daemon_restart=PASS" >> "$EVID/openclaw-report.md"
fi

if [[ -d "/home/$RUNTIME_USER/.openclaw/workspace" ]]; then
  echo "workspace_present=PASS" >> "$EVID/openclaw-report.md"
else
  echo "workspace_present=WARNING_NOT_CREATED_YET" >> "$EVID/openclaw-report.md"
fi

find "/home/$RUNTIME_USER/.openclaw" -maxdepth 2 \( -user root -o -group root \) -print > "$EVID/root-owned-openclaw-paths.txt" 2>/dev/null || true

if [[ -s "$EVID/root-owned-openclaw-paths.txt" ]]; then
  echo "root_owned_openclaw_paths=FAIL" >> "$EVID/openclaw-report.md"
  status="BLOCKED_ROOT_OWNED_OPENCLAW_PATHS"
else
  echo "root_owned_openclaw_paths=PASS" >> "$EVID/openclaw-report.md"
fi

{
  echo
  echo "final_status=$status"
  echo "network_used=YES_OPENCLAW_INSTALL"
  echo "vps_touched=YES_OPENCLAW"
  echo "secrets_read=NO"
  echo "MARKER=STAGE_04_OPENCLAW_${status}"
} >> "$EVID/openclaw-report.md"

printf '%s\n' \
"AVB_CURRENT_STAGE=04" \
"AVB_CURRENT_STATUS=$status" \
"AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
> "$STATE"

cat > "$HELP" <<EOH
# ChatGPT Help Context

Último tramo ejecutado: 04-openclaw
Estado del último tramo: $status
Tramo actual/siguiente: 05-openai-auth
Resultado general: $status
Pendientes:
- Autenticar OpenAI/Codex con cuenta nueva del usuario.
- No usar API key como fallback silencioso.
Comando recomendado para continuar:
- sudo AVB_LIVE=1 bash install.sh --run 05
Comando recomendado para reanudar:
- sudo AVB_LIVE=1 bash install.sh --resume
Archivo de reporte:
- evidence/04-openclaw/openclaw-report.md
Recordatorio de seguridad:
- No pegar API keys, tokens, device codes, URLs OAuth privadas, QR, .env, creds.json, secrets.json, cookies ni llaves privadas.
EOH

if [[ "$status" == "PASS" ]]; then
  exit 0
fi

exit 1
