#!/usr/bin/env bash
set -Eeuo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
EVID="$PACK_DIR/evidence/00-audit-package"
STATE="$PACK_DIR/state/current.env"
HELP="$PACK_DIR/evidence/chatgpt-help-context.md"

mkdir -p "$EVID" "$PACK_DIR/evidence" "$PACK_DIR/state"

status="PASS"

check() {
  local name="$1"
  shift
  if "$@"; then
    echo "$name=PASS" >> "$EVID/audit-package-report.md"
  else
    echo "$name=FAIL" >> "$EVID/audit-package-report.md"
    status="FAILED"
  fi
}

{
  echo "# Tramo 00 — audit-package"
  echo
  echo "mode=LIVE_SAFE_READONLY"
  echo "started_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
} > "$EVID/audit-package-report.md"

check "package_dir" test -d "$PACK_DIR"
check "install_sh_present" test -f "$PACK_DIR/install.sh"
check "version_present" test -f "$PACK_DIR/VERSION"
check "manifest_present" test -f "$PACK_DIR/MANIFEST.md"
check "scripts_dir_present" test -d "$PACK_DIR/scripts"
check "install_bash_n" bash -n "$PACK_DIR/install.sh"


if [[ -f "$PACK_DIR/CHECKSUMS.sha256" ]]; then
  if (cd "$PACK_DIR" && sha256sum -c CHECKSUMS.sha256 >> "$EVID/checksums.log" 2>&1); then
    echo "checksums_sha256=PASS" >> "$EVID/audit-package-report.md"
  else
    echo "checksums_sha256=FAIL" >> "$EVID/audit-package-report.md"
    status="FAILED"
  fi
else
  echo "checksums_sha256=FAIL_MISSING" >> "$EVID/audit-package-report.md"
  status="FAILED"
fi

for n in 00 01 02 03 04 05 06 07 08 09 10 11 12 13 14; do
  if ls "$PACK_DIR/scripts/$n-"*.sh >/dev/null 2>&1; then
    echo "script_${n}_present=PASS" >> "$EVID/audit-package-report.md"
  else
    echo "script_${n}_present=FAIL" >> "$EVID/audit-package-report.md"
    status="FAILED"
  fi
done

needles=(
  "/home/" "runtime_user"
  "/home/" "previous-owner/.ssh"
  "r" "oy_vps_ed25519"
  "137." "184.135.47"
  "100." "89.198.28"
  "duck" "dns"
  "com.r" "oy.app"
)

contaminated="NO"
for ((i=0; i<${#needles[@]}; i+=2)); do
  needle="${needles[$i]}${needles[$((i+1))]}"
  if grep -RIl -- "$needle" "$PACK_DIR" >/dev/null; then
    contaminated="YES"
  fi
done

if [[ "$contaminated" == "YES" ]]; then
  echo "live_state_contamination=FAIL" >> "$EVID/audit-package-report.md"
  status="BLOCKED_SECRET_SCAN"
else
  echo "live_state_contamination=PASS" >> "$EVID/audit-package-report.md"
fi

if find "$PACK_DIR" -type f -perm /111 -print -quit | grep -q .; then
  echo "unexpected_executables=FAIL" >> "$EVID/audit-package-report.md"
  status="FAILED"
else
  echo "unexpected_executables=PASS" >> "$EVID/audit-package-report.md"
fi

{
  echo
  echo "final_status=$status"
  echo "network_used=NO"
  echo "vps_touched=NO"
  echo "secrets_read=NO"
  echo "MARKER=STAGE_00_AUDIT_PACKAGE_${status}"
} >> "$EVID/audit-package-report.md"

printf '%s\n' \
"AVB_CURRENT_STAGE=00" \
"AVB_CURRENT_STATUS=$status" \
"AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
> "$STATE"

cat > "$HELP" <<EOH
# ChatGPT Help Context

Último tramo ejecutado: 00-audit-package
Estado del último tramo: $status
Tramo actual/siguiente: 01-preflight
Resultado general: $status
Pendientes:
- Ejecutar preflight del VPS antes de instalar base de sistema.
Errores no sensibles:
- Revisar evidence/00-audit-package/audit-package-report.md si hubo FAIL.
Comando recomendado para continuar:
- sudo bash install.sh --run 01
Recordatorio de seguridad:
- No pegar API keys, tokens, QR, .env, creds.json, secrets.json, cookies ni llaves privadas.
EOH

if [[ "$status" == "PASS" ]]; then
  exit 0
fi

exit 1
