#!/usr/bin/env bash
set -Eeuo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
EVID="$PACK_DIR/evidence/12-automations"
STATE="$PACK_DIR/state/current.env"
HELP="$PACK_DIR/evidence/chatgpt-help-context.md"
CONFIG="$PACK_DIR/state/install-config.env"

mkdir -p "$EVID"
REPORT="$EVID/skills-automation-report.md"
status="PASS"
missing=0
pending_credentials=0

{
  echo "# Tramo 12 — automatizaciones de skills"
  echo
  echo "mode=LIVE_SKILL_AUTOMATIONS_WORKSPACE"
  echo "started_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
} > "$REPORT"

if [[ "${AVB_LIVE:-0}" != "1" ]]; then
  echo "live_gate=BLOCKED_AVB_LIVE_REQUIRED" >> "$REPORT"
  echo "final_status=BLOCKED_LIVE_GATE" >> "$REPORT"
  printf '%s\n' "AVB_CURRENT_STAGE=12" "AVB_CURRENT_STATUS=BLOCKED_LIVE_GATE" "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$STATE"
  exit 1
fi

if [[ "$(id -u)" -ne 0 ]]; then
  echo "root_required=FAIL" >> "$REPORT"
  echo "final_status=BLOCKED_ROOT_REQUIRED" >> "$REPORT"
  exit 1
fi

if [[ ! -f "$CONFIG" ]]; then
  echo "install_config_present=FAIL" >> "$REPORT"
  echo "final_status=BLOCKED_MISSING_INSTALL_CONFIG_RUN_STAGE_02_FIRST" >> "$REPORT"
  exit 1
fi

# shellcheck disable=SC1090
source "$CONFIG"

if [[ -z "${RUNTIME_USER:-}" ]] || ! id "$RUNTIME_USER" >/dev/null 2>&1; then
  echo "runtime_user_valid=FAIL" >> "$REPORT"
  echo "final_status=BLOCKED_RUNTIME_USER_NOT_FOUND" >> "$REPORT"
  exit 1
fi

WORKSPACE="/home/$RUNTIME_USER/.openclaw/workspace"
ENV_FILE="$WORKSPACE/.env"
if [[ ! -d "$WORKSPACE" ]]; then
  echo "workspace_present=FAIL" >> "$REPORT"
  echo "final_status=BLOCKED_WORKSPACE_NOT_FOUND_RUN_STAGE_04_FIRST" >> "$REPORT"
  exit 1
fi

TR="$WORKSPACE/skills/total-recall/scripts"
MM="$WORKSPACE/skills/memory-maintenance/scripts"

has_env_key() {
  local key="$1"
  [[ -f "$ENV_FILE" ]] && grep -Eq "^${key}=" "$ENV_FILE"
}

has_openrouter="NO"
if has_env_key OPENROUTER_API_KEY || has_env_key LLM_API_KEY; then
  has_openrouter="YES"
fi

has_gemini="NO"
if has_env_key GEMINI_API_KEY || has_env_key GOOGLE_API_KEY; then
  has_gemini="YES"
fi

CRON_FILE="/tmp/assistant-installer-cron.$$"
sudo -iu "$RUNTIME_USER" bash -lc 'crontab -l 2>/dev/null || true' > "$CRON_FILE"
sed -i '/ASSISTANT_INSTALLER_TOTAL_RECALL_START/,/ASSISTANT_INSTALLER_TOTAL_RECALL_END/d' "$CRON_FILE"
sed -i '/ASSISTANT_INSTALLER_MEMORY_MAINTENANCE_START/,/ASSISTANT_INSTALLER_MEMORY_MAINTENANCE_END/d' "$CRON_FILE"

echo "runtime_user_valid=PASS" >> "$REPORT"
echo "workspace_present=PASS" >> "$REPORT"
echo "automation_policy=CRONTAB_MARKED_IDEMPOTENT" >> "$REPORT"
echo "automation_source=OPENCLAW_WORKSPACE_INSTALLED_SKILLS" >> "$REPORT"
echo "openrouter_key_present=$has_openrouter" >> "$REPORT"
echo "gemini_key_present=$has_gemini" >> "$REPORT"

append_if_present() {
  local label="$1"
  local file="$2"
  local cron_line="$3"

  if [[ -f "$file" ]]; then
    echo "$cron_line"
    echo "${label}=CONFIGURED" >> "$REPORT"
  else
    echo "${label}=MISSING_SKIPPED" >> "$REPORT"
    missing=$((missing+1))
  fi
}

{
  echo "# ASSISTANT_INSTALLER_TOTAL_RECALL_START"
  if [[ "$has_openrouter" == "YES" ]]; then
    append_if_present "total_recall_observer_cron" "$TR/observer-agent.sh" "*/15 * * * * OPENCLAW_WORKSPACE='$WORKSPACE' bash '$TR/observer-agent.sh' >/dev/null 2>&1"
    append_if_present "total_recall_reflector_cron" "$TR/reflector-agent.sh" "17 * * * * OPENCLAW_WORKSPACE='$WORKSPACE' bash '$TR/reflector-agent.sh' >/dev/null 2>&1"
    append_if_present "total_recall_session_recovery_reboot" "$TR/session-recovery.sh" "@reboot OPENCLAW_WORKSPACE='$WORKSPACE' bash '$TR/session-recovery.sh' >/dev/null 2>&1"
    append_if_present "total_recall_watcher_reboot" "$TR/observer-watcher.sh" "@reboot OPENCLAW_WORKSPACE='$WORKSPACE' bash '$TR/observer-watcher.sh' >/dev/null 2>&1"
    append_if_present "total_recall_dream_cycle" "$TR/dream-cycle.sh" "30 3 * * * OPENCLAW_WORKSPACE='$WORKSPACE' bash '$TR/dream-cycle.sh' >/dev/null 2>&1"
  else
    echo "total_recall_automations=SKIPPED_PENDING_OPENROUTER" >> "$REPORT"
    pending_credentials=$((pending_credentials+1))
  fi
  echo "# ASSISTANT_INSTALLER_TOTAL_RECALL_END"
  echo "# ASSISTANT_INSTALLER_MEMORY_MAINTENANCE_START"
  if [[ "$has_gemini" == "YES" ]]; then
    append_if_present "memory_maintenance_review_daily" "$MM/review.sh" "45 7 * * * OPENCLAW_WORKSPACE='$WORKSPACE' bash '$MM/review.sh' >/dev/null 2>&1"
    append_if_present "memory_maintenance_cleanup_daily" "$MM/cleanup.sh" "55 7 * * * OPENCLAW_WORKSPACE='$WORKSPACE' bash '$MM/cleanup.sh' >/dev/null 2>&1"
  else
    echo "memory_maintenance_automations=SKIPPED_PENDING_GEMINI" >> "$REPORT"
    pending_credentials=$((pending_credentials+1))
  fi
  echo "# ASSISTANT_INSTALLER_MEMORY_MAINTENANCE_END"
} >> "$CRON_FILE"

sudo -iu "$RUNTIME_USER" crontab "$CRON_FILE"
rm -f "$CRON_FILE"

echo "cron_total_recall_markers=PASS" >> "$REPORT"
echo "cron_memory_maintenance_markers=PASS" >> "$REPORT"
echo "missing_automation_scripts=$missing" >> "$REPORT"
echo "pending_automation_credentials=$pending_credentials" >> "$REPORT"

if [[ "$missing" -gt 0 ]]; then
  status="PARTIAL_PASS_AUTOMATIONS_MISSING_SCRIPTS"
elif [[ "$pending_credentials" -gt 0 ]]; then
  status="PARTIAL_PASS_AUTOMATIONS_PENDING_CREDENTIALS"
fi

echo "final_status=$status" >> "$REPORT"
echo "MARKER=STAGE_12_AUTOMATIONS_${status}" >> "$REPORT"

printf '%s\n' "AVB_CURRENT_STAGE=12" "AVB_CURRENT_STATUS=$status" "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$STATE"

cat > "$HELP" <<EOH
# ChatGPT Help Context

Último tramo ejecutado: 12-automations
Estado del último tramo: $status
Tramo actual/siguiente: 13-healthcheck
Resultado general: $status
Pendientes:
- Si alguna automatización fue MISSING_SKIPPED, revisar instalación de skills.
- Si alguna automatización fue SKIPPED_PENDING_*, configurar la API key correspondiente y repetir tramo 12.
Comando recomendado para continuar:
- sudo AVB_LIVE=1 bash install.sh --run 13
Comando recomendado para reanudar:
- sudo AVB_LIVE=1 bash install.sh --resume
Archivo de reporte:
- evidence/12-automations/skills-automation-report.md
Recordatorio de seguridad:
- No pegar API keys, tokens, QR, .env, creds.json, secrets.json, cookies ni llaves privadas.
EOH

exit 0
