#!/usr/bin/env bash
set -Eeuo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
EVID="$PACK_DIR/evidence/11-memory-init"
STATE="$PACK_DIR/state/current.env"
HELP="$PACK_DIR/evidence/chatgpt-help-context.md"
CONFIG="$PACK_DIR/state/install-config.env"

mkdir -p "$EVID"

status="PASS"

{
  echo "# Tramo 11 — memory-init"
  echo
  echo "mode=LIVE_MEMORY_EMPTY_INIT"
  echo "started_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
} > "$EVID/memory-init-report.md"

if [[ "${AVB_LIVE:-0}" != "1" ]]; then
  echo "live_gate=BLOCKED_AVB_LIVE_REQUIRED" >> "$EVID/memory-init-report.md"
  echo "final_status=BLOCKED_LIVE_GATE" >> "$EVID/memory-init-report.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=11" \
  "AVB_CURRENT_STATUS=BLOCKED_LIVE_GATE" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

if [[ "$(id -u)" -ne 0 ]]; then
  echo "root_required=FAIL" >> "$EVID/memory-init-report.md"
  echo "final_status=BLOCKED_ROOT_REQUIRED" >> "$EVID/memory-init-report.md"
  exit 1
fi

if [[ ! -f "$CONFIG" ]]; then
  echo "install_config_present=FAIL" >> "$EVID/memory-init-report.md"
  echo "final_status=BLOCKED_MISSING_INSTALL_CONFIG_RUN_STAGE_02_FIRST" >> "$EVID/memory-init-report.md"
  exit 1
fi

# shellcheck disable=SC1090
source "$CONFIG"

if [[ -z "${RUNTIME_USER:-}" ]] || ! id "$RUNTIME_USER" >/dev/null 2>&1; then
  echo "runtime_user_valid=FAIL" >> "$EVID/memory-init-report.md"
  echo "final_status=BLOCKED_RUNTIME_USER_NOT_FOUND" >> "$EVID/memory-init-report.md"
  exit 1
fi

ASSISTANT_HOME="/home/$RUNTIME_USER/assistant"
WORKSPACE="/home/$RUNTIME_USER/.openclaw/workspace"
MEMORY_ROOT="$WORKSPACE/memory"
BRAIN_ROOT="$WORKSPACE/brain"
LEARNINGS_ROOT="$WORKSPACE/.learnings"
AGENTS_MEMORY="$WORKSPACE/agents/memory"

if [[ ! -d "$WORKSPACE" ]]; then
  echo "workspace_present=FAIL" >> "$EVID/memory-init-report.md"
  echo "final_status=BLOCKED_WORKSPACE_NOT_FOUND_RUN_STAGE_04_FIRST" >> "$EVID/memory-init-report.md"
  exit 1
fi
echo "workspace_present=PASS" >> "$EVID/memory-init-report.md"
BACKUP_DIR="$ASSISTANT_HOME/backups/memory-init-$(date -u +%Y%m%dT%H%M%SZ)"

echo "runtime_user=$RUNTIME_USER" >> "$EVID/memory-init-report.md"
echo "runtime_user_valid=PASS" >> "$EVID/memory-init-report.md"

mkdir -p "$BACKUP_DIR"
chown "$RUNTIME_USER:$RUNTIME_USER" "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"

for p in "$MEMORY_ROOT" "$BRAIN_ROOT" "$LEARNINGS_ROOT" "$AGENTS_MEMORY"; do
  if [[ -e "$p" ]]; then
    cp -a "$p" "$BACKUP_DIR/" 2>/dev/null || true
  fi
done

echo "backup_created=PASS" >> "$EVID/memory-init-report.md"

install -d -o "$RUNTIME_USER" -g "$RUNTIME_USER" -m 700 "$MEMORY_ROOT"
install -d -o "$RUNTIME_USER" -g "$RUNTIME_USER" -m 700 "$MEMORY_ROOT/ontology"
install -d -o "$RUNTIME_USER" -g "$RUNTIME_USER" -m 700 "$BRAIN_ROOT"
install -d -o "$RUNTIME_USER" -g "$RUNTIME_USER" -m 700 "$BRAIN_ROOT/notes"
install -d -o "$RUNTIME_USER" -g "$RUNTIME_USER" -m 700 "$LEARNINGS_ROOT"
install -d -o "$RUNTIME_USER" -g "$RUNTIME_USER" -m 700 "$AGENTS_MEMORY"

cat > "$MEMORY_ROOT/observations.md" <<'EOM'
# Observations

Estado inicial:
- Memoria vacía.
- Sin observaciones importadas.
- Sin recuerdos demo.
- Sin recuerdos heredados.
EOM

: > "$MEMORY_ROOT/ontology/graph.jsonl"

cat > "$MEMORY_ROOT/ontology/schema.yaml" <<'EOM'
version: 1
state: empty_initial_schema
entities: []
relations: []
rules:
  - do_not_create_demo_entities
  - do_not_import_previous_owner_memory
  - learn_only_from_new_owner_after_install
EOM

cat > "$BRAIN_ROOT/index.md" <<'EOM'
# Brain Index

Estado inicial:
- Sin notas importadas.
- Sin notas ficticias.
- Sin contenido heredado.
EOM

cat > "$LEARNINGS_ROOT/LEARNINGS.md" <<'EOM'
# Learnings

Estado inicial:
- Sin aprendizajes importados.
- Sin aprendizajes de otro asistente.
- Registrar solo aprendizajes futuros del nuevo usuario.
EOM

cat > "$AGENTS_MEMORY/README.md" <<'EOM'
# Agent Memory

Estado inicial:
- Memoria operativa vacía.
- No importar memoria de otra instalación.
EOM

chown -R "$RUNTIME_USER:$RUNTIME_USER" "$MEMORY_ROOT" "$BRAIN_ROOT" "$LEARNINGS_ROOT" "$AGENTS_MEMORY"
chmod -R go-rwx "$MEMORY_ROOT" "$BRAIN_ROOT" "$LEARNINGS_ROOT" "$AGENTS_MEMORY"

echo "memory_dirs_created=PASS" >> "$EVID/memory-init-report.md"
echo "observations_created=PASS" >> "$EVID/memory-init-report.md"
echo "ontology_graph_created_empty=PASS" >> "$EVID/memory-init-report.md"
echo "ontology_schema_created=PASS" >> "$EVID/memory-init-report.md"
echo "brain_index_created=PASS" >> "$EVID/memory-init-report.md"
echo "learnings_created=PASS" >> "$EVID/memory-init-report.md"
echo "agent_memory_created=PASS" >> "$EVID/memory-init-report.md"

if [[ -s "$MEMORY_ROOT/ontology/graph.jsonl" ]]; then
  echo "ontology_graph_empty=FAIL" >> "$EVID/memory-init-report.md"
  status="BLOCKED_MEMORY_GRAPH_NOT_EMPTY"
else
  echo "ontology_graph_empty=PASS" >> "$EVID/memory-init-report.md"
fi

if grep -RIl -e 'previous owner' -e 'previous-owner' -e 'runtime_user' "$MEMORY_ROOT" "$BRAIN_ROOT" "$LEARNINGS_ROOT" "$AGENTS_MEMORY" >/dev/null; then
  echo "inherited_memory_scan=FAIL" >> "$EVID/memory-init-report.md"
  status="BLOCKED_INHERITED_MEMORY_SCAN"
else
  echo "inherited_memory_scan=PASS" >> "$EVID/memory-init-report.md"
fi

{
  echo
  echo "final_status=$status"
  echo "network_used=NO"
  echo "vps_touched=YES_MEMORY_INIT"
  echo "demo_memory_created=NO"
  echo "inherited_memory_used=NO"
  echo "secrets_read=NO"
  echo "MARKER=STAGE_11_MEMORY_INIT_${status}"
} >> "$EVID/memory-init-report.md"

printf '%s\n' \
"AVB_CURRENT_STAGE=11" \
"AVB_CURRENT_STATUS=$status" \
"AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
> "$STATE"

cat > "$HELP" <<EOH
# ChatGPT Help Context

Último tramo ejecutado: 11-memory-init
Estado del último tramo: $status
Tramo actual/siguiente: 12-automations
Resultado general: $status
Pendientes:
- Configurar automatizaciones marcadas y seguras sobre el workspace OpenClaw.
Comando recomendado para continuar:
- sudo AVB_LIVE=1 bash install.sh --run 12
Comando recomendado para reanudar:
- sudo AVB_LIVE=1 bash install.sh --resume
Archivo de reporte:
- evidence/11-memory-init/memory-init-report.md
Recordatorio de seguridad:
- No pegar API keys, tokens, QR, .env, creds.json, secrets.json, cookies ni llaves privadas.
EOH

if [[ "$status" == "PASS" ]]; then
  exit 0
fi

exit 1
