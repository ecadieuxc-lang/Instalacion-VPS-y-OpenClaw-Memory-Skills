#!/usr/bin/env bash
set -Eeuo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
EVID="$PACK_DIR/evidence/08-whatsapp-patches"
STATE="$PACK_DIR/state/current.env"
HELP="$PACK_DIR/evidence/chatgpt-help-context.md"
CONFIG="$PACK_DIR/state/install-config.env"
PATCH_DIR="$PACK_DIR/patches/whatsapp-presence"

mkdir -p "$EVID"

status="PASS"

{
  echo "# Tramo 08 — whatsapp-patches"
  echo
  echo "mode=LIVE_GUARDED_WHATSAPP_PATCHES"
  echo "started_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
} > "$EVID/whatsapp-patches-report.md"

if [[ "${AVB_LIVE:-0}" != "1" ]]; then
  echo "live_gate=BLOCKED_AVB_LIVE_REQUIRED" >> "$EVID/whatsapp-patches-report.md"
  echo "final_status=BLOCKED_LIVE_GATE" >> "$EVID/whatsapp-patches-report.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=08" \
  "AVB_CURRENT_STATUS=BLOCKED_LIVE_GATE" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

if [[ "$(id -u)" -ne 0 ]]; then
  echo "root_required=FAIL" >> "$EVID/whatsapp-patches-report.md"
  echo "final_status=BLOCKED_ROOT_REQUIRED" >> "$EVID/whatsapp-patches-report.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=08" \
  "AVB_CURRENT_STATUS=BLOCKED_ROOT_REQUIRED" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

if [[ ! -f "$CONFIG" ]]; then
  echo "install_config_present=FAIL" >> "$EVID/whatsapp-patches-report.md"
  echo "final_status=BLOCKED_MISSING_INSTALL_CONFIG_RUN_STAGE_02_FIRST" >> "$EVID/whatsapp-patches-report.md"
  exit 1
fi

# shellcheck disable=SC1090
source "$CONFIG"

if [[ -z "${RUNTIME_USER:-}" ]] || ! id "$RUNTIME_USER" >/dev/null 2>&1; then
  echo "runtime_user_valid=FAIL" >> "$EVID/whatsapp-patches-report.md"
  echo "final_status=BLOCKED_RUNTIME_USER_NOT_FOUND" >> "$EVID/whatsapp-patches-report.md"
  exit 1
fi

echo "runtime_user=$RUNTIME_USER" >> "$EVID/whatsapp-patches-report.md"
echo "runtime_user_valid=PASS" >> "$EVID/whatsapp-patches-report.md"

if [[ ! -d "$PATCH_DIR" ]]; then
  echo "patch_pack_present=NO" >> "$EVID/whatsapp-patches-report.md"
  echo "patches_applied=NO" >> "$EVID/whatsapp-patches-report.md"
  status="PARTIAL_PASS_WHATSAPP_PATCHES_SKIPPED_NO_PATCH_PACK"
else
  echo "patch_pack_present=YES" >> "$EVID/whatsapp-patches-report.md"
fi

if [[ "$status" == "PASS" ]]; then
  if [[ ! -f "$PATCH_DIR/manifest.env" ]]; then
    echo "patch_manifest_present=FAIL" >> "$EVID/whatsapp-patches-report.md"
    status="BLOCKED_WHATSAPP_PATCH_MANIFEST_MISSING"
  else
    echo "patch_manifest_present=PASS" >> "$EVID/whatsapp-patches-report.md"
  fi
fi

if [[ "$status" == "PASS" ]]; then
  # shellcheck disable=SC1090
  source "$PATCH_DIR/manifest.env"

  TARGET_RELATIVE_PATH="${TARGET_RELATIVE_PATH:-}"
  EXPECTED_PATTERN="${EXPECTED_PATTERN:-}"
  PATCH_FILE="${PATCH_FILE:-}"

  if [[ -z "$TARGET_RELATIVE_PATH" || -z "$EXPECTED_PATTERN" || -z "$PATCH_FILE" ]]; then
    echo "patch_manifest_valid=FAIL" >> "$EVID/whatsapp-patches-report.md"
    status="BLOCKED_WHATSAPP_PATCH_MANIFEST_INVALID"
  else
    echo "patch_manifest_valid=PASS" >> "$EVID/whatsapp-patches-report.md"
  fi
fi

if [[ "$status" == "PASS" ]]; then
  OPENCLAW_HOME="/home/$RUNTIME_USER/.openclaw"
  TARGET_FILE="$OPENCLAW_HOME/$TARGET_RELATIVE_PATH"
  FULL_PATCH="$PATCH_DIR/$PATCH_FILE"

  if [[ ! -f "$TARGET_FILE" ]]; then
    echo "patch_target_present=FAIL" >> "$EVID/whatsapp-patches-report.md"
    status="BLOCKED_WHATSAPP_PATCH_TARGET_MISSING"
  else
    echo "patch_target_present=PASS" >> "$EVID/whatsapp-patches-report.md"
  fi

  if [[ ! -f "$FULL_PATCH" ]]; then
    echo "patch_file_present=FAIL" >> "$EVID/whatsapp-patches-report.md"
    status="BLOCKED_WHATSAPP_PATCH_FILE_MISSING"
  else
    echo "patch_file_present=PASS" >> "$EVID/whatsapp-patches-report.md"
  fi
fi

if [[ "$status" == "PASS" ]]; then
  if grep -qF "$EXPECTED_PATTERN" "$TARGET_FILE"; then
    echo "expected_pattern_present=PASS" >> "$EVID/whatsapp-patches-report.md"
  else
    echo "expected_pattern_present=FAIL" >> "$EVID/whatsapp-patches-report.md"
    status="BLOCKED_WHATSAPP_PATCH_INCOMPATIBLE"
  fi
fi

if [[ "$status" == "PASS" ]]; then
  BACKUP_DIR="/home/$RUNTIME_USER/assistant/backups/whatsapp-patches-$(date -u +%Y%m%dT%H%M%SZ)"
  mkdir -p "$BACKUP_DIR"
  cp -a "$TARGET_FILE" "$BACKUP_DIR/$(basename "$TARGET_FILE")"
  chown -R "$RUNTIME_USER:$RUNTIME_USER" "$BACKUP_DIR"
  chmod 700 "$BACKUP_DIR"

  echo "backup_created=PASS" >> "$EVID/whatsapp-patches-report.md"

  if patch --dry-run "$TARGET_FILE" "$FULL_PATCH" >> "$EVID/patch-dry-run.log" 2>&1; then
    echo "patch_dry_run=PASS" >> "$EVID/whatsapp-patches-report.md"
  else
    echo "patch_dry_run=FAIL" >> "$EVID/whatsapp-patches-report.md"
    status="BLOCKED_WHATSAPP_PATCH_DRY_RUN_FAILED"
  fi
fi

if [[ "$status" == "PASS" ]]; then
  patch "$TARGET_FILE" "$FULL_PATCH" >> "$EVID/patch-apply.log" 2>&1
  chown "$RUNTIME_USER:$RUNTIME_USER" "$TARGET_FILE"

  echo "patches_applied=YES" >> "$EVID/whatsapp-patches-report.md"
  echo "patch_marker_prefixes=WA-COMPOSING,WA-MICROPULSE" >> "$EVID/whatsapp-patches-report.md"

  if sudo -iu "$RUNTIME_USER" bash -lc '
    set -Eeuo pipefail
    export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"
    openclaw daemon restart >/dev/null 2>&1
  '; then
    echo "openclaw_daemon_restart=PASS" >> "$EVID/whatsapp-patches-report.md"
  else
    echo "openclaw_daemon_restart=WARNING_FAILED" >> "$EVID/whatsapp-patches-report.md"
    status="PARTIAL_PASS_PATCH_APPLIED_DAEMON_RESTART_FAILED"
  fi
fi

{
  echo
  echo "final_status=$status"
  echo "network_used=NO"
  echo "vps_touched=YES_IF_PATCH_APPLIED"
  echo "old_session_copied=NO"
  echo "creds_json_copied=NO"
  echo "secrets_read=NO"
  echo "MARKER=STAGE_08_WHATSAPP_PATCHES_${status}"
} >> "$EVID/whatsapp-patches-report.md"

printf '%s\n' \
"AVB_CURRENT_STAGE=08" \
"AVB_CURRENT_STATUS=$status" \
"AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
> "$STATE"

cat > "$HELP" <<EOH
# ChatGPT Help Context

Último tramo ejecutado: 08-whatsapp-patches
Estado del último tramo: $status
Tramo actual/siguiente: 09-credentials
Resultado general: $status
Pendientes:
- Si no hay patch pack, continuar sin parches o agregar pack compatible auditado.
- No aplicar parches WhatsApp a ciegas.
Comando recomendado para continuar:
- sudo AVB_LIVE=1 bash install.sh --run 09
Comando recomendado para reanudar:
- sudo AVB_LIVE=1 bash install.sh --resume
Archivo de reporte:
- evidence/08-whatsapp-patches/whatsapp-patches-report.md
Recordatorio de seguridad:
- No pegar API keys, tokens, QR, .env, creds.json, secrets.json, cookies ni llaves privadas.
EOH

if [[ "$status" == "PASS" || "$status" == PARTIAL_PASS_* ]]; then
  exit 0
fi

exit 1
