#!/usr/bin/env bash
set -Eeuo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
EVID="$PACK_DIR/evidence/14-final-report"
STATE="$PACK_DIR/state/current.env"
HELP="$PACK_DIR/evidence/chatgpt-help-context.md"
CONFIG="$PACK_DIR/state/install-config.env"

mkdir -p "$EVID"

status="PASS"

{
  echo "# Tramo 14 — final-report"
  echo
  echo "mode=LIVE_FINAL_REPORT"
  echo "started_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
} > "$EVID/final-report-stage.md"

if [[ "${AVB_LIVE:-0}" != "1" ]]; then
  echo "live_gate=BLOCKED_AVB_LIVE_REQUIRED" >> "$EVID/final-report-stage.md"
  echo "final_status=BLOCKED_LIVE_GATE" >> "$EVID/final-report-stage.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=14" \
  "AVB_CURRENT_STATUS=BLOCKED_LIVE_GATE" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

if [[ "$(id -u)" -ne 0 ]]; then
  echo "root_required=FAIL" >> "$EVID/final-report-stage.md"
  echo "final_status=BLOCKED_ROOT_REQUIRED" >> "$EVID/final-report-stage.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=14" \
  "AVB_CURRENT_STATUS=BLOCKED_ROOT_REQUIRED" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

if [[ ! -f "$CONFIG" ]]; then
  echo "install_config_present=FAIL" >> "$EVID/final-report-stage.md"
  echo "final_status=BLOCKED_MISSING_INSTALL_CONFIG_RUN_STAGE_02_FIRST" >> "$EVID/final-report-stage.md"
  exit 1
fi

# shellcheck disable=SC1090
source "$CONFIG"

if [[ -z "${RUNTIME_USER:-}" ]] || ! id "$RUNTIME_USER" >/dev/null 2>&1; then
  echo "runtime_user_valid=FAIL" >> "$EVID/final-report-stage.md"
  echo "final_status=BLOCKED_RUNTIME_USER_NOT_FOUND" >> "$EVID/final-report-stage.md"
  exit 1
fi

ASSISTANT_HOME="/home/$RUNTIME_USER/assistant"
FINAL_REPORT="$ASSISTANT_HOME/INSTALLATION_REPORT.md"
HEALTH_REPORT="$PACK_DIR/evidence/13-healthcheck/healthcheck-report.md"

install -d -o "$RUNTIME_USER" -g "$RUNTIME_USER" -m 700 "$ASSISTANT_HOME"

health_status="NOT_RUN"
if [[ -f "$HEALTH_REPORT" ]]; then
  health_status="$(grep -E '^final_status=' "$HEALTH_REPORT" | tail -n1 | cut -d= -f2- || true)"
fi

previous_statuses_file="$EVID/previous-stage-statuses.txt"
: > "$previous_statuses_file"
for d in "$PACK_DIR"/evidence/[0-9][0-9]-*; do
  [[ -d "$d" ]] || continue
  base="$(basename "$d")"
  [[ "$base" == "14-final-report" ]] && continue
  grep -RhE '^final_status=' "$d" 2>/dev/null | tail -n1 | sed "s#^#${base}:#" >> "$previous_statuses_file" || true
done

previous_partial_count="$(grep -Ec '=PARTIAL(_PASS)?|=PARTIAL_PASS_' "$previous_statuses_file" 2>/dev/null || true)"
previous_blocked_failed_count="$(grep -Ec '=BLOCKED|=FAILED|=FAIL$' "$previous_statuses_file" 2>/dev/null || true)"

echo "previous_partial_count=$previous_partial_count" >> "$EVID/final-report-stage.md"
echo "previous_blocked_failed_count=$previous_blocked_failed_count" >> "$EVID/final-report-stage.md"

if [[ "$health_status" == "NOT_RUN" ]]; then
  status="PARTIAL_PASS_FINAL_REPORT_HEALTHCHECK_NOT_RUN"
elif [[ "$health_status" != "PASS" && "$health_status" != "PASS_WITH_WARNINGS" ]]; then
  status="PARTIAL_PASS_FINAL_REPORT_HEALTHCHECK_NOT_PASS"
elif [[ "$previous_blocked_failed_count" -gt 0 ]]; then
  status="PARTIAL_PASS_FINAL_REPORT_PREVIOUS_STAGE_BLOCKED_OR_FAILED"
elif [[ "$previous_partial_count" -gt 0 ]]; then
  status="PARTIAL_PASS_FINAL_REPORT_PREVIOUS_STAGE_PARTIALS"
fi

cat > "$FINAL_REPORT" <<EOM
# Assistant VPS Base — Installation Report

Generated UTC: $(date -u +%Y-%m-%dT%H:%M:%SZ)

## Final status

Installer final report status: $status
Healthcheck status: $health_status
Healthcheck required for full PASS: yes
Previous partial stages: $previous_partial_count
Previous blocked/failed stages: $previous_blocked_failed_count

## Runtime

Runtime user: $RUNTIME_USER
Assistant home: /home/$RUNTIME_USER/assistant
OpenClaw home: /home/$RUNTIME_USER/.openclaw
OpenClaw workspace: /home/$RUNTIME_USER/.openclaw/workspace

## Installed / configured stages

- 00 audit package
- 01 preflight
- 02 system base
- 03 Tailscale + UFW guarded setup
- 04 OpenClaw install/config
- 05 OpenAI/Codex auth
- 06 personality
- 07 WhatsApp
- 08 WhatsApp patches guarded
- 09 credentials
- 10 skills
- 11 memory init
- 12 automations
- 13 healthcheck
- 14 final report

## Security notes

- No previous VPS session is copied.
- No old WhatsApp creds are copied.
- No QR is written to evidence.
- No API key value is written to evidence.
- Runtime memory starts empty unless the new user teaches it later.
- Optional stages may be skipped and reported as partial pass.

## Useful commands

\`\`\`bash
sudo AVB_LIVE=1 bash install.sh --status
sudo AVB_LIVE=1 bash install.sh --resume
sudo AVB_LIVE=1 bash install.sh --run 13
\`\`\`
EOM

chown "$RUNTIME_USER:$RUNTIME_USER" "$FINAL_REPORT"
chmod 600 "$FINAL_REPORT"

echo "runtime_user=$RUNTIME_USER" >> "$EVID/final-report-stage.md"
echo "runtime_user_valid=PASS" >> "$EVID/final-report-stage.md"

DOCS_DIR="$ASSISTANT_HOME/docs"
install -d -o "$RUNTIME_USER" -g "$RUNTIME_USER" -m 700 "$DOCS_DIR"

cat > "$DOCS_DIR/ASSISTANT_VPS_STATE.md" <<EOM
# Assistant VPS State

Generated UTC: $(date -u +%Y-%m-%dT%H:%M:%SZ)

Runtime user: $RUNTIME_USER
Assistant home: /home/$RUNTIME_USER/assistant
OpenClaw home: /home/$RUNTIME_USER/.openclaw
OpenClaw workspace: /home/$RUNTIME_USER/.openclaw/workspace
Workspace memory: /home/$RUNTIME_USER/.openclaw/workspace/memory
Workspace skills: /home/$RUNTIME_USER/.openclaw/workspace/skills
Workspace skill env: /home/$RUNTIME_USER/.openclaw/workspace/.env
Healthcheck status: $health_status
Healthcheck required for full PASS: yes
Previous partial stages: $previous_partial_count
Previous blocked/failed stages: $previous_blocked_failed_count
Installer final status: $status

Security:
- No previous credentials copied.
- No previous WhatsApp session copied.
- No previous memory copied.
- Gateway expected local/loopback.
EOM

cat > "$DOCS_DIR/SKILLS_STATE.md" <<EOM
# Skills State

Expected bundled skills:

- ontology
- total-recall
- 2nd-brain
- mindmap-generator
- memory-maintenance
- self-improving-agent

Install policy:
- local bundled source only;
- OpenClaw official install command;
- no ClawHub/latest fallback;
- new agent starts with empty memory.

Credential policy:
- Gemini/Google key: new user only, if configured.
- OpenRouter key: new user only, if configured.
- No key values are written here.
EOM

chown "$RUNTIME_USER:$RUNTIME_USER" "$DOCS_DIR/ASSISTANT_VPS_STATE.md" "$DOCS_DIR/SKILLS_STATE.md"
chmod 600 "$DOCS_DIR/ASSISTANT_VPS_STATE.md" "$DOCS_DIR/SKILLS_STATE.md"

echo "assistant_vps_state_written=PASS" >> "$EVID/final-report-stage.md"
echo "skills_state_written=PASS" >> "$EVID/final-report-stage.md"

echo "installation_report_written=PASS" >> "$EVID/final-report-stage.md"
echo "healthcheck_status=$health_status" >> "$EVID/final-report-stage.md"

{
  echo
  echo "final_status=$status"
  echo "network_used=NO"
  echo "vps_touched=YES_FINAL_REPORT"
  echo "secrets_read=NO"
  echo "secret_values_written_to_evidence=NO"
  echo "qr_logged_to_evidence=NO"
  echo "MARKER=STAGE_14_FINAL_REPORT_${status}"
} >> "$EVID/final-report-stage.md"

printf '%s\n' \
"AVB_CURRENT_STAGE=14" \
"AVB_CURRENT_STATUS=$status" \
"AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
> "$STATE"

cat > "$HELP" <<EOH
# ChatGPT Help Context

Último tramo ejecutado: 14-final-report
Estado del último tramo: $status
Resultado general: $status
Archivo de reporte final:
- /home/$RUNTIME_USER/assistant/INSTALLATION_REPORT.md
Archivo de reporte del tramo:
- evidence/14-final-report/final-report-stage.md
Recordatorio de seguridad:
- No pegar API keys, tokens, QR, .env, creds.json, secrets.json, cookies ni llaves privadas.
EOH

if [[ "$status" == "PASS" || "$status" == PARTIAL_PASS_* ]]; then
  exit 0
fi

exit 1
