#!/usr/bin/env bash
set -Eeuo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
EVID="$PACK_DIR/evidence/13-healthcheck"
STATE="$PACK_DIR/state/current.env"
HELP="$PACK_DIR/evidence/chatgpt-help-context.md"
CONFIG="$PACK_DIR/state/install-config.env"

mkdir -p "$EVID"

status="PASS"
critical_failures=0
warnings=0

{
  echo "# Tramo 13 — healthcheck"
  echo
  echo "mode=LIVE_FINAL_HEALTHCHECK"
  echo "started_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
} > "$EVID/healthcheck-report.md"

fail_critical() {
  echo "$1=FAIL" >> "$EVID/healthcheck-report.md"
  critical_failures=$((critical_failures+1))
}

pass_check() {
  echo "$1=PASS" >> "$EVID/healthcheck-report.md"
}

warn_check() {
  echo "$1=WARNING" >> "$EVID/healthcheck-report.md"
  warnings=$((warnings+1))
}

scan_targets_for_inherited_identifiers() {
  local n
  local -a targets=("$@")
  local -a needles=(
    "/home/previous-owner/.s""sh"
    "ro""y_vps_""ed25519"
    "137.184.""135.47"
    "100.89.""198.28"
    "duck""dns"
    "com.r""oy.app"
  )

  for n in "${needles[@]}"; do
    if grep -RIlF -- "$n" "${targets[@]}" 2>/dev/null; then
      return 0
    fi
  done

  return 1
}

if [[ "${AVB_LIVE:-0}" != "1" ]]; then
  echo "live_gate=BLOCKED_AVB_LIVE_REQUIRED" >> "$EVID/healthcheck-report.md"
  echo "final_status=BLOCKED_LIVE_GATE" >> "$EVID/healthcheck-report.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=13" \
  "AVB_CURRENT_STATUS=BLOCKED_LIVE_GATE" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

if [[ "$(id -u)" -ne 0 ]]; then
  echo "root_required=FAIL" >> "$EVID/healthcheck-report.md"
  echo "final_status=BLOCKED_ROOT_REQUIRED" >> "$EVID/healthcheck-report.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=13" \
  "AVB_CURRENT_STATUS=BLOCKED_ROOT_REQUIRED" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

if [[ ! -f "$CONFIG" ]]; then
  echo "install_config_present=FAIL" >> "$EVID/healthcheck-report.md"
  echo "final_status=BLOCKED_MISSING_INSTALL_CONFIG_RUN_STAGE_02_FIRST" >> "$EVID/healthcheck-report.md"
  exit 1
fi

# shellcheck disable=SC1090
source "$CONFIG"

if [[ -n "${RUNTIME_USER:-}" ]] && id "$RUNTIME_USER" >/dev/null 2>&1; then
  pass_check "runtime_user_valid"
else
  fail_critical "runtime_user_valid"
fi

echo "runtime_user=${RUNTIME_USER:-MISSING}" >> "$EVID/healthcheck-report.md"

for f in "$PACK_DIR"/scripts/*.sh "$PACK_DIR/install.sh"; do
  if bash -n "$f"; then
    echo "bash_n_$(basename "$f")=PASS" >> "$EVID/bash-n-results.txt"
  else
    echo "bash_n_$(basename "$f")=FAIL" >> "$EVID/bash-n-results.txt"
    critical_failures=$((critical_failures+1))
  fi
done

if grep -q '=FAIL' "$EVID/bash-n-results.txt"; then
  fail_critical "all_scripts_bash_n"
else
  pass_check "all_scripts_bash_n"
fi

if find "$PACK_DIR" -type f -perm /111 -print -quit | grep -q .; then
  fail_critical "unexpected_executables"
else
  pass_check "unexpected_executables"
fi

if scan_targets_for_inherited_identifiers "$PACK_DIR" >/dev/null; then
  fail_critical "live_state_contamination"
else
  pass_check "live_state_contamination"
fi

if [[ -n "${RUNTIME_USER:-}" ]] && id "$RUNTIME_USER" >/dev/null 2>&1; then
  RUNTIME_HOME="/home/$RUNTIME_USER"
  OPENCLAW_HOME="$RUNTIME_HOME/.openclaw"
  WORKSPACE="$OPENCLAW_HOME/workspace"
  ASSISTANT_HOME="$RUNTIME_HOME/assistant"

  if sudo -iu "$RUNTIME_USER" bash -lc 'export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"; command -v openclaw >/dev/null 2>&1'; then
    pass_check "openclaw_command"
  else
    fail_critical "openclaw_command"
  fi

  if sudo -iu "$RUNTIME_USER" bash -lc 'export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"; openclaw --version >/dev/null 2>&1'; then
    pass_check "openclaw_version_command"
    sudo -iu "$RUNTIME_USER" bash -lc 'export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"; openclaw --version' > "$EVID/openclaw-version.txt" 2>&1 || true
  else
    fail_critical "openclaw_version_command"
  fi

  if python3 - "$OPENCLAW_HOME/openclaw.json" <<'PY'
import json, sys
from pathlib import Path
p = Path(sys.argv[1])
data = json.loads(p.read_text())
primary = data.get("agents", {}).get("defaults", {}).get("model", {}).get("primary")
keys = data.get("agents", {}).get("defaults", {}).get("models_keys", [])
raise SystemExit(0 if primary == "openai/gpt-5.5" and "openai/gpt-5.5" in keys else 1)
PY
  then
    pass_check "openclaw_model_gpt55_config"
  else
    fail_critical "openclaw_model_gpt55_config"
  fi

  if python3 - "$OPENCLAW_HOME/openclaw.json" <<'PY'
import json, sys
from pathlib import Path
data = json.loads(Path(sys.argv[1]).read_text())
providers = data.get("auth", {}).get("profile_providers", [])
raise SystemExit(0 if "openai" in providers else 1)
PY
  then
    pass_check "openai_oauth_provider_config"
  else
    fail_critical "openai_oauth_provider_config"
  fi

  if sudo -iu "$RUNTIME_USER" bash -lc 'export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"; openclaw models status --probe --probe-provider openai >/dev/null 2>&1'; then
    pass_check "openai_oauth_runtime_probe"
  else
    fail_critical "openai_oauth_runtime_probe"
  fi

  if python3 - "$OPENCLAW_HOME/openclaw.json" <<'PY'
import json, sys
from pathlib import Path
data = json.loads(Path(sys.argv[1]).read_text())
wa = data.get("channels", {}).get("whatsapp", {})
cmd = data.get("commands", {})
ok = (
  wa.get("enabled") is True
  and wa.get("dmPolicy") == "allowlist"
  and isinstance(wa.get("allowFrom"), list)
  and len(wa.get("allowFrom")) > 0
  and wa.get("groupPolicy") == "disabled"
  and isinstance(cmd.get("ownerAllowFrom"), list)
  and len(cmd.get("ownerAllowFrom")) > 0
)
raise SystemExit(0 if ok else 1)
PY
  then
    pass_check "whatsapp_allowlist_owner_config"
  else
    warn_check "whatsapp_allowlist_owner_config"
  fi

  if command -v tailscale >/dev/null 2>&1 && tailscale status >/dev/null 2>&1; then
    pass_check "tailscale_status"
  else
    warn_check "tailscale_status"
  fi

  if command -v ufw >/dev/null 2>&1 && ufw status | grep -qi '^Status: active'; then
    pass_check "ufw_active"
  else
    warn_check "ufw_active"
  fi

  [[ -f "$OPENCLAW_HOME/openclaw.json" ]] && pass_check "openclaw_json_present" || warn_check "openclaw_json_present"
  [[ -d "$WORKSPACE" ]] && pass_check "workspace_present" || warn_check "workspace_present"

  for md in AGENTS.md SOUL.md USER.md IDENTITY.md TOOLS.md HEARTBEAT.md MEMORY.md; do
    if [[ -f "$WORKSPACE/$md" ]]; then
      echo "workspace_${md}=PASS" >> "$EVID/workspace-files.txt"
    else
      echo "workspace_${md}=WARNING_MISSING" >> "$EVID/workspace-files.txt"
      warnings=$((warnings+1))
    fi
  done

  [[ -d "$ASSISTANT_HOME" ]] && pass_check "assistant_home_present" || warn_check "assistant_home_present"
  [[ -d "$WORKSPACE/memory" ]] && pass_check "workspace_memory_present" || warn_check "workspace_memory_present"
  [[ -f "$WORKSPACE/memory/observations.md" ]] && pass_check "observations_present" || warn_check "observations_present"
  [[ -f "$WORKSPACE/memory/ontology/graph.jsonl" ]] && pass_check "ontology_graph_present" || warn_check "ontology_graph_present"
  [[ -f "$WORKSPACE/.env" ]] && pass_check "workspace_env_present_or_created" || warn_check "workspace_env_present_or_created"

  if sudo -iu "$RUNTIME_USER" bash -lc 'export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"; openclaw skills list >/dev/null 2>&1'; then
    pass_check "openclaw_skills_list"
  else
    warn_check "openclaw_skills_list"
  fi



  missing_skill_dirs=0
  for skill in ontology total-recall 2nd-brain mindmap-generator memory-maintenance self-improving-agent; do
    if [[ -f "$WORKSPACE/skills/$skill/SKILL.md" ]]; then
      echo "workspace_skill_${skill}=PASS" >> "$EVID/skills-dirs.txt"
    else
      echo "workspace_skill_${skill}=FAIL" >> "$EVID/skills-dirs.txt"
      missing_skill_dirs=$((missing_skill_dirs+1))
    fi
  done

  if [[ "$missing_skill_dirs" -eq 0 ]]; then
    pass_check "workspace_skills_6_present"
  else
    fail_critical "workspace_skills_6_present"
  fi

  if sudo -iu "$RUNTIME_USER" bash -lc 'export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"; openclaw channels status --channel whatsapp >/dev/null 2>&1'; then
    pass_check "whatsapp_status_command"
  else
    warn_check "whatsapp_status_command"
  fi

  if scan_targets_for_inherited_identifiers "$OPENCLAW_HOME" "$ASSISTANT_HOME" >/dev/null 2>&1; then
    fail_critical "runtime_inherited_identifier_scan"
  else
    pass_check "runtime_inherited_identifier_scan"
  fi
fi

if [[ -n "${RUNTIME_USER:-}" ]] && id "$RUNTIME_USER" >/dev/null 2>&1; then
  CRON_DUMP="$EVID/runtime-crontab.txt"
  sudo -iu "$RUNTIME_USER" bash -lc 'crontab -l 2>/dev/null || true' > "$CRON_DUMP"

  if grep -q ASSISTANT_INSTALLER_TOTAL_RECALL_START "$CRON_DUMP"; then
    pass_check "total_recall_cron_markers"
  else
    warn_check "total_recall_cron_markers"
  fi

  if grep -q ASSISTANT_INSTALLER_MEMORY_MAINTENANCE_START "$CRON_DUMP"; then
    pass_check "memory_maintenance_cron_markers"
  else
    warn_check "memory_maintenance_cron_markers"
  fi

  for cron_name in \
    observer-agent.sh \
    reflector-agent.sh \
    session-recovery.sh \
    observer-watcher.sh \
    dream-cycle.sh \
    memory-maintenance/scripts/review.sh \
    memory-maintenance/scripts/cleanup.sh
  do
    safe_name="${cron_name//\//_}"
    safe_name="${safe_name//./_}"
    if grep -qF "$cron_name" "$CRON_DUMP"; then
      pass_check "cron_${safe_name}"
    else
      warn_check "cron_${safe_name}"
    fi
  done
fi

echo "critical_failures=$critical_failures" >> "$EVID/healthcheck-report.md"
echo "warnings=$warnings" >> "$EVID/healthcheck-report.md"

if [[ "$critical_failures" -eq 0 && "$warnings" -eq 0 ]]; then
  status="PASS"
elif [[ "$critical_failures" -eq 0 ]]; then
  status="PASS_WITH_WARNINGS"
else
  status="FAIL"
fi

{
  echo
  echo "final_status=$status"
  echo "network_used=NO_DIRECT_INSTALL"
  echo "vps_touched=READONLY_CHECKS_PLUS_LOCAL_STATUS"
  echo "secrets_read=NO"
  echo "secret_values_written_to_evidence=NO"
  echo "qr_logged_to_evidence=NO"
  echo "MARKER=STAGE_13_HEALTHCHECK_${status}"
} >> "$EVID/healthcheck-report.md"

printf '%s\n' \
"AVB_CURRENT_STAGE=13" \
"AVB_CURRENT_STATUS=$status" \
"AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
> "$STATE"

cat > "$HELP" <<EOH
# ChatGPT Help Context

Último tramo ejecutado: 13-healthcheck
Estado del último tramo: $status
Tramo actual/siguiente: 14-final-report
Resultado general: $status
Pendientes:
- Si hay FAIL, revisar evidence/13-healthcheck/healthcheck-report.md antes de empaquetar.
- Si solo hay WARNING, puede ser por pasos opcionales saltados.
Comando recomendado para continuar:
- sudo AVB_LIVE=1 bash install.sh --run 14
Comando recomendado para reanudar:
- sudo AVB_LIVE=1 bash install.sh --resume
Archivo de reporte:
- evidence/13-healthcheck/healthcheck-report.md
Recordatorio de seguridad:
- No pegar API keys, tokens, QR, .env, creds.json, secrets.json, cookies ni llaves privadas.
EOH

if [[ "$status" == "PASS" || "$status" == "PASS_WITH_WARNINGS" ]]; then
  exit 0
fi

exit 1
