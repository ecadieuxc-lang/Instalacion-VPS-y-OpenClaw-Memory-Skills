#!/usr/bin/env bash
set -Eeuo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
EVID="$PACK_DIR/evidence/07-whatsapp"
STATE="$PACK_DIR/state/current.env"
HELP="$PACK_DIR/evidence/chatgpt-help-context.md"
CONFIG="$PACK_DIR/state/install-config.env"

mkdir -p "$EVID"

status="PASS"

{
  echo "# Tramo 07 — whatsapp"
  echo
  echo "mode=LIVE_INTERACTIVE_WHATSAPP_QR"
  echo "started_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
} > "$EVID/whatsapp-report.md"

if [[ "${AVB_LIVE:-0}" != "1" ]]; then
  echo "live_gate=BLOCKED_AVB_LIVE_REQUIRED" >> "$EVID/whatsapp-report.md"
  echo "final_status=BLOCKED_LIVE_GATE" >> "$EVID/whatsapp-report.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=07" \
  "AVB_CURRENT_STATUS=BLOCKED_LIVE_GATE" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

if [[ "$(id -u)" -ne 0 ]]; then
  echo "root_required=FAIL" >> "$EVID/whatsapp-report.md"
  echo "final_status=BLOCKED_ROOT_REQUIRED" >> "$EVID/whatsapp-report.md"
  printf '%s\n' \
  "AVB_CURRENT_STAGE=07" \
  "AVB_CURRENT_STATUS=BLOCKED_ROOT_REQUIRED" \
  "AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "$STATE"
  exit 1
fi

if [[ ! -f "$CONFIG" ]]; then
  echo "install_config_present=FAIL" >> "$EVID/whatsapp-report.md"
  echo "final_status=BLOCKED_MISSING_INSTALL_CONFIG_RUN_STAGE_02_FIRST" >> "$EVID/whatsapp-report.md"
  exit 1
fi

# shellcheck disable=SC1090
source "$CONFIG"

if [[ -z "${RUNTIME_USER:-}" ]] || ! id "$RUNTIME_USER" >/dev/null 2>&1; then
  echo "runtime_user_valid=FAIL" >> "$EVID/whatsapp-report.md"
  echo "final_status=BLOCKED_RUNTIME_USER_NOT_FOUND" >> "$EVID/whatsapp-report.md"
  exit 1
fi

echo "runtime_user=$RUNTIME_USER" >> "$EVID/whatsapp-report.md"
echo "runtime_user_valid=PASS" >> "$EVID/whatsapp-report.md"

if ! sudo -iu "$RUNTIME_USER" bash -lc 'export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"; command -v openclaw >/dev/null 2>&1'; then
  echo "openclaw_command=FAIL" >> "$EVID/whatsapp-report.md"
  echo "final_status=BLOCKED_OPENCLAW_NOT_FOUND_RUN_STAGE_04_FIRST" >> "$EVID/whatsapp-report.md"
  exit 1
else
  echo "openclaw_command=PASS" >> "$EVID/whatsapp-report.md"
fi

echo
echo "Este tramo configurará WhatsApp nuevo para este asistente."
echo "No se copia sesión vieja, creds.json, QR viejo, número anterior ni datos de otro VPS."
echo "El QR aparecerá en la terminal. No lo pegues en ChatGPT."
echo

read -r -p "¿Configurar WhatsApp ahora? Escribe SI para continuar o ENTER para saltar: " CONFIRM_WA

if [[ "$CONFIRM_WA" != "SI" ]]; then
  echo "whatsapp_setup=SKIPPED_BY_USER" >> "$EVID/whatsapp-report.md"
  status="PARTIAL_PASS_WHATSAPP_SKIPPED_BY_USER"
else
  read -r -p "Número dueño/allowlist en formato E.164. Ej: +569XXXXXXXX: " OWNER_PHONE

  if ! [[ "$OWNER_PHONE" =~ ^\+[1-9][0-9]{7,14}$ ]]; then
    echo "owner_phone_valid=FAIL" >> "$EVID/whatsapp-report.md"
    echo "final_status=BLOCKED_INVALID_OWNER_PHONE_E164" >> "$EVID/whatsapp-report.md"
    exit 1
  fi

  umask 077
  {
    grep -v '^OWNER_PHONE=' "$CONFIG" 2>/dev/null || true
    printf 'OWNER_PHONE=%q\n' "$OWNER_PHONE"
  } > "$CONFIG.tmp"
  mv "$CONFIG.tmp" "$CONFIG"
  chmod 600 "$CONFIG"

  echo "owner_phone_valid=PASS" >> "$EVID/whatsapp-report.md"
  echo "owner_phone_saved_masked=YES" >> "$EVID/whatsapp-report.md"

  echo
  echo "Instalando/agregando canal WhatsApp si falta."
  echo "La salida interactiva no se guardará en evidence para evitar QR o material sensible."
  echo

  sudo -iu "$RUNTIME_USER" bash -lc '
    set -Eeuo pipefail
    export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"
    openclaw channels add --channel whatsapp
  ' || {
    echo "whatsapp_channel_add=FAIL" >> "$EVID/whatsapp-report.md"
    status="BLOCKED_WHATSAPP_CHANNEL_ADD_FAILED"
  }

  if [[ "$status" == "PASS" ]]; then
    echo "whatsapp_channel_add=PASS" >> "$EVID/whatsapp-report.md"

    OPENCLAW_JSON="/home/$RUNTIME_USER/.openclaw/openclaw.json"

    if [[ -f "$OPENCLAW_JSON" ]]; then
      cp -a "$OPENCLAW_JSON" "$OPENCLAW_JSON.before-stage07-$(date -u +%Y%m%dT%H%M%SZ)"

      python3 - "$OPENCLAW_JSON" "$OWNER_PHONE" <<'PY'
import json, sys
from pathlib import Path

path = Path(sys.argv[1])
owner_phone = sys.argv[2]

try:
    data = json.loads(path.read_text())
except Exception:
    data = {}

channels = data.setdefault("channels", {})
wa = channels.setdefault("whatsapp", {})

wa["enabled"] = True
wa["dmPolicy"] = "allowlist"
wa["groupPolicy"] = "disabled"
wa["allowFrom"] = [owner_phone]
wa["ownerAllowFrom"] = [owner_phone]  # compatibility note; command owner is also set below
wa.pop("allowlist", None)
wa["notes"] = {
    "managedBy": "assistant-vps-base installer",
    "sessionPolicy": "new session only",
    "doNotCopy": ["creds.json", "old QR", "old WhatsApp session"],
    "accessPolicy": "dmPolicy=allowlist + allowFrom + groupPolicy=disabled"
}

plugins = data.setdefault("plugins", {})
allow = plugins.get("allow")
if not isinstance(allow, list):
    allow = []
for plugin in ["codex", "whatsapp"]:
    if plugin not in allow:
        allow.append(plugin)
plugins["allow"] = allow

commands = data.setdefault("commands", {})
owners = commands.get("ownerAllowFrom")
if not isinstance(owners, list):
    owners = []
owner_scoped = f"whatsapp:{owner_phone}"
if owner_scoped not in owners:
    owners.append(owner_scoped)
commands["ownerAllowFrom"] = owners

path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
PY

      chown "$RUNTIME_USER:$RUNTIME_USER" "$OPENCLAW_JSON"
      chmod 600 "$OPENCLAW_JSON"
      echo "whatsapp_config_written=PASS" >> "$EVID/whatsapp-report.md"
      echo "dm_policy_allowlist=PASS" >> "$EVID/whatsapp-report.md"
      echo "group_policy_disabled=PASS" >> "$EVID/whatsapp-report.md"

      if sudo -iu "$RUNTIME_USER" bash -lc '
        set -Eeuo pipefail
        export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"
        openclaw daemon restart >/dev/null 2>&1
      '; then
        echo "openclaw_daemon_restart_after_whatsapp_config=PASS" >> "$EVID/whatsapp-report.md"
      else
        echo "openclaw_daemon_restart_after_whatsapp_config=WARNING_FAILED" >> "$EVID/whatsapp-report.md"
      fi
    else
      echo "whatsapp_config_written=WARNING_OPENCLAW_JSON_NOT_FOUND" >> "$EVID/whatsapp-report.md"
      status="PARTIAL_WHATSAPP_CONFIG_PENDING_OPENCLAW_JSON"
    fi
  fi

  if [[ "$status" == "PASS" ]]; then
    echo
    echo "Ahora se iniciará login WhatsApp."
    echo "Escanea el QR desde WhatsApp > Dispositivos vinculados."
    echo "No pegues QR, pantallazos ni archivos de sesión en ChatGPT."
    echo

    sudo -iu "$RUNTIME_USER" bash -lc '
      set -Eeuo pipefail
      export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"
      openclaw channels login --channel whatsapp
    ' || {
      echo "whatsapp_login=PARTIAL_OR_FAILED" >> "$EVID/whatsapp-report.md"
      status="PARTIAL_PASS_WHATSAPP_LOGIN_PENDING"
    }

    if [[ "$status" == "PASS" ]]; then
      echo "whatsapp_login=COMPLETED_INTERACTIVE" >> "$EVID/whatsapp-report.md"
      if sudo -iu "$RUNTIME_USER" bash -lc '
        set -Eeuo pipefail
        export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"
        openclaw daemon restart >/dev/null 2>&1
      '; then
        echo "openclaw_daemon_restart_after_whatsapp_login=PASS" >> "$EVID/whatsapp-report.md"
      else
        echo "openclaw_daemon_restart_after_whatsapp_login=WARNING_FAILED" >> "$EVID/whatsapp-report.md"
      fi
    fi
  fi

  if sudo -iu "$RUNTIME_USER" bash -lc '
    set -Eeuo pipefail
    export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:$PATH"
    openclaw channels status --channel whatsapp >/dev/null 2>&1
  '; then
    echo "whatsapp_status_command=PASS" >> "$EVID/whatsapp-report.md"
  else
    echo "whatsapp_status_command=WARNING_OR_UNAVAILABLE" >> "$EVID/whatsapp-report.md"
  fi
fi

{
  echo
  echo "final_status=$status"
  echo "network_used=YES_WHATSAPP_IF_CONFIRMED"
  echo "vps_touched=YES_WHATSAPP_IF_CONFIRMED"
  echo "old_session_copied=NO"
  echo "qr_logged_to_evidence=NO"
  echo "creds_json_copied=NO"
  echo "secrets_read=NO"
  echo "MARKER=STAGE_07_WHATSAPP_${status}"
} >> "$EVID/whatsapp-report.md"

printf '%s\n' \
"AVB_CURRENT_STAGE=07" \
"AVB_CURRENT_STATUS=$status" \
"AVB_UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
> "$STATE"

cat > "$HELP" <<EOH
# ChatGPT Help Context

Último tramo ejecutado: 07-whatsapp
Estado del último tramo: $status
Tramo actual/siguiente: 08-whatsapp-patches
Resultado general: $status
Pendientes:
- Si WhatsApp quedó pendiente, repetir tramo 07 y escanear QR nuevo.
- No copiar creds.json ni sesiones antiguas.
- No pegar QR ni pantallazos en ChatGPT.
Comando recomendado para continuar:
- sudo AVB_LIVE=1 bash install.sh --run 08
Comando recomendado para reanudar:
- sudo AVB_LIVE=1 bash install.sh --resume
Archivo de reporte:
- evidence/07-whatsapp/whatsapp-report.md
Recordatorio de seguridad:
- No pegar API keys, tokens, QR, .env, creds.json, secrets.json, cookies ni llaves privadas.
EOH

if [[ "$status" == "PASS" || "$status" == PARTIAL_PASS_* || "$status" == PARTIAL_WHATSAPP_* ]]; then
  exit 0
fi

exit 1
