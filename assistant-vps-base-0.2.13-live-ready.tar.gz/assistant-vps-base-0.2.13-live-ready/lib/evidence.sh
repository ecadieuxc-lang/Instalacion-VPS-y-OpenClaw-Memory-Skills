#!/usr/bin/env bash
set -Eeuo pipefail

avb_evidence_dir() {
  local stage="$1"
  printf "%s/evidence/%s\n" "$(avb_pack_root)" "$stage"
}

avb_evidence_init() {
  local stage="$1"
  mkdir -p "$(avb_evidence_dir "$stage")"
}

avb_evidence_write_summary() {
  local stage="$1"
  local status="$2"
  local dir
  dir="$(avb_evidence_dir "$stage")"
  mkdir -p "$dir"
  printf "%s\n" "# Evidence — $stage" "" "status=$status" "updated_at=$(avb_timestamp_utc)" > "$dir/summary.md"
}

avb_evidence_append() {
  local stage="$1"
  local message="$2"
  local dir
  dir="$(avb_evidence_dir "$stage")"
  mkdir -p "$dir"
  printf "%s %s\n" "$(avb_timestamp_utc)" "$message" >> "$dir/events.log"
}

return 0 2>/dev/null || true
