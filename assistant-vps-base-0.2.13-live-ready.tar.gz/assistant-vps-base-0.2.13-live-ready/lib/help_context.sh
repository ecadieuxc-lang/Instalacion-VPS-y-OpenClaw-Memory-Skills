#!/usr/bin/env bash
set -Eeuo pipefail

avb_help_context_file() {
  printf "%s/evidence/chatgpt-help-context.md\n" "$(avb_pack_root)"
}

avb_help_context_write() {
  local stage="$1"
  local status="$2"
  local next_stage="$3"
  local file
  file="$(avb_help_context_file)"
  mkdir -p "$(dirname "$file")"
  printf "%s\n" "# chatgpt-help-context.md" "" "## Estado actual" "- Ultimo tramo ejecutado: $stage" "- Estado ultimo tramo: $status" "- Siguiente tramo recomendado: $next_stage" "" "## Seguridad" "- No pegar API keys." "- No pegar tokens." "- No pegar QR." "- No pegar .env reales." "- No pegar llaves SSH privadas." > "$file"
}

return 0 2>/dev/null || true
