#!/usr/bin/env bash
set -Eeuo pipefail

avb_state_file() {
  printf "%s/state/current.env\n" "$(avb_pack_root)"
}

avb_state_init() {
  local file
  file="$(avb_state_file)"
  mkdir -p "$(dirname "$file")"
  test -f "$file" || printf "%s\n" "AVB_CURRENT_STAGE=00" "AVB_CURRENT_STATUS=PENDING" > "$file"
}

avb_state_write() {
  local stage="$1"
  local status="$2"
  local file
  file="$(avb_state_file)"
  mkdir -p "$(dirname "$file")"
  printf "%s\n" "AVB_CURRENT_STAGE=$stage" "AVB_CURRENT_STATUS=$status" "AVB_UPDATED_AT=$(avb_timestamp_utc)" > "$file"
}

avb_state_read() {
  local file
  file="$(avb_state_file)"
  test -f "$file" && cat "$file" || true
}

return 0 2>/dev/null || true
