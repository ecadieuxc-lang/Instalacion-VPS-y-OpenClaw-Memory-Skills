#!/usr/bin/env bash
set -Eeuo pipefail

avb_redact_line() {
  sed -E "s/([A-Za-z0-9_]*(KEY|TOKEN|SECRET|PASSWORD)[A-Za-z0-9_]*[[:space:]]*=).+/\1[REDACTED]/g"
}

avb_secret_scan_generic() {
  local root="$1"
  grep -RInE "BEGIN (RSA|OPENSSH|EC) PRIVATE KEY|[A-Za-z0-9_]*(API_KEY|TOKEN|SECRET|PASSWORD)[A-Za-z0-9_]*[[:space:]]*=|\"(access_token|refresh_token|api_key|password|secret)\"[[:space:]]*:" "$root" 2>/dev/null || true
}

avb_secret_scan_should_be_empty() {
  local root="$1"
  test -z "$(avb_secret_scan_generic "$root")"
}

return 0 2>/dev/null || true
