#!/usr/bin/env bash
set -Eeuo pipefail

avb_validate_file_exists() {
  local file="$1"
  test -f "$file"
}

avb_validate_dir_exists() {
  local dir="$1"
  test -d "$dir"
}

avb_validate_no_executables() {
  local root="$1"
  ! find "$root" -type f -perm /111 | grep -q .
}

avb_validate_bash_syntax_tree() {
  local root="$1"
  find "$root" -type f -name "*.sh" -print0 | xargs -0 -r bash -n
}

avb_validation_result() {
  local name="$1"
  local status="$2"
  printf "%s=%s\n" "$name" "$status"
}

return 0 2>/dev/null || true
