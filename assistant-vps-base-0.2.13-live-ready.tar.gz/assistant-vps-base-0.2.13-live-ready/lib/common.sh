#!/usr/bin/env bash
set -Eeuo pipefail

avb_timestamp_utc() {
  date -u +%Y-%m-%dT%H:%M:%SZ
}

avb_log() {
  printf "%s %s\n" "$(avb_timestamp_utc)" "$*"
}

avb_die() {
  avb_log "ERROR: $*"
  return 1
}

avb_require_dir() {
  test -d "$1" || avb_die "missing directory: $1"
}

avb_require_file() {
  test -f "$1" || avb_die "missing file: $1"
}

avb_pack_root() {
  cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd
}

avb_assert_no_runtime_execution() {
  : "${AVB_ALLOW_RUNTIME_EXECUTION:=0}"
  test "$AVB_ALLOW_RUNTIME_EXECUTION" = "1" || avb_die "runtime execution not enabled"
}

return 0 2>/dev/null || true
