#!/usr/bin/env bash
set -Eeuo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STATE="$PACK_DIR/state/current.env"

mkdir -p "$PACK_DIR/state" "$PACK_DIR/evidence" "$PACK_DIR/logs"

usage() {
  cat <<USAGE
assistant-vps-base 0.2.13-live-ready

Uso:
  bash install.sh --list
  bash install.sh --status
  bash install.sh --run 00
  bash install.sh --run 01
  sudo AVB_LIVE=1 bash install.sh --run 02
  bash install.sh --resume

Notas:
  - 00 y 01 son de solo lectura.
  - 02 modifica sistema y exige root + AVB_LIVE=1.
  - No pegues API keys, tokens, QR, .env, creds.json ni llaves privadas en ChatGPT.
USAGE
}

stage_script() {
  case "$1" in
    00) echo "$PACK_DIR/scripts/00-audit-package.sh" ;;
    01) echo "$PACK_DIR/scripts/01-preflight.sh" ;;
    02) echo "$PACK_DIR/scripts/02-system-base.sh" ;;
    03) echo "$PACK_DIR/scripts/03-tailscale-ufw.sh" ;;
    04) echo "$PACK_DIR/scripts/04-openclaw.sh" ;;
    05) echo "$PACK_DIR/scripts/05-openai-auth.sh" ;;
    06) echo "$PACK_DIR/scripts/06-personality.sh" ;;
    07) echo "$PACK_DIR/scripts/07-whatsapp.sh" ;;
    08) echo "$PACK_DIR/scripts/08-whatsapp-patches.sh" ;;
    09) echo "$PACK_DIR/scripts/09-credentials.sh" ;;
    10) echo "$PACK_DIR/scripts/10-skills.sh" ;;
    11) echo "$PACK_DIR/scripts/11-memory-init.sh" ;;
    12) echo "$PACK_DIR/scripts/12-automations.sh" ;;
    13) echo "$PACK_DIR/scripts/13-healthcheck.sh" ;;
    14) echo "$PACK_DIR/scripts/14-final-report.sh" ;;
    *) return 1 ;;
  esac
}

stage_name() {
  case "$1" in
    00) echo "audit-package" ;;
    01) echo "preflight" ;;
    02) echo "system-base" ;;
    03) echo "tailscale-ufw" ;;
    04) echo "openclaw" ;;
    05) echo "openai-auth" ;;
    06) echo "personality" ;;
    07) echo "whatsapp" ;;
    08) echo "whatsapp-patches" ;;
    09) echo "credentials" ;;
    10) echo "skills" ;;
    11) echo "memory-init" ;;
    12) echo "automations" ;;
    13) echo "healthcheck" ;;
    14) echo "final-report" ;;
    *) return 1 ;;
  esac
}

next_stage() {
  case "$1" in
    NONE) echo "00" ;;
    00) echo "01" ;;
    01) echo "02" ;;
    02) echo "03" ;;
    03) echo "04" ;;
    04) echo "05" ;;
    05) echo "06" ;;
    06) echo "07" ;;
    07) echo "08" ;;
    08) echo "09" ;;
    09) echo "10" ;;
    10) echo "11" ;;
    11) echo "12" ;;
    12) echo "13" ;;
    13) echo "14" ;;
    14) echo "DONE" ;;
    *) echo "00" ;;
  esac
}

list_stages() {
  for n in 00 01 02 03 04 05 06 07 08 09 10 11 12 13 14; do
    printf '%s %s\n' "$n" "$(stage_name "$n")"
  done
}

show_status() {
  if [[ -f "$STATE" ]]; then
    cat "$STATE"
  else
    echo "AVB_CURRENT_STAGE=NONE"
    echo "AVB_CURRENT_STATUS=NO_STATE"
  fi
}

run_stage() {
  local stage="$1"
  local script

  script="$(stage_script "$stage")" || {
    echo "ERROR: tramo inválido: $stage" >&2
    exit 64
  }

  if [[ ! -f "$script" ]]; then
    echo "ERROR: script no encontrado para tramo $stage: $script" >&2
    exit 66
  fi

  case "$stage" in
    00|01|02|03|04|05|06|07|08|09|10|11|12|13|14)
      echo "==> Ejecutando tramo $stage — $(stage_name "$stage")"
      bash "$script"
      ;;
    *)
      echo "ERROR: tramo $stage todavía no implementado en modo LIVE." >&2
      echo "Estado: BLOCKED_NOT_IMPLEMENTED_LIVE_STAGE_$stage" >&2
      exit 1
      ;;
  esac
}

resume_stage() {
  local current="NONE"
  local status="NO_STATE"
  local target

  if [[ -f "$STATE" ]]; then
    # shellcheck disable=SC1090
    source "$STATE"
    current="${AVB_CURRENT_STAGE:-NONE}"
    status="${AVB_CURRENT_STATUS:-NO_STATE}"
  fi

  case "$status" in
    FRESH_RELEASE|NO_STATE)
      target="00"
      ;;
    PASS|PASS_*|PARTIAL_PASS_*|LIVE_FOUNDATION_CREATED)
      target="$(next_stage "$current")"
      ;;
    BLOCKED*|FAILED*|PARTIAL*)
      if [[ "$current" == "NONE" ]]; then
        target="00"
      else
        target="$current"
      fi
      echo "Reanudando tramo bloqueado/incompleto: $target"
      ;;
    *)
      target="$(next_stage "$current")"
      ;;
  esac

  if [[ "$target" == "DONE" ]]; then
    echo "Instalador ya está en etapa final."
    show_status
    exit 0
  fi

  run_stage "$target"
}

cmd="${1:-}"

case "$cmd" in
  --help|-h|"")
    usage
    ;;
  --list)
    list_stages
    ;;
  --status)
    show_status
    ;;
  --run)
    shift || true
    stage="${1:-}"
    if [[ -z "$stage" ]]; then
      echo "ERROR: falta número de tramo. Ejemplo: bash install.sh --run 00" >&2
      exit 64
    fi
    run_stage "$stage"
    ;;
  --resume)
    resume_stage
    ;;
  *)
    echo "ERROR: comando no reconocido: $cmd" >&2
    usage
    exit 64
    ;;
esac
