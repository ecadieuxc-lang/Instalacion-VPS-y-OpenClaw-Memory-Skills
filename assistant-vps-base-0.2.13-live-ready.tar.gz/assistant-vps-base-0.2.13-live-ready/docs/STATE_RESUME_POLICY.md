# STATE_RESUME_POLICY.md

Politica futura de estado y resume para assistant-vps-base.

## Regla central

El instalador debe avanzar por tramos y debe poder continuar desde el ultimo tramo seguro sin repetir acciones peligrosas.

## Estado por tramo

Cada tramo debe registrar como minimo:

- numero de tramo.
- nombre de tramo.
- estado.
- fecha UTC de inicio.
- fecha UTC de cierre.
- validacion ejecutada.
- evidencia generada.
- siguiente tramo recomendado.
- errores no sensibles.

## Estados permitidos

- PENDING
- RUNNING
- PASS
- PARTIAL
- BLOCKED
- FAILED
- SKIPPED

## Resume

resume solo puede continuar desde un estado PASS, PARTIAL controlado o SKIPPED justificado.

resume debe bloquear si el ultimo estado es RUNNING, FAILED o BLOCKED sin intervencion humana.

## Fallo cerrado

Si hay duda de consistencia, el instalador debe bloquear y pedir ayuda con el help-context seguro.
