# HELP_CONTEXT_POLICY.md

Politica del contexto seguro para pedir ayuda a ChatGPT durante la instalacion.

## Regla central

Despues de cada tramo, el instalador debe actualizar un archivo chatgpt-help-context.md sin secretos.

## Debe incluir

- ultimo tramo ejecutado.
- estado del ultimo tramo.
- siguiente tramo recomendado.
- comandos seguros de diagnostico.
- errores no sensibles.
- rutas del pack sin secretos.
- resumen de validaciones.
- advertencias de seguridad.

## No debe incluir

- API keys.
- tokens.
- QR.
- cookies.
- .env reales.
- creds.json reales.
- secrets.json reales.
- sesiones WhatsApp.
- llaves SSH privadas.
- passwords.

## Uso esperado

El usuario puede copiar este archivo en ChatGPT para recibir ayuda sin exponer secretos.
