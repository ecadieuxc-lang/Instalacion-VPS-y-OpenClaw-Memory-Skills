# VALIDATION_POLICY.md

Politica de validacion documental y futura validacion tecnica del instalador.

## Validacion minima documental

- test -f para archivos esperados.
- grep de contenido clave.
- scan de ejecutables inesperados.
- scan de rutas vivas heredadas.
- scan de nombres personales heredados.
- scan de secretos o patrones de credenciales.

## Categorias de contaminacion viva a bloquear

- Rutas reales de usuarios heredados.
- Rutas locales de llaves SSH privadas.
- Nombres reales de llaves SSH privadas heredadas.
- IPs reales de VPS previos.
- Dominios personales de apps previas.
- Package IDs de apps previas.
- Identidad, memoria o configuracion privada de ASSISTANT.
- creds.json reales.
- secrets.json reales.
- .env reales.
- sesiones WhatsApp reales.

## Validacion futura por tipo

- Markdown: test -f y grep.
- Bash: bash -n antes de ejecucion.
- JSON: parser JSON.
- YAML: parser YAML si esta disponible.
- VPS read-only: comandos no mutantes.
- VPS mutante: backup, rollback, validacion y evidencia.

## Regla de cierre

Sin validacion objetiva no hay TASK_DONE.
