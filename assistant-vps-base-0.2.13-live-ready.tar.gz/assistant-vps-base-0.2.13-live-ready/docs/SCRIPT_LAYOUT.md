# SCRIPT_LAYOUT.md

Layout futuro de scripts del instalador assistant-vps-base.

Este documento no crea scripts. Solo define nombres, responsabilidad y frontera.

## Regla central

```text
un tramo canonico = un script futuro = una evidencia = una validacion = una actualizacion de chatgpt-help-context.md
```

## Layout futuro esperado

```text
scripts/00-audit-package.sh
scripts/01-preflight.sh
scripts/02-system-base.sh
scripts/03-tailscale-ufw.sh
scripts/04-openclaw.sh
scripts/05-openai-auth.sh
scripts/06-personality.sh
scripts/07-whatsapp.sh
scripts/08-whatsapp-patches.sh
scripts/09-credentials.sh
scripts/10-skills.sh
scripts/11-memory-init.sh
scripts/12-automations.sh
scripts/13-healthcheck.sh
scripts/14-final-report.sh
```

## Prohibicion actual

No crear estos scripts hasta que el contrato, los tramos, la politica de dispatcher y la politica de seguridad esten validados.
