# STAGES.md

Documento canonico de tramos del instalador assistant-vps-base.

Regla principal:

```text
un tramo = un script futuro = una validacion = una evidencia = una actualizacion de chatgpt-help-context.md
```

Este archivo no implementa scripts. Solo fija la estructura que cualquier implementacion posterior debe respetar.

## Estados permitidos por tramo

```text
PENDING
RUNNING
PASS
PARTIAL
BLOCKED
FAILED
SKIPPED
```

## Tramos canonicos

### 00 — audit-package
Validar que el paquete no venga contaminado antes de instalar nada.

### 01 — preflight
Confirmar VPS limpio, sistema compatible, recursos minimos y ausencia de instalacion previa.

### 02 — system-base
Crear usuario runtime, base del sistema y carpetas operativas minimas.

### 03 — tailscale-ufw
Configurar Tailscale nuevo y endurecer UFW solo despues de confirmar segunda via SSH.

### 04 — openclaw
Instalar OpenClaw como usuario runtime, con gateway local/loopback y permisos correctos.

### 05 — openai-auth
Guiar OAuth/login nuevo del usuario sin usar API key como fallback silencioso.

### 06 — personality
Aplicar personalidad nueva sobre workspace nativo creado por OpenClaw, sin copiar Assistant.

### 07 — whatsapp
Instalar y enlazar WhatsApp oficial desde cero con QR nuevo, allowlist nueva y grupos deshabilitados.

### 08 — whatsapp-patches
Aplicar patches WhatsApp solo si version y patrones son compatibles. Si no calza, bloquear.

### 09 — credentials
Pedir credenciales nuevas para skills/integraciones, sin imprimirlas ni guardarlas en evidencia.

### 10 — skills
Instalar las 6 skills como paquete funcional auditado, no como lista plana ni latest sin control.

### 11 — memory-init
Inicializar memoria vacia minima, sin recuerdos demo, entidades ficticias ni memoria de Assistant.

### 12 — automations
Configurar solo cron/wrappers necesarios, con marcadores y sin duplicar automatizaciones.

### 13 — healthcheck
Validar OpenClaw, gateway, runtime, UFW, Tailscale, auth, WhatsApp, skills, cron, permisos y secret scan.

### 14 — final-report
Generar reporte final, estado del VPS nuevo y estado de skills sin secretos.

## Regla de no implementacion prematura

No crear scripts ejecutables hasta que este documento y el contrato del instalador esten validados.

