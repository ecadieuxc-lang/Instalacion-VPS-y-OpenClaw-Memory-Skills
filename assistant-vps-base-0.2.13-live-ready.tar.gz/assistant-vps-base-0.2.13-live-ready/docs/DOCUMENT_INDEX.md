# DOCUMENT_INDEX.md

Indice documental canonico de assistant-vps-base.

## Base

- README.md: entrada principal del pack.
- VERSION: version canonica.
- MANIFEST.md: inventario del contenido.

## Contrato y tramos

- docs/INSTALLER_CONTRACT.md: alcance, prohibiciones y contrato base.
- docs/STAGES.md: tramos canonicos 00-14.

## Scripts futuros

- docs/SCRIPT_LAYOUT.md: nombres futuros de scripts 00-14.
- docs/DISPATCHER_POLICY.md: politica futura de install.sh.

## Seguridad y validacion

- docs/SECRET_POLICY.md: secretos prohibidos y sanitizacion.
- docs/VALIDATION_POLICY.md: validaciones y scans requeridos.

## Estado y ayuda

- docs/STATE_RESUME_POLICY.md: estado, resume y fallo cerrado.
- docs/HELP_CONTEXT_POLICY.md: contexto seguro para ChatGPT.
- templates/evidence/chatgpt-help-context.md: plantilla segura para pedir ayuda.

## Gates

- docs/IMPLEMENTATION_GATES.md: condiciones para pasar de documentacion a scripts.
