# SECRET_POLICY.md

Politica de secretos y sanitizacion para assistant-vps-base.

## Regla central

El instalador no debe copiar, imprimir, empaquetar, registrar ni inferir secretos vivos.

## Prohibido en pack, logs y evidence

- API keys reales.
- Tokens OAuth.
- Refresh tokens.
- Cookies.
- QR de autenticacion.
- Semillas TOTP.
- Archivos .env reales.
- creds.json.
- secrets.json.
- Auth stores SQLite.
- Sesiones WhatsApp.
- Llaves SSH privadas.
- Passwords.
- Numeros personales completos salvo que el usuario los ingrese para su propio allowlist.

## Regla de credenciales nuevas

Cada usuario debe usar credenciales nuevas. Nunca se deben usar credenciales de ASSISTANT, previous owner, runtime_user ni de ningun VPS previo.

## Evidence segura

La evidencia puede registrar estado CONFIGURED, PENDING, SKIPPED o INVALID, pero nunca valores secretos.
