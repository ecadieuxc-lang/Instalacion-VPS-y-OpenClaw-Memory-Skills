# WhatsApp patches opcionales

Este paquete no incluye un patch pack real de WhatsApp presence/typing/read receipts.

El tramo `08-whatsapp-patches` está preparado para aplicar un patch pack controlado solo si existe `patches/whatsapp-presence/manifest.env` y los patrones/versiones calzan.

Si el patch pack no está presente, el instalador debe terminar ese tramo como `PARTIAL_PASS_WHATSAPP_PATCHES_SKIPPED_NO_PATCH_PACK` y continuar sin prometer typing/presence/read receipts avanzados.

No copiar `dist/*.js`, sesiones, QR ni credenciales desde otro VPS.
