# DISPATCHER_POLICY.md

Politica futura del dispatcher install.sh.

Este documento no implementa install.sh. Solo fija reglas.

## Funcion del dispatcher

install.sh debe orquestar tramos. No debe esconder logica pesada.

## Reglas obligatorias

- Debe aceptar ejecucion por tramo.
- Debe aceptar resume.
- Debe bloquear si falta estado consistente.
- Debe actualizar chatgpt-help-context.md despues de cada tramo.
- Debe escribir evidencia por tramo.
- Debe ocultar secretos en toda salida.
- Debe fallar cerrado ante errores criticos.

## Prohibido

- No ejecutar todo a ciegas.
- No continuar tras fallo critico.
- No usar credenciales por defecto.
- No usar rutas vivas heredadas.
- No copiar estado de ASSISTANT.
- No crear fallback silencioso a API keys.
- No abrir red publica.

## Politica de estados

Los estados permitidos son PENDING, RUNNING, PASS, PARTIAL, BLOCKED, FAILED y SKIPPED.
