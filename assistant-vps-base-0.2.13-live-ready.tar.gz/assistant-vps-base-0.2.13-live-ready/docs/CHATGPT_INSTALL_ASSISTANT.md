# CHATGPT_INSTALL_ASSISTANT.md


Guia segura para pedir ayuda a ChatGPT durante una instalacion.


# Uso minimo

## Preparar contexto

1. Leer `README.md`, `MANIFEST.md` y `docs/safety.md`.
2. Copiar la estructura de `templates/help-context.md` en el task o handoff.
3. Completar solo campos no sensibles.
4. Confirmar explicitamente el entorno: `LIVE_INSTALLER / VPS_TARGET`, `VPS_SSH_READONLY` o `VPS_SSH_MUTATING`.
5. Definir validaciones objetivas antes de ejecutar.

## Antes de cerrar

Validar:

- `test -f packs/assistant-vps-base/README.md`
- `test -f packs/assistant-vps-base/VERSION`
- `grep -R "VERSION" packs/assistant-vps-base`
- `grep -R "No pegar API keys" packs/assistant-vps-base`
- `find packs/assistant-vps-base -type f -perm /111 -print`

La ultima validacion debe devolver salida vacia para confirmar que no hay ejecutables.

## Resultado esperado

Cerrar como `TASK_DONE` solo si existen los archivos minimos, la politica anti-secretos aparece en el pack y no hay ejecutables.



## Que NO pegar
- No pegar API keys.
- No pegar tokens.
- No pegar QR.
- No pegar .env.
- No pegar creds.json.
- No pegar secrets.json.
- No pegar cookies.
- No pegar llaves privadas.
