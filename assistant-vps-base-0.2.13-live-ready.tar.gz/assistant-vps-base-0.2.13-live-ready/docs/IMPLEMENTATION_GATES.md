# IMPLEMENTATION_GATES.md

Gates obligatorios antes de crear scripts ejecutables del instalador.

## Gate 1 — Documentacion base

Debe existir README.md, VERSION, MANIFEST.md y docs/INSTALLER_CONTRACT.md.

## Gate 2 — Tramos canonicos

Debe existir docs/STAGES.md con tramos 00-14.

## Gate 3 — Layout y dispatcher

Debe existir docs/SCRIPT_LAYOUT.md y docs/DISPATCHER_POLICY.md.

## Gate 4 — Seguridad y validacion

Debe existir docs/SECRET_POLICY.md y docs/VALIDATION_POLICY.md.

## Gate 5 — Estado y ayuda

Debe existir docs/STATE_RESUME_POLICY.md, docs/HELP_CONTEXT_POLICY.md y templates/evidence/chatgpt-help-context.md.

## Gate 6 — Sin ejecutables prematuros

Antes de pasar a scripts, el pack no debe contener archivos ejecutables inesperados.

## Gate 7 — Sin contaminacion viva

El pack no debe contener rutas, IPs, dominios, package IDs, llaves o identidad viva heredada de ASSISTANT.

## Regla de paso a implementacion

Solo si todos los gates pasan se puede abrir un task nuevo para crear scripts no peligrosos en modo local.
