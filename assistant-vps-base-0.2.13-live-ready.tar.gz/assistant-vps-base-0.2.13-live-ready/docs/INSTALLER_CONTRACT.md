# INSTALLER_CONTRACT.md


Contrato documental inicial del instalador assistant-vps-base.


# Alcance - assistant-vps-base

## Permitido

- Crear o actualizar documentacion del pack.
- Usar `templates/help-context.md` para describir contexto no sensible.
- Registrar evidencia local de validacion documental.
- Referenciar rutas solo como identificadores operativos, sin contenido secreto.

## Prohibido

- Usar SSH.
- Usar sudo.
- Mutar VPS, produccion o servicios remotos.
- Leer o copiar secretos.
- Abrir `.env`, `creds.json`, `secrets.json`, auth stores, sesiones WhatsApp o llaves SSH.
- Crear scripts ejecutables.
- Instalar dependencias.
- Hacer commits.

## Politica de modelos

El pack asume uso mediante CLI/modelo disponible por suscripcion mensual. No disena flujos que dependan de `OPENAI_API_KEY` ni de pago por consumo de tokens.

## Senal de bloqueo

Si aparece contenido que parezca secreto, token, credencial, sesion o llave, detener el task y cerrar como `TASK_BLOCKED`.



# Seguridad operacional

## Regla central

No pegar API keys.

Tambien esta prohibido pegar tokens, passwords, cookies, codigos de recuperacion, QR de autenticacion, semillas TOTP, contenido de `.env`, credenciales cloud, sesiones WhatsApp o llaves SSH.

## Ejecucion

Este pack es LIVE_INSTALLER. No contiene scripts y no autoriza ejecucion remota.

Para cualquier task con VPS:

- Debe existir task explicito.
- Debe estar definido el entorno.
- Debe estar definido el rollback.
- Debe estar autorizada la modalidad SSH si aplica.
- Debe haber validacion objetiva sin exponer secretos.

## Evidencia aceptable

- Salidas de `test -f`.
- Salidas de `grep` sobre archivos documentales creados por el task.
- Listado de archivos del pack.
- Confirmacion local de que no hay ejecutables.

## Evidencia no aceptable

- Valores de secretos.
- Capturas de auth stores.
- Contenido de sesiones.
- Dumps de `.env`.
- Llaves privadas o publicas completas si no son necesarias.



## Estados de tramo
- PENDING
- RUNNING
- PASS
- PARTIAL
- BLOCKED
- FAILED
- SKIPPED

## Gate de implementacion

Antes de crear scripts ejecutables deben pasar los gates definidos en docs/IMPLEMENTATION_GATES.md.
Si un gate falla, el instalador no debe avanzar a implementacion.
