---
name: 2nd-brain
description: Assistant Memory Stack curated notes layer. La Biblioteca: use only when the user explicitly asks to save or retrieve intentional notes. Local Markdown only. No automatic capture, no API keys, no hooks, no scripts, no attachments/media auto-save, no ontology duplication.
emoji: 📚
tags: [notes, curated-memory, assistant-memory-stack, local-assistant]
---

# 2nd-brain — Assistant Memory Stack edition

## Role

This skill is La Biblioteca.

It stores and retrieves intentional reference notes: the things the user explicitly wants to keep.

It is different from total-recall:
- total-recall, if installed later, remembers what happened automatically.
- 2nd-brain saves what the user deliberately asks to preserve.

It is different from ontology:
- ontology owns structured entities and relations.
- 2nd-brain owns descriptive curated notes.

## Write zone

This skill may write only under:
- brain/notes/
- brain/index.md

This skill must not write, update, promote, consolidate, index, or mutate:
- MEMORY.md
- memory/observations.md
- memory/ontology/
- .learnings/
- mindmap outputs
- OpenClaw config
- session/auth files
- WhatsApp files
- VPS operational files
- any path outside brain/

## Activation

Use this skill only for explicit save or retrieve requests.

Spanish save triggers:
- guarda esto
- guardá esto
- anota esto
- agrega esto a mis notas
- déjalo en mis notas
- guarda este restaurante/lugar/producto/dato

English save triggers:
- save this
- note this
- add this to my notes
- store this in my notes

Retrieval triggers:
- qué tengo anotado sobre
- qué notas tengo de
- what do I have noted about
- what notes do I have on

Do not save ordinary conversation by initiative.

If the user only says remember ambiguously, ask whether they want:
- a curated note in 2nd-brain;
- a structured fact in ontology;
- or no persistent write.

## Read zone

When retrieving curated notes, this skill may read only:

- brain/index.md
- brain/notes/

This skill must not read or search:

- MEMORY.md
- memory/observations.md
- memory/ontology/
- .learnings/
- mindmap outputs
- OpenClaw config
- session/auth files
- WhatsApp files
- VPS operational files
- raw transcripts
- unrelated workspace files

memorySearch may be used only when constrained to curated 2nd-brain note sources.

## No automatic capture

This skill must not:
- monitor sessions;
- summarize every conversation;
- read transcripts automatically;
- trigger on every turn;
- run cron jobs;
- infer what should be saved without explicit user instruction.

## Note format

Use short Markdown notes under brain/notes/.

Recommended filename:
YYYY-MM-DD-topic-slug.md

Recommended fields:
- Title
- Created UTC
- Source: explicit-user-request
- Type
- Sensitivity
- Note
- Retrieval hints

Keep notes short and curated.
Do not paste raw transcripts.

## Index

brain/index.md may contain only note titles, paths, short tags, and retrieval hints.

Do not store secrets, raw logs, transcripts, credentials, or sensitive personal data in the index.

## Ontology coordination

If the content is clearly a structured entity, relation, project state, person relation, task relation, or stable decision, route it to ontology instead of duplicating it here.

2nd-brain may keep a descriptive note only when the user explicitly wants a note.

When in doubt, ask whether the user wants a note, a structured memory entry, or both.

## Assistant Memory Stack coordination

- ontology is the Archivist and owns structured graph memory.
- total-recall, if installed later, owns automatic episodic observations.
- memory-maintenance, if installed later, owns review, retention and proposed promotion.
- self-improving-agent owns assistant behavioral corrections.
- mindmap-generator is read-only visualization.
- memorySearch remains the shared retrieval layer.
- 2nd-brain owns curated notes only by explicit user request.

## Secrets and sensitive data

Never store:
- passwords, API keys, tokens, cookies, bearer headers;
- OAuth/device codes, login URLs, session material;
- SSH keys, private keys, .env contents;
- WhatsApp auth data, JIDs, LIDs, phone numbers, session files;
- VPS credentials, private endpoints, firewall details;
- raw command output, stack traces, environment dumps, logs, transcripts;
- sensitive health, finance, legal, relationship, address or identifier data;
- source code, config files, or operational details.

If sensitive material appears, refuse to store it and ask for a safe abstract wording.

## Attachments and media

Do not save uploaded files, images, audio, PDFs, screenshots, or media automatically.

If the user explicitly asks to save an attachment, stop and require a separate approved attachment-storage task.

This skill alone must not silently create or fill brain/attachments/.

## Hooks and scripts

This assistant-base edition does not install hooks, scripts, cron jobs, daemons, watchers, background processors, or registry helper code.

## Operational posture

Be conservative.

2nd-brain is deliberate notes, not automatic memory.
