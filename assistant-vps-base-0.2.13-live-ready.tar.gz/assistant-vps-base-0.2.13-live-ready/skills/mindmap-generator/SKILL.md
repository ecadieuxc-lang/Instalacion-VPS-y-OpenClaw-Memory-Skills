---
name: mindmap-generator
description: Assistant Memory Stack visual mindmap layer. Use only when the user explicitly asks to map, visualize, structure, or mentally organize information, or when the user appears overwhelmed and a map can be offered. Memory read-only: never writes memory, never captures conversations automatically, never edits ontology, MEMORY.md, 2nd-brain notes, observations, or .learnings. May create temporary visual output artifacts for delivery when a map is useful.
emoji: 🗺️
tags: [mindmap, visualization, diagram, assistant-memory-stack, local-assistant, read-only]
---

# mindmap-generator — Assistant Memory Stack edition

## Role

This skill is "El Cartógrafo" in the assistant's Assistant Memory Stack memory architecture.

Its job is to transform information into a clear visual or structured mind map.

It may help organize:

- conversations;
- goals;
- decisions;
- priorities;
- pros and cons;
- risks;
- project structure;
- study material;
- meeting notes;
- memory summaries that were already retrieved by another approved layer.

## Memory read-only rule

This skill is read-only with respect to memory.

It must not write, create, update, delete, promote, consolidate, index, or mutate:

- `MEMORY.md`
- ontology graph/schema files
- `memory/observations.md`
- 2nd-brain notes
- `.learnings/`
- OpenClaw config
- user profile files
- WhatsApp/session/auth files
- any memory source

It can generate a temporary visual output when the user explicitly requests a visual/map artifact, or when the user is clearly overwhelmed by a complex situation and a map would reduce cognitive load.

## Activation rules

Use this skill when the user asks in Spanish or English for:

- "mapa mental"
- "mapéalo"
- "visualízalo"
- "hazme un mapa"
- "desglosa esto visualmente"
- "organiza esto como mapa"
- "mindmap"
- "visual map"
- "map this out"
- "show me the structure"
- "diagram this as a mindmap"

It may offer or produce a map when the user says they are overwhelmed, has too many priorities, asks to make sense of a complex situation, reviews 3 or more priorities, compares options, or asks to organize plans visually.

Do not activate for trivial lists of 1–2 items unless the user explicitly asks for a map.

Do not activate when the user asks for text only.

## Input boundaries

Use only information that is already present in the current conversation or has been intentionally retrieved by another approved memory layer.

Do not independently search, scan, or read memory files just to make a map.

If the user asks for a map of memory, first route retrieval to the proper layer:

- ontology for structured entities/relations/decisions;
- 2nd-brain for curated notes;
- total-recall for episodic observations, if installed later;
- memorySearch for ordinary retrieval if appropriate.

Then this skill may visualize the retrieved result.

## Output behavior

Prefer a concise outline first if the map is complex.

When producing a visual artifact, prefer safe local formats:

- Mermaid mindmap text;
- SVG/HTML through the existing bundled `diagram-maker` skill when available;
- PNG only if the available toolchain supports it safely and temporarily.

Temporary generated files must be treated as runtime/output artifacts, not memory.

This skill may create temporary output artifacts only for delivery to the user:

- Mermaid text in the response;
- SVG/HTML through the existing bundled `diagram-maker` skill;
- PNG when the local node/npx toolchain is already available and safe, with no network fetch, no package install, and no registry download.

Output artifacts must be transient runtime/delivery artifacts. They must not be written into memory paths, note paths, ontology paths, `.learnings/`, config, session/auth paths, or any persistent memory store. Temporary files should live only in a safe runtime/output location and be cleaned up or treated as disposable after delivery.

Do not save maps as memory. If the user explicitly wants to keep a map, route the request to a separate approved note/document task owned by 2nd-brain or another approved document layer. In that case, mindmap-generator provides the visual content; the owner layer decides whether and where to save it.

## Assistant Memory Stack coordination

- ontology remains the Archivist and owns structured facts/relations.
- 2nd-brain owns curated notes by explicit user request.
- total-recall, if installed later, owns automatic episodic observations.
- memory-maintenance, if installed later, owns review/promotion/retention.
- self-improving-agent owns assistant behavioral corrections.
- memorySearch remains the shared retrieval layer.
- mindmap-generator owns no persistent memory. It represents information visually and may create temporary delivery artifacts.

## Secret and privacy policy

Never include secrets or sensitive operational data in a map:

- tokens, passwords, API keys, cookies;
- OAuth/device codes;
- SSH keys;
- WhatsApp JIDs/LIDs/session data/phone numbers;
- VPS credentials/private endpoints;
- raw logs, stack traces, env dumps;
- private identifiers or sensitive personal data.

If sensitive material appears in the source, abstract it or ask for a sanitized version.

## Hooks and scripts

This assistant-base edition does not install hooks, scripts, cron jobs, daemons, watchers, or background processors.

Do not use or install third-party registry hooks/scripts for mindmap generation without separate audit and explicit human approval.

## Operational posture

Be useful but quiet.

Offer or produce maps when they reduce cognitive load, especially for complex priorities, decisions, plans, study material, or overwhelm. Do not force visual output into ordinary text questions.
