#!/usr/bin/env bash
# Total Recall compatibility helpers — Assistant Memory Stack safe edition.
# No systemd probing, no service management.

tr_date_utc() {
  date -u +"%Y-%m-%dT%H:%M:%SZ"
}

file_mtime() {
  local file="$1"
  if [ ! -e "$file" ]; then
    echo 0
    return 0
  fi
  if stat -c %Y "$file" >/dev/null 2>&1; then
    stat -c %Y "$file"
  else
    stat -f %m "$file"
  fi
}

date_minutes_ago() {
  local mins="${1:-15}"
  if date -u -d "$mins minutes ago" +"%Y-%m-%dT%H:%M:%S" >/dev/null 2>&1; then
    date -u -d "$mins minutes ago" +"%Y-%m-%dT%H:%M:%S"
  else
    date -u -v-"${mins}"M +"%Y-%m-%dT%H:%M:%S"
  fi
}

md5_hash() {
  if command -v md5sum >/dev/null 2>&1; then
    md5sum | awk '{print $1}'
  elif command -v md5 >/dev/null 2>&1; then
    md5 -q
  else
    shasum -a 256 | awk '{print $1}'
  fi
}

has_inotify() {
  command -v inotifywait >/dev/null 2>&1
}

safe_load_env_keys() {
  # Usage: safe_load_env_keys FILE KEY1 KEY2...
  # Non-executing parser: supports KEY=value and KEY="value"; ignores unsafe key names.
  local env_file="${1:-}"
  shift || true
  [ -f "$env_file" ] || return 0

  local key allowed raw value wanted
  while IFS= read -r raw || [ -n "$raw" ]; do
    raw="${raw%%#*}"
    case "$raw" in
      *=*) ;;
      *) continue ;;
    esac
    key="${raw%%=*}"
    value="${raw#*=}"

    case "$key" in
      ''|*[!A-Za-z0-9_]*|[0-9]*)
        continue
        ;;
    esac

    wanted=0
    for allowed in "$@"; do
      if [ "$key" = "$allowed" ]; then
        wanted=1
        break
      fi
    done
    [ "$wanted" -eq 1 ] || continue

    value="${value%$'\r'}"
    case "$value" in
      \"*\") value="${value#\"}"; value="${value%\"}" ;;
      \'*\') value="${value#\'}"; value="${value%\'}" ;;
    esac

    case "$value" in
      *$'\n'*|*$'\r'*)
        continue
        ;;
    esac

    export "$key=$value"
  done < "$env_file"
}

tr_user_services_available() {
  return 1
}
