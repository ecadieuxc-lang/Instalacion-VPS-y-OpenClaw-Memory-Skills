#!/usr/bin/env bash
set -euo pipefail

# Total Recall Dream Cycle helper — Assistant Memory Stack safe edition.
# No git mutation. No arbitrary .env sourcing. Approved memory paths only.

WORKSPACE="${OPENCLAW_WORKSPACE:-$HOME/.openclaw/workspace}"
MEMORY_DIR="${MEMORY_DIR:-$WORKSPACE/memory}"

OBS="$MEMORY_DIR/observations.md"
BACKUP_DIR="$MEMORY_DIR/dream-backups"
OBS_BACKUP_DIR="$MEMORY_DIR/observation-backups"
ARCHIVE_OBS="$MEMORY_DIR/archive/observations"
ARCHIVE_CHUNKS="$MEMORY_DIR/archive/chunks"
LOG_DIR="$MEMORY_DIR/dream-logs"
METRICS_DIR="$MEMORY_DIR/dream-metrics"
STAGING_DIR="$MEMORY_DIR/dream-staging"
TMP_DIR="$MEMORY_DIR/.tmp-total-recall"

timestamp() {
  date -u +"%Y%m%dT%H%M%SZ"
}

ensure_dirs() {
  mkdir -p "$MEMORY_DIR" "$BACKUP_DIR" "$OBS_BACKUP_DIR" "$ARCHIVE_OBS" "$ARCHIVE_CHUNKS" "$LOG_DIR" "$METRICS_DIR" "$STAGING_DIR" "$TMP_DIR"
  touch "$OBS"
}

safe_name() {
  local name="$1"
  if [[ ! "$name" =~ ^[A-Za-z0-9._-]+$ ]]; then
    echo "Invalid name: $name" >&2
    exit 2
  fi
}

reject_sensitive() {
  local file="$1"
  if grep -Eiq 'api[_-]?key|secret|password|token|bearer |ssh private|BEGIN OPENSSH|cookie|oauth|device code|whatsapp|jid|lid|session auth|raw log|env dump' "$file"; then
    echo "Rejected: sensitive-looking material detected in $file" >&2
    return 3
  fi
  return 0
}

atomic_safe_write() {
  local out="$1"
  local tmp
  tmp="$(mktemp "$TMP_DIR/write.XXXXXX")"
  cat > "$tmp"

  if ! reject_sensitive "$tmp"; then
    rm -f "$tmp"
    exit 3
  fi

  mv "$tmp" "$out"
  echo "$out"
}

backup_observations() {
  ensure_dirs
  local out="$BACKUP_DIR/observations.$(timestamp).bak.md"
  cp "$OBS" "$out"
  echo "$out"
}

preflight() {
  ensure_dirs
  backup_observations >/dev/null
  echo "DREAM_PREFLIGHT_OK"
}

validate_observations_file() {
  local file="$1"
  test -f "$file"
  reject_sensitive "$file"
  if grep -Eq 'MEMORY.md|\.learnings|ontology|2nd-brain|WhatsApp/session|auth file|private key' "$file"; then
    echo "Rejected: output references forbidden write surfaces" >&2
    exit 4
  fi
}

write_staging() {
  ensure_dirs
  local name="${1:-}"
  test -n "$name" || { echo "Usage: $0 write-staging NAME.md < content" >&2; exit 2; }
  safe_name "$name"
  case "$name" in
    *.md|*.json) ;;
    *) echo "Staging name must end in .md or .json" >&2; exit 2 ;;
  esac
  atomic_safe_write "$STAGING_DIR/$name"
}

apply_observations() {
  ensure_dirs
  local name="${1:-}"
  test -n "$name" || { echo "Usage: $0 apply-observations NAME.md" >&2; exit 2; }
  safe_name "$name"
  local src="$STAGING_DIR/$name"
  validate_observations_file "$src"
  backup_observations >/dev/null
  cp "$src" "$OBS"
  echo "DREAM_APPLY_OBSERVATIONS_OK"
}

archive_observation() {
  ensure_dirs
  local name="${1:-}"
  test -n "$name" || { echo "Usage: $0 archive-observation NAME.md < content" >&2; exit 2; }
  safe_name "$name"
  atomic_safe_write "$ARCHIVE_OBS/$name"
}

archive_chunk() {
  ensure_dirs
  local name="${1:-}"
  test -n "$name" || { echo "Usage: $0 archive-chunk NAME.md < content" >&2; exit 2; }
  safe_name "$name"
  atomic_safe_write "$ARCHIVE_CHUNKS/$name"
}

write_log() {
  ensure_dirs
  local name="${1:-dream.$(timestamp).md}"
  safe_name "$name"
  atomic_safe_write "$LOG_DIR/$name"
}

write_metrics() {
  ensure_dirs
  local name="${1:-metrics.$(timestamp).json}"
  safe_name "$name"
  atomic_safe_write "$METRICS_DIR/$name"
}

rollback_latest() {
  ensure_dirs
  local latest
  latest="$(ls -1t "$BACKUP_DIR"/observations.*.bak.md 2>/dev/null | head -1 || true)"
  if [ -z "$latest" ]; then
    echo "No backup available" >&2
    exit 1
  fi
  cp "$latest" "$OBS"
  echo "DREAM_ROLLBACK_OK $latest"
}

case "${1:-}" in
  preflight) preflight ;;
  backup) backup_observations ;;
  write-staging) shift; write_staging "$@" ;;
  apply-observations) shift; apply_observations "$@" ;;
  archive-observation) shift; archive_observation "$@" ;;
  archive-chunk) shift; archive_chunk "$@" ;;
  write-log) shift; write_log "$@" ;;
  write-metrics) shift; write_metrics "$@" ;;
  rollback-latest) rollback_latest ;;
  *)
    cat <<'USAGE'
Usage:
  dream-cycle.sh preflight
  dream-cycle.sh backup
  dream-cycle.sh write-staging NAME.md < content
  dream-cycle.sh apply-observations NAME.md
  dream-cycle.sh archive-observation NAME.md < content
  dream-cycle.sh archive-chunk NAME.md < content
  dream-cycle.sh write-log NAME.md < content
  dream-cycle.sh write-metrics NAME.json < content
  dream-cycle.sh rollback-latest

Allowed writes are restricted to Total Recall memory paths only.
Forbidden: git, MEMORY.md, ontology, 2nd-brain, .learnings, secrets, raw transcripts.
USAGE
    exit 2
    ;;
esac
