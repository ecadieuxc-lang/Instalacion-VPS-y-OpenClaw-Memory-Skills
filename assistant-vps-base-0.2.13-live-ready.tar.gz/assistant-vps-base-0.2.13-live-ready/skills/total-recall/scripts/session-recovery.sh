#!/usr/bin/env bash
set -euo pipefail

# Total Recall — Assistant Memory Stack safe session recovery.
# Runs observer targeted recovery only. No raw transcript fallback.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE="${OPENCLAW_WORKSPACE:-$HOME/.openclaw/workspace}"
MEMORY_DIR="${MEMORY_DIR:-$WORKSPACE/memory}"
SESSIONS_DIR="${SESSIONS_DIR:-$HOME/.openclaw/agents/main/sessions}"
LOG_DIR="${LOG_DIR:-$WORKSPACE/logs}"
OBS="$MEMORY_DIR/observations.md"
LOG="$LOG_DIR/session-recovery.log"

mkdir -p "$MEMORY_DIR" "$LOG_DIR"
touch "$OBS" "$LOG"

timestamp() {
  date -u +"%Y-%m-%dT%H:%M:%SZ"
}

log_msg() {
  printf '[%s] %s\n' "$(timestamp)" "$*" >> "$LOG"
}

OBSERVER="$SCRIPT_DIR/observer-agent.sh"

if [ ! -x "$OBSERVER" ] && [ -f "$OBSERVER" ]; then
  chmod 0755 "$OBSERVER" 2>/dev/null || true
fi

if [ ! -f "$OBSERVER" ]; then
  log_msg "SESSION_RECOVERY_SKIPPED observer-agent.sh missing"
  echo "SESSION_RECOVERY_SKIPPED_OBSERVER_MISSING"
  exit 0
fi

SESSION_FILE="${1:-}"

if [ -z "$SESSION_FILE" ]; then
  SESSION_FILE="$(find "$SESSIONS_DIR" -name "*.jsonl" -type f 2>/dev/null | sort | tail -1 || true)"
fi

if [ -z "$SESSION_FILE" ] || [ ! -f "$SESSION_FILE" ]; then
  log_msg "SESSION_RECOVERY_NO_SESSION_FILE"
  echo "SESSION_RECOVERY_NO_SESSION_FILE"
  exit 0
fi

case "$SESSION_FILE" in
  "$SESSIONS_DIR"/*.jsonl) ;;
  *)
    log_msg "SESSION_RECOVERY_REJECTED_OUTSIDE_SESSIONS_DIR"
    echo "SESSION_RECOVERY_REJECTED_OUTSIDE_SESSIONS_DIR"
    exit 0
    ;;
esac

set +e
bash "$OBSERVER" --recover "$SESSION_FILE" >> "$LOG" 2>&1
STATUS=$?
set -e

if [ "$STATUS" -eq 0 ]; then
  log_msg "SESSION_RECOVERY_OBSERVER_OK file=$SESSION_FILE"
  echo "SESSION_RECOVERY_OBSERVER_OK"
  exit 0
fi

log_msg "SESSION_RECOVERY_OBSERVER_FAILED status=$STATUS; raw fallback disabled by Assistant Memory Stack policy"
echo "SESSION_RECOVERY_OBSERVER_FAILED_RAW_FALLBACK_DISABLED"
exit 0
