---
name: total-recall
description: "Assistant Memory Stack autonomous observational memory core. El Escriba watches OpenClaw session activity, compresses important conversation context into memory/observations.md, consolidates that log, and recovers missed sessions. External app connectors are intentionally disabled for this phase and require separate audit."
metadata:
  openclaw:
    emoji: "🧠"
    requires:
      bins: ["jq", "curl", "bash"]
    env:
      - key: OPENROUTER_API_KEY
        label: "OpenRouter API key for free-tier LLM calls"
        required: true
    config:
      memorySearch:
        description: "Keep OpenClaw memorySearch enabled for observations.md cross-session recall"
---

# total-recall — Assistant Memory Stack core

## Role

This skill is **El Escriba** in the assistant's Assistant Memory Stack memory architecture.

Its job is to capture and compress important conversational context into `memory/observations.md` automatically.

It is the only Assistant Memory Stack component allowed to perform automatic episodic/observational capture.

## Included core

This Assistant Memory Stack-core installation includes:

- Observer;
- Reflector;
- Session Recovery;
- Reactive Watcher script;
- Dream Cycle helper and prompt;
- memoryFlush observer-only config;
- cron config templates;
- observation schema;
- future connector policy.

## Excluded from this phase

The following are intentionally not installed or enabled in the core phase:

- Gmail connector;
- Calendar connector;
- Fitbit connector;
- Samsung Health / Health Connect connector;
- LinkedIn connector;
- Todoist connector;
- Ionos connector;
- broad filewatch connector;
- AIE sensor-sweep / rumination / preconscious / buffer / emergency modules.

Future connectors must be installed as separate gated modules.

## Ownership

Allowed automatic write targets:

- `memory/observations.md`;
- `memory/observation-backups/`;
- `memory/dream-backups/`;
- `memory/dream-logs/`;
- `memory/dream-metrics/`;
- `memory/dream-staging/`;
- `memory/archive/observations/`;
- `memory/archive/chunks/`;
- `logs/observer.log`;
- `logs/reflector.log`;
- `logs/session-recovery.log`;
- `logs/observer-watcher.log`.

Forbidden write targets:

- `MEMORY.md`;
- ontology graph/schema files;
- 2nd-brain notes;
- `.learnings/`;
- OpenClaw identity/personality/config files;
- WhatsApp/session/auth files;
- SSH keys;
- `.env`;
- API key files;
- external connector credentials;
- any path outside the approved total-recall memory/log surface.

## API key rule

`OPENROUTER_API_KEY` or compatible `LLM_API_KEY` must be configured outside chat and outside evidence.

Never write API keys into:

- this skill directory;
- `MEMORY.md`;
- `memory/observations.md`;
- logs;
- evidence files;
- chat transcripts.

Default models must use OpenRouter `:free` models unless the user explicitly approves otherwise.

## Capture policy

The observer may read OpenClaw session JSONL files and send recent conversation content to the configured LLM for compression.

The output must be concise observations, not raw transcripts.

Never persist:

- full raw transcripts;
- raw command output;
- secrets;
- passwords;
- tokens;
- API keys;
- SSH private keys;
- cookies;
- OAuth/device codes;
- WhatsApp session/auth/JID/LID data;
- raw logs;
- env dumps;
- private credentials.

If sensitive material appears in source text, the observation must abstract or omit it.

## Session Recovery

Session Recovery may call the observer in recovery mode.

If observer recovery fails, it must log a safe failure marker only. It must not append raw fallback transcript excerpts to `memory/observations.md`.

## Dream Cycle

Dream Cycle may consolidate `memory/observations.md` and write only to approved total-recall memory paths.

It must not:

- mutate git state;
- run git staging, commit, or destructive reset operations;
- write the main long-term memory file;
- stage promotion proposals for direct long-term-memory writes;
- source arbitrary `.env` files.

Promotion into long-term memory belongs to memory-maintenance, not total-recall.

## Setup posture

This skill ships with scripts and config templates only.

Do not auto-install systemd services, crontab entries, packages, or external connectors from this skill without a separate explicit gate.

Allowed install shape for the first phase:

- install files under `skills/total-recall/`;
- create `memory/observations.md` if absent;
- create approved memory/log directories;
- configure API key outside evidence/chat;
- run observer manually once for validation;
- enable cron/watchers only after separate gate.

## Coordination with other Assistant Memory Stack skills

- ontology owns structured entities and relations.
- 2nd-brain owns curated notes by explicit request.
- mindmap-generator visualizes retrieved information.
- self-improving-agent owns assistant behavioral corrections.
- memory-maintenance owns review, promotion, retention, and `MEMORY.md` proposals.
- total-recall owns automatic observational capture into `memory/observations.md`.

## Future connector policy

See `docs/assistant-memory-stack-connectors-future.md`.

Connectors are valuable, but they are not part of this core install.
## Assistant Phase 2 hardening note

This Assistant Memory Stack build includes a reflector sensitive-output guard and uses `$HOME/.openclaw/workspace` as the unified default workspace fallback for auxiliary scripts. External connectors remain future-gated and disabled.

