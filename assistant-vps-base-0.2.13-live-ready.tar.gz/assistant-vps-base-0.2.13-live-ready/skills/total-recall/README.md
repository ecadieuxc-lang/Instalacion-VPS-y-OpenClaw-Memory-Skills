# Total Recall — Assistant Memory Stack Core

This is a hardened Assistant Memory Stack-core candidate derived from upstream Total Recall.

## Purpose

Automatic observational memory for the assistant.

The core captures important conversational context into:

- `memory/observations.md`

It then consolidates that file through reflector and Dream Cycle mechanisms.

## Included

- Observer
- Reflector
- Session Recovery
- Reactive Watcher script
- Dream Cycle safe helper
- observation schema
- memoryFlush observer-only config
- cron config templates
- future connector policy

## Not included now

External connectors and AIE modules are intentionally excluded.

Future connector candidates include:

- Gmail
- Calendar
- Fitbit
- Samsung Health / Health Connect
- LinkedIn
- Todoist
- Ionos
- filewatch

Each requires separate audit and explicit approval.

## Safe first install shape

1. Install files under `~/.openclaw/workspace/skills/total-recall/`.
2. Create `memory/observations.md` if absent.
3. Configure `OPENROUTER_API_KEY` outside chat and outside evidence.
4. Run observer manually once for validation.
5. Enable cron/watcher only after a separate gate.

No sudo, no package install, no systemd, no crontab mutation, no connectors in this phase.
