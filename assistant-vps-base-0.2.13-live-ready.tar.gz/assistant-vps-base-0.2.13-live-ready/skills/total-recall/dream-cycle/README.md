# Dream Cycle — Assistant Memory Stack Safe Edition

Dream Cycle consolidates `memory/observations.md`.

Allowed writes:

- `memory/dream-backups/`
- `memory/observation-backups/`
- `memory/dream-logs/`
- `memory/dream-metrics/`
- `memory/dream-staging/`
- `memory/archive/observations/`
- `memory/archive/chunks/`
- `memory/observations.md`

Forbidden:

- `MEMORY.md`
- ontology
- 2nd-brain
- `.learnings/`
- OpenClaw config/personality files
- secrets
- raw transcripts
- git operations
- external connectors

Run only after observer/reflector validation.
