# Total Recall — Assistant Memory Stack startup snippet

At session startup:

1. Run `bash ~/.openclaw/workspace/skills/total-recall/scripts/session-recovery.sh` to capture any missed observation safely.
2. Load `memory/observations.md` for cross-session context.
3. Use memorySearch over `memory/observations.md` when searching past observations.
4. Do not load daily memory files in this core phase.
5. Do not write long-term memory directly from Total Recall.

Total Recall owns automatic observational capture only.
Long-term promotion belongs to memory-maintenance.
