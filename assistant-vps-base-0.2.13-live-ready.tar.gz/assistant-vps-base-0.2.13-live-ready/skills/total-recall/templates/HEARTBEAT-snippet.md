# Total Recall — Assistant Memory Stack heartbeat snippet

On heartbeat:

1. Check whether `memory/observations.md` exists.
2. Use the observer only for compressed observations.
3. Do not load daily memory files in this core phase.
4. Do not write long-term memory directly from Total Recall.
5. Keep external connectors disabled unless separately approved.

Total Recall should stay focused on observations, not broad memory promotion.
