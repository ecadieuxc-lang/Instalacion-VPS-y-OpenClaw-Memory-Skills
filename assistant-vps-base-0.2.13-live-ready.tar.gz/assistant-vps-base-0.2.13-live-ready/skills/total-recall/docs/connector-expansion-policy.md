# Assistant Memory Stack connector expansion policy

This total-recall installation intentionally includes the Assistant Memory Stack memory core only.

## Current install scope

Enabled/installed core:

- Observer
- Reflector
- Session Recovery
- Reactive Watcher
- Dream Cycle
- Staging Review
- observations.md memory loop
- cron/memoryFlush configuration files for reviewed setup

## Not enabled in this phase

External app connectors are not installed or enabled in the core phase:

- Gmail
- Calendar
- Fitbit
- Samsung Health / Health Connect
- LinkedIn
- Todoist
- Ionos
- broad filewatch
- any future external app connector

## Future connector contract

Any future connector must be reviewed as a separate mini-skill or gated module.

Each connector must define:

- exact source app/service;
- exact credentials required;
- exact data types read;
- exact data types prohibited;
- event schema emitted to total-recall;
- retention rules;
- redaction rules;
- whether it can run automatically;
- whether human approval is required before writing observations;
- rollback/removal procedure.

## Health data rule

Health connectors, including Fitbit, Samsung Health, Galaxy Watch, or Health Connect, are sensitive.

Allowed future direction:

- summarized daily events;
- sleep summary;
- activity summary;
- watch status;
- coarse pattern detection.

Forbidden by default:

- raw heart-rate streams;
- precise GPS traces;
- medical diagnoses;
- sensitive health logs;
- unredacted exports;
- continuous surveillance.

## Principle

total-recall may observe useful life signals, but it must not become an unrestricted data vacuum.
