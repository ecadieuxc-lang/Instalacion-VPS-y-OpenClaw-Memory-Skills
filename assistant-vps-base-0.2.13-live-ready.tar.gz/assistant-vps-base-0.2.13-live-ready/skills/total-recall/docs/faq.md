# Total Recall Assistant Memory Stack FAQ

## Where does it write?

`memory/observations.md` and approved Total Recall support paths only.

## Where does the API key go?

Outside chat and outside evidence. Do not store it in memory files.

## Are external apps connected now?

No. Connectors require a future gate.

## Does this write MEMORY.md?

No. Long-term promotion belongs to memory-maintenance.
