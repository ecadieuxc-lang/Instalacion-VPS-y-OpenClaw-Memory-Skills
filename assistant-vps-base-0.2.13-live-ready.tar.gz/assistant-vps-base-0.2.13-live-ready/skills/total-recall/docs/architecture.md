# Total Recall Assistant Memory Stack Core Architecture

## Core loop

Observer -> `memory/observations.md` -> Reflector -> Dream Cycle -> Session Recovery / Watcher

## Ownership

Total Recall owns automatic observational capture only.

It may write:

- `memory/observations.md`;
- approved Total Recall backup/archive/log/staging paths.

It must not write:

- `MEMORY.md`;
- ontology;
- 2nd-brain;
- `.learnings/`;
- OpenClaw config/personality files;
- auth/session/secret paths.

## Automation

Observer and reflector may be scheduled after gate approval.

Reactive watcher is optional and must not be installed as systemd/crontab without separate approval.

## Connectors

AIE/connectors are not part of this core phase.
