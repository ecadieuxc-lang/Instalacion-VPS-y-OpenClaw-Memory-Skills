# Total Recall Dream Cycle Prompt — Assistant Memory Stack safe edition

You are running Total Recall Dream Cycle for the assistant.

Goal:
- consolidate `memory/observations.md`;
- archive stale observations into approved Total Recall archive paths;
- add semantic hooks so archived information remains findable;
- produce a concise dream log and metrics.

Strict boundaries:
- Do not write `MEMORY.md`.
- Do not propose direct writes to `MEMORY.md`.
- Do not write ontology.
- Do not write 2nd-brain.
- Do not write `.learnings/`.
- Do not write OpenClaw identity/personality/config files.
- Do not write secrets, credentials, API keys, tokens, raw logs, raw transcripts, WhatsApp/session/auth data, SSH keys, or env dumps.
- Do not use git.
- Do not call package installers.
- Do not use external app connectors.

Allowed helper:
`skills/total-recall/scripts/dream-cycle.sh`

Allowed helper commands:
- `preflight`
- `backup`
- `write-staging NAME.md`
- `apply-observations NAME.md`
- `archive-observation NAME.md`
- `archive-chunk NAME.md`
- `write-log NAME.md`
- `write-metrics NAME.json`
- `rollback-latest`

Process:
1. Run preflight.
2. Read `memory/observations.md`.
3. Classify observations by impact, confidence, age, and type.
4. Produce a revised `observations.md` that is shorter, cleaner, and still useful.
5. Archive stale or superseded details only under `memory/archive/observations/` or `memory/archive/chunks/`.
6. Write revised observations to `memory/dream-staging/`.
7. Apply the staged observations only after validating that no forbidden material is included.
8. Write a dream log under `memory/dream-logs/`.
9. Write metrics under `memory/dream-metrics/`.

Promotion rule:
Promotion into long-term memory belongs to memory-maintenance, not Total Recall. If you detect a recurring theme worth long-term memory, write a review note only under `memory/dream-staging/` for memory-maintenance review. Do not modify the main long-term memory file.

Reply with a concise completion summary.
