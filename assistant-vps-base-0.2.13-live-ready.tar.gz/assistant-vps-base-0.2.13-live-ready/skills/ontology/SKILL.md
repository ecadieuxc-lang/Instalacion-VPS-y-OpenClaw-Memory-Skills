---
name: ontology
description: Typed knowledge graph for the assistant structured memory. Use when creating/querying typed entities, linking related objects, enforcing schema constraints, promoting stable facts, recording decisions, or answering structured questions such as "what do I know about X" or "what relation does X have with Y". Do not use for automatic conversation capture, raw episodic notes, behavioral lessons, visualizations, or untyped narrative memory.
---

# Ontology

A typed vocabulary + constraint system for representing knowledge as a verifiable graph.

## Core Concept

Everything is an **entity** with a **type**, **properties**, and **relations** to other entities. Every mutation is validated against type constraints before committing.

```
Entity: { id, type, properties, relations, created, updated }
Relation: { from_id, relation_type, to_id, properties }
```

## When to Use

| Trigger | Action |
|---------|--------|
| Approved structured promotion / explicit typed memory request | Create/update entity after schema validation |
| "What do I know about X?" | Query graph |
| "Link X to Y" | Create relation |
| "Show all tasks for project Z" | Graph traversal |
| "What depends on X?" | Dependency query |
| Planning multi-step work | Model as graph transformations |
| Skill needs structured shared state | Read/write ontology objects only when explicit or approved |

## Core Types

```yaml
# Agents & People
Person: { name, email?, phone?, notes? }
Organization: { name, type?, members[] }

# Work
Project: { name, status, goals[], owner? }
Task: { title, status, due?, priority?, assignee?, blockers[] }
Goal: { description, target_date?, metrics[] }

# Time & Place
Event: { title, start, end?, location?, attendees[], recurrence? }
Location: { name, address?, coordinates? }

# Information
Document: { title, path?, url?, summary? }
Message: { content, sender, recipients[], thread? }
Thread: { subject, participants[], messages[] }
Note: { content, tags[], refs[] }

# Resources
Account: { service, username, credential_ref? }
Device: { name, type, identifiers[] }
Credential: { service, secret_ref }  # Never store secrets directly

# Meta
Action: { type, target, timestamp, outcome? }
Policy: { scope, rule, enforcement }
```

## Storage

Default: `memory/ontology/graph.jsonl`

```jsonl
{"op":"create","entity":{"id":"p_001","type":"Person","properties":{"name":"Alice"}}}
{"op":"create","entity":{"id":"proj_001","type":"Project","properties":{"name":"Website Redesign","status":"active"}}}
{"op":"relate","from":"proj_001","rel":"has_owner","to":"p_001"}
```

Query via scripts or direct file ops. For complex graphs, migrate to SQLite.

### Append-Only Rule

When working with existing ontology data or schema, **append/merge** changes instead of overwriting files. This preserves history and avoids clobbering prior definitions.


### Installation Gate Notes

This audited local copy restricts `--graph` and `--schema` to `memory/ontology/` under the current workspace root. Paths outside that subtree must be rejected.

`delete` is append-only: it writes a tombstone record and does not purge historical `create` or `update` values from `graph.jsonl`. Do not store raw secrets, tokens, passwords, API keys, or credentials in ontology records. Use `secret_ref` only.

PyYAML is an external dependency required for schema validation and schema append operations.


## Assistant Memory Stack memory architecture overlay

This section is mandatory for the assistant's personal-assistant memory architecture.

### Role

Ontology is "El Archivista": the single authoritative typed knowledge graph for
stable structured memory.

Ontology owns:

- typed entities
- typed relations
- validated graph mutations
- structured project/task/person/place/decision records
- cross-skill structured state when explicitly promoted or requested

Ontology does not own:

- automatic conversation capture
- raw episodic notes
- untyped narrative memory
- daily observations
- behavioral lessons/errors
- visualizations
- memory index/search itself

### Activation rules

Use ontology when the user asks or when an approved promotion requires structured
knowledge, such as:

- "who is X?"
- "what relation does X have with Y?"
- "what did we decide about Z?"
- "list my open projects/tasks"
- "link X to Y"
- "create/update this structured record"
- "promote this stable fact into the graph"

Do not trigger ontology merely because the user says "remember" in a broad,
unstructured or conversational way. If the memory is untyped narrative context,
daily observation, behavioral correction, or personal note, route it to the
appropriate memory layer instead of ontology.

### Write policy

Ontology writes only by explicit user instruction or approved promotion.

Ontology must not capture every conversation turn automatically.

All ontology mutations must be:

1. typed;
2. validated against schema constraints;
3. append-only or merge-based;
4. non-destructive by default;
5. auditable through graph.jsonl history.

Never overwrite or purge existing graph/schema history as a normal operation.

### Secret and sensitive-data policy

Never store raw secrets, passwords, tokens, API keys, OAuth/device codes,
session material, private keys, cookies, WhatsApp auth data, VPS credentials,
or sensitive operational endpoints.

Use `secret_ref` only when the user explicitly approves storing a reference.
Do not store redacted versions of secrets.

### Coordination with other memory layers

In the assistant's Assistant Memory Stack architecture:

- total-recall, if later installed, owns automatic observations.
- memory-maintenance, if later installed, proposes/promotes memory maintenance.
- 2nd-brain, if later installed, owns user-curated notes by explicit request.
- self-improving-agent, if later installed, owns behavioral lessons/corrections.
- mindmap-generator, if later installed, is read-only visualization.
- memorySearch/memory-core remains enabled as the shared search/index layer.
- memento is intentionally not part of this architecture and must not be used as
  a competing memory writer.

### Conflict resolution

When sources disagree, prefer:

1. current explicit user correction;
2. approved MEMORY.md content;
3. ontology graph records;
4. curated notes;
5. raw observations.

If contradiction persists, ask the user before mutating the graph.

### No automatic memory-core mutation

Do not run `openclaw memory index`, `openclaw memory status --fix`,
`openclaw memory promote --apply`, snapshots, or other mutating memory
maintenance commands as part of ontology use unless explicitly authorized.


## Workflows

### Create Entity

```bash
python3 scripts/ontology.py create --type Person --props '{"name":"Alice","email":"alice@example.com"}'
```

### Query

```bash
python3 scripts/ontology.py query --type Task --where '{"status":"open"}'
python3 scripts/ontology.py get --id task_001
python3 scripts/ontology.py related --id proj_001 --rel has_task
```

### Link Entities

```bash
python3 scripts/ontology.py relate --from proj_001 --rel has_task --to task_001
```

### Validate

```bash
python3 scripts/ontology.py validate  # Check all constraints
```

## Constraints

Define in `memory/ontology/schema.yaml`:

```yaml
types:
  Task:
    required: [title, status]
    status_enum: [open, in_progress, blocked, done]
  
  Event:
    required: [title, start]
    validate: "end >= start if end exists"

  Credential:
    required: [service, secret_ref]
    forbidden_properties: [password, secret, token]  # Force indirection

relations:
  has_owner:
    from_types: [Project, Task]
    to_types: [Person]
    cardinality: many_to_one
  
  blocks:
    from_types: [Task]
    to_types: [Task]
    acyclic: true  # No circular dependencies
```

## Skill Contract

Skills that use ontology should declare:

```yaml
# In SKILL.md frontmatter or header
ontology:
  reads: [Task, Project, Person]
  writes: [Task, Action]
  preconditions:
    - "Task.assignee must exist"
  postconditions:
    - "Created Task has status=open"
```

## Planning as Graph Transformation

Model multi-step plans as a sequence of graph operations:

```
Plan: "Schedule team meeting and create follow-up tasks"

1. CREATE Event { title: "Team Sync", attendees: [p_001, p_002] }
2. RELATE Event -> has_project -> proj_001
3. CREATE Task { title: "Prepare agenda", assignee: p_001 }
4. RELATE Task -> for_event -> event_001
5. CREATE Task { title: "Send summary", assignee: p_001, blockers: [task_001] }
```

Each step is validated before execution. Rollback on constraint violation.

## Integration Patterns

### With Causal Inference

Log ontology mutations as causal actions:

```python
# When creating/updating entities, also log to causal action log
action = {
    "action": "create_entity",
    "domain": "ontology", 
    "context": {"type": "Task", "project": "proj_001"},
    "outcome": "created"
}
```

### Cross-Skill Communication

```python
# Email skill creates commitment
commitment = ontology.create("Commitment", {
    "source_message": msg_id,
    "description": "Send report by Friday",
    "due": "2026-01-31"
})

# Task skill picks it up
tasks = ontology.query("Commitment", {"status": "pending"})
for c in tasks:
    ontology.create("Task", {
        "title": c.description,
        "due": c.due,
        "source": c.id
    })
```

## Quick Start

```bash
# Initialize ontology storage
mkdir -p memory/ontology
touch memory/ontology/graph.jsonl

# Create schema (optional but recommended)
python3 scripts/ontology.py schema-append --data '{
  "types": {
    "Task": { "required": ["title", "status"] },
    "Project": { "required": ["name"] },
    "Person": { "required": ["name"] }
  }
}'

# Start using
python3 scripts/ontology.py create --type Person --props '{"name":"Alice"}'
python3 scripts/ontology.py list --type Person
```

## References

- `references/schema.md` — Full type definitions and constraint patterns
- `references/queries.md` — Query language and traversal examples

## Instruction Scope

Runtime instructions operate on local files (`memory/ontology/graph.jsonl` and `memory/ontology/schema.yaml`) and provide CLI usage for create/query/relate/validate; this is within scope. The skill reads/writes workspace files and will create the `memory/ontology` directory when used. Validation includes property/enum/forbidden checks, relation type/cardinality validation, acyclicity for relations marked `acyclic: true`, and Event `end >= start` checks; other higher-level constraints may still be documentation-only unless implemented in code.
