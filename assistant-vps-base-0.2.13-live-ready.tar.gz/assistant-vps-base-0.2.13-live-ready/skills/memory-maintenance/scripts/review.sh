#!/usr/bin/env bash
set -e

export GEMINI_CLI_TRUST_WORKSPACE="${GEMINI_CLI_TRUST_WORKSPACE:-true}"

WORKSPACE="${OPENCLAW_WORKSPACE:-$HOME/.openclaw/workspace}"
ENV_FILE="$WORKSPACE/.env"
OUTPUT_DIR="$WORKSPACE/agents/memory"
SETTINGS="$WORKSPACE/skills/memory-maintenance/config/settings.json"

DATE="$(date +%Y-%m-%d)"
TIMESTAMP="$(date +%Y-%m-%d-%H%M)"

mkdir -p "$OUTPUT_DIR" "$OUTPUT_DIR/archive" "$OUTPUT_DIR/.trash" "$WORKSPACE/memory/archive"

if [ -f "$ENV_FILE" ]; then
  set -a
  source "$ENV_FILE"
  set +a
fi

GEMINI_MODEL="$(jq -r '.review.gemini_model // "gemini-2.5-flash"' "$SETTINGS" 2>/dev/null || echo "gemini-2.5-flash")"
LOOKBACK_DAYS="$(jq -r '.review.lookback_days // 7' "$SETTINGS" 2>/dev/null || echo "7")"
MAX_SUGGESTIONS="$(jq -r '.review.max_suggestions // 10' "$SETTINGS" 2>/dev/null || echo "10")"

echo "[$TIMESTAMP] Starting memory maintenance v2 scan..."

DAILY_NOTES_FILE="$(mktemp)"
MEMORY_MD_FILE="$(mktemp)"
USER_MD_FILE="$(mktemp)"
PROMPT_FILE="$(mktemp)"
RESULT_FILE="$(mktemp)"
ERR_FILE="$(mktemp)"
JSON_FILE="$(mktemp)"

cleanup_tmp() {
  rm -f "$DAILY_NOTES_FILE" "$MEMORY_MD_FILE" "$USER_MD_FILE" "$PROMPT_FILE" "$RESULT_FILE" "$ERR_FILE" "$JSON_FILE"
}
trap cleanup_tmp EXIT

i=0
while [ "$i" -lt "$LOOKBACK_DAYS" ]; do
  DAY="$(date -d "$i days ago" +%Y-%m-%d 2>/dev/null || true)"
  NOTE_FILE="$WORKSPACE/memory/${DAY}.md"
  if [ -n "$DAY" ] && [ -f "$NOTE_FILE" ]; then
    {
      echo ""
      echo "=== memory/${DAY}.md ==="
      sed -n '1,260p' "$NOTE_FILE"
    } >> "$DAILY_NOTES_FILE"
  fi
  i=$((i + 1))
done

if [ -f "$WORKSPACE/MEMORY.md" ]; then
  head -c 120000 "$WORKSPACE/MEMORY.md" > "$MEMORY_MD_FILE"
fi

if [ -f "$WORKSPACE/USER.md" ]; then
  head -c 80000 "$WORKSPACE/USER.md" > "$USER_MD_FILE"
fi

MEMORY_DIR_COUNT="$(find "$WORKSPACE/memory" -maxdepth 1 \( -name "*.md" -o -name "*.txt" -o -name "*.json" \) ! -name "observations.md" 2>/dev/null | wc -l | tr -d ' ')"
ARCHIVE_COUNT="$(find "$WORKSPACE/memory/archive" -type f 2>/dev/null | wc -l | tr -d ' ')"
OLD_FILES="$(find "$WORKSPACE/memory" -maxdepth 1 -name "*.md" ! -name "observations.md" -mtime +30 2>/dev/null | head -20)"
OLD_FILES_COUNT="$(find "$WORKSPACE/memory" -maxdepth 1 -name "*.md" ! -name "observations.md" -mtime +30 2>/dev/null | wc -l | tr -d ' ')"
NON_STANDARD="$(find "$WORKSPACE/memory" -maxdepth 1 -name "*.md" ! -name "observations.md" ! -name "[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9].md" 2>/dev/null | head -20)"
NON_STANDARD_COUNT="$(find "$WORKSPACE/memory" -maxdepth 1 -name "*.md" ! -name "observations.md" ! -name "[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9].md" 2>/dev/null | wc -l | tr -d ' ')"
DAILY_COUNT="$(grep -c '^=== memory/' "$DAILY_NOTES_FILE" 2>/dev/null || echo 0)"

echo "[$TIMESTAMP] Found:"
echo "  - Daily notes: $DAILY_COUNT"
echo "  - Memory dir files: $MEMORY_DIR_COUNT"
echo "  - Archive files: $ARCHIVE_COUNT"
echo "  - Files >30 days old: $OLD_FILES_COUNT"
echo "  - Non-standard names: $NON_STANDARD_COUNT"

{
  cat <<PROMPT
TASK: Comprehensive Memory Maintenance Review for Assistant/OpenClaw.

You are the memory-maintenance skill. Produce suggestions only. Do not apply changes.

HARD OWNERSHIP BOUNDARIES:
- memory/observations.md is owned by total-recall.
- Treat memory/observations.md as an intentional exception.
- Never suggest renaming, deleting, archiving, consolidating, moving, editing, or rewriting memory/observations.md.
- Never suggest modifying anything under skills/total-recall/.
- Never consolidate total-recall observations into daily notes.
- Memory-maintenance owns review outputs under agents/memory/ and may suggest human-reviewed updates to MEMORY.md only.
- Content updates require human approval.
- Delete/destructive actions require human approval.
- Prefer no suggestion over risky suggestion.

REVIEW CONTEXT:
- Date: $DATE
- Lookback days: $LOOKBACK_DAYS
- Max suggestions: $MAX_SUGGESTIONS
- Memory dir files excluding observations.md: $MEMORY_DIR_COUNT
- Archive files: $ARCHIVE_COUNT
- Old files excluding observations.md: $OLD_FILES_COUNT
- Non-standard names excluding observations.md: $NON_STANDARD_COUNT

OLD FILES:
$OLD_FILES

NON-STANDARD FILES:
$NON_STANDARD

DAILY NOTES:
PROMPT

  cat "$DAILY_NOTES_FILE"

  cat <<PROMPT

CURRENT MEMORY.md:
PROMPT

  cat "$MEMORY_MD_FILE"

  cat <<PROMPT

CURRENT USER.md:
PROMPT

  cat "$USER_MD_FILE"

  cat <<'PROMPT'

Return valid JSON only. No markdown. No prose outside JSON.

Required schema:
{
  "review_date": "YYYY-MM-DD",
  "summary": {
    "daily_notes_reviewed": 0,
    "memory_dir_files": 0,
    "archive_files": 0,
    "issues_found": 0,
    "human_readable_summary": "2-3 short paragraphs"
  },
  "content_suggestions": [
    {
      "type": "add|update|delete",
      "section": "MEMORY.md section",
      "current_text": null,
      "proposed_text": "text",
      "rationale": "why",
      "sources": ["memory/YYYY-MM-DD.md"],
      "confidence": "high|medium|low",
      "priority": "high|medium|low"
    }
  ],
  "maintenance_suggestions": [
    {
      "type": "archive|rename|delete|consolidate",
      "target": "relative filepath",
      "action": "specific action",
      "reason": "why",
      "safe_to_auto": false,
      "backup_required": true
    }
  ],
  "contradictions": [],
  "stats": {
    "content_suggestions_count": 0,
    "maintenance_suggestions_count": 0,
    "high_priority_count": 0,
    "safe_to_auto_count": 0
  }
}
PROMPT
} > "$PROMPT_FILE"

echo "[$TIMESTAMP] Running Gemini analysis..."

if ! timeout 210s env GEMINI_CLI_TRUST_WORKSPACE=true gemini --model "$GEMINI_MODEL" -p "$(cat "$PROMPT_FILE")" > "$RESULT_FILE" 2> "$ERR_FILE"; then
  echo "[$TIMESTAMP] ERROR: Gemini failed"
  cat "$ERR_FILE"
  cat "$RESULT_FILE"
  cat "$ERR_FILE" "$RESULT_FILE" > "$OUTPUT_DIR/error-v2-${TIMESTAMP}.txt"
  exit 1
fi

python3 - "$RESULT_FILE" "$JSON_FILE" <<'PYJSON'
import json
import re
import sys
from pathlib import Path

src = Path(sys.argv[1]).read_text(encoding="utf-8", errors="ignore")
dst = Path(sys.argv[2])

candidates = []

m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", src, re.S)
if m:
    candidates.append(m.group(1))

starts = [i for i, ch in enumerate(src) if ch == "{"]
for start in starts:
    depth = 0
    in_string = False
    escape = False
    for i in range(start, len(src)):
        ch = src[i]
        if in_string:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
        else:
            if ch == '"':
                in_string = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    candidates.append(src[start:i + 1])
                    break

def is_protected_target(value: object) -> bool:
    text = str(value or "")
    return (
        "memory/observations.md" in text
        or text.endswith("/observations.md")
        or "skills/total-recall" in text
        or "total-recall" in text.lower()
    )

last_error = None

for candidate in candidates:
    try:
        data = json.loads(candidate)
        if not isinstance(data, dict):
            continue
        if "summary" not in data:
            continue

        kept = []
        protected = []

        for item in data.get("maintenance_suggestions", []) or []:
            target = item.get("target", "")
            action = item.get("action", "")
            reason = item.get("reason", "")
            if is_protected_target(target) or is_protected_target(action) or is_protected_target(reason):
                protected.append(item)
            else:
                kept.append(item)

        data["maintenance_suggestions"] = kept

        if protected:
            data["protected_suggestions_ignored"] = protected

        stats = data.setdefault("stats", {})
        stats["content_suggestions_count"] = len(data.get("content_suggestions", []) or [])
        stats["maintenance_suggestions_count"] = len(kept)
        stats["safe_to_auto_count"] = sum(1 for x in kept if x.get("safe_to_auto") is True)
        stats["protected_suggestions_ignored_count"] = len(protected)

        dst.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        raise SystemExit(0)
    except Exception as e:
        last_error = e

raise SystemExit(f"no valid JSON object found: {last_error}")
PYJSON

if ! jq empty "$JSON_FILE" >/dev/null 2>&1; then
  echo "[$TIMESTAMP] ERROR: Invalid JSON from Gemini after extraction"
  cat "$ERR_FILE" "$RESULT_FILE" > "$OUTPUT_DIR/error-v2-${TIMESTAMP}.txt"
  exit 1
fi

JSON_OUT="$OUTPUT_DIR/review-v2-${DATE}.json"
MD_OUT="$OUTPUT_DIR/review-v2-${DATE}.md"

mv "$JSON_FILE" "$JSON_OUT"

python3 - "$JSON_OUT" "$MD_OUT" <<'PYMD'
import json
import sys
from pathlib import Path

data = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
out = Path(sys.argv[2])

summary = data.get("summary", {})
stats = data.get("stats", {})
content = data.get("content_suggestions", []) or []
maintenance = data.get("maintenance_suggestions", []) or []
protected = data.get("protected_suggestions_ignored", []) or []
contradictions = data.get("contradictions", []) or []

lines = []
lines.append(f"# Memory Maintenance Review v2: {data.get('review_date', '')}")
lines.append("")
lines.append("## Summary")
lines.append(str(summary.get("human_readable_summary", "No summary provided")))
lines.append("")
lines.append("## Quick Stats")
lines.append(f"- **Content suggestions:** {stats.get('content_suggestions_count', len(content))}")
lines.append(f"- **Maintenance tasks:** {stats.get('maintenance_suggestions_count', len(maintenance))}")
lines.append(f"- **Safe to auto-apply:** {stats.get('safe_to_auto_count', 0)}")
lines.append(f"- **Protected suggestions ignored:** {stats.get('protected_suggestions_ignored_count', len(protected))}")
lines.append("")
lines.append("## Content Suggestions for MEMORY.md")
lines.append("")

if content:
    for item in content:
        lines.append(f"### {str(item.get('priority', 'medium')).upper()}: {str(item.get('type', '')).upper()} - {item.get('section', '')}")
        lines.append("")
        lines.append(f"**Confidence:** {item.get('confidence', '')}")
        lines.append("")
        lines.append(f"**Rationale:** {item.get('rationale', '')}")
        lines.append("")
        lines.append("**Current:**")
        lines.append(str(item.get("current_text") or "(new addition)"))
        lines.append("")
        lines.append("**Proposed:**")
        lines.append(str(item.get("proposed_text") or ""))
        lines.append("")
        lines.append("**Sources:** " + ", ".join(map(str, item.get("sources", []) or [])))
        lines.append("")
        lines.append("---")
        lines.append("")
else:
    lines.append("(none)")
    lines.append("")

lines.append("## Directory Maintenance Tasks")
lines.append("")
lines.append("| Action | Target | Reason | Safe to Auto |")
lines.append("|--------|--------|--------|--------------|")

if maintenance:
    for item in maintenance:
        safe = "Yes" if item.get("safe_to_auto") is True else "No"
        lines.append(f"| {item.get('type', '')} | `{item.get('target', '')}` | {item.get('reason', '')} | {safe} |")
else:
    lines.append("| none | none | none | No |")

if protected:
    lines.append("")
    lines.append("## Protected Suggestions Ignored")
    lines.append("")
    for item in protected:
        lines.append(f"- `{item.get('target', '')}` — ignored because it belongs to total-recall or protected memory.")

if contradictions:
    lines.append("")
    lines.append("## Contradictions")
    lines.append("")
    for item in contradictions:
        lines.append(f"### {item.get('topic', '')}")
        lines.append("")
        lines.append(f"**MEMORY.md says:** {item.get('memory_says', '')}")
        lines.append("")
        lines.append(f"**Notes say:** {item.get('notes_say', '')}")
        lines.append("")
        lines.append(f"**Resolution:** {item.get('resolution', '')}")

lines.append("")
lines.append("## Next Steps")
lines.append("")
lines.append("- Review suggestions manually.")
lines.append("- Do not apply content changes without human approval.")
lines.append("- Do not modify memory/observations.md; it belongs to total-recall.")

out.write_text("\n".join(lines) + "\n", encoding="utf-8")
PYMD

echo "[$TIMESTAMP] Analysis complete:"
jq '.summary, .stats' "$JSON_OUT"

echo "[$TIMESTAMP] Review files:"
echo "$JSON_OUT"
echo "$MD_OUT"
