---
name: self-improving-agent
description: assistant behavioral learning layer for Assistant Memory Stack. Use for safe event-based assistant-behavior learning: user corrections, repeated assistant mistakes, clear non-sensitive operational failures, capability gaps, outdated answers, and better recurring methods. Critical or sensitive contexts require explicit approval. Do not use for user facts, personal memory, secrets, credentials, transcripts, command output, VPS/WhatsApp/auth/session data, or general automatic session capture.
emoji: 🧠
tags: [learning, correction, behavior, assistant-memory-stack, local-assistant]
---

# self-improving-agent — Assistant Memory Stack edition

## Role

This skill is "El Aprendiz" in the assistant's Assistant Memory Stack memory architecture.

It records only behavioral lessons about the assistant itself:

- what the assistant did wrong;
- what the user corrected about the assistant's behavior;
- what the assistant should do differently next time;
- repeated assistant failure patterns;
- safe behavioral preferences explicitly framed as corrections.

It must not remember facts about the user's life.

## Ownership boundary

This skill owns only:

- `.learnings/LEARNINGS.md`

This skill must not write, promote, rewrite, or patch:

- `MEMORY.md`
- `SOUL.md`
- `AGENTS.md`
- `TOOLS.md`
- `CLAUDE.md`
- Copilot instructions
- OpenClaw core files
- ontology graph/schema files
- `memory/observations.md`
- raw transcripts
- command logs
- hook outputs
- session history

## Activation rules

Use this skill for safe event-based behavioral learning.

Normal low-risk events may be logged silently when the lesson is clear and safe:

1. the user corrects the assistant's behavior;
2. Assistant repeats a mistake and the pattern is clear;
3. a non-sensitive operation fails and reveals a reusable behavioral lesson;
4. the user asks for a capability Assistant does not have;
5. the assistant detects that its answer was outdated or incorrect;
6. a better way to perform a recurring task is discovered.

Do not activate it for facts, contacts, schedules, places, preferences, decisions, project details, health, legal, finance, credentials, WhatsApp data, VPS state, or ordinary conversation unless the lesson is strictly about the assistant's behavior.

This skill must not capture sessions generally. total-recall owns automatic episodic capture. self-improving-agent only writes when a clear behavioral event exists.

## Critical-context gates

Silent event logging is allowed only in normal low-risk assistant behavior contexts.

Explicit approval is required before writing `.learnings/LEARNINGS.md` during or after:

- audits;
- security reviews;
- read-only tasks;
- documentation-only tasks;
- no-state-change workflows;
- VPS, SSH, credential, WhatsApp, token, auth, deployment, or production work;
- tool-output analysis where sensitive data may appear;
- any task involving logs, secrets, sessions, auth, operational infrastructure, or user-sensitive material.

In those contexts, write only after the user approves a safe abstract lesson. Never include raw output, credentials, identifiers, transcripts, paths containing secrets, or operational details.

## Event-write rule

In normal low-risk contexts, persistent writes may happen silently when there is a clear behavioral event and the entry can be written as a short safe abstraction.

Explicit approval is still required when:

- the context is critical or sensitive;
- the proposed lesson is ambiguous;
- the lesson may contain personal facts, credentials, operational details, transcripts, or raw tool output;
- the lesson is a user preference not clearly framed as a correction;
- the entry would require later promotion, broader memory changes, or edits outside `.learnings/`.

Direct approval phrases include:

- "anota esta corrección";
- "recuerda esta lección";
- "no vuelvas a hacer esto";
- "guarda esto como aprendizaje";
- "para la próxima, actúa así".

Equivalent English approval phrases include:

- "note this correction";
- "remember this lesson";
- "do not do this again";
- "save this as a learning";
- "next time, act this way".

If approval is required and ambiguous, ask before writing.

## Secret and privacy policy

Never store, quote, summarize, redact, hash, or partially capture:

- secrets, passwords, API keys, tokens, cookies, bearer headers;
- OAuth/device codes, login URLs, session material;
- SSH keys, private keys, `.env` contents or credential files;
- WhatsApp auth data, JIDs, LIDs, phone numbers, session files;
- VPS credentials, private endpoints, firewall details;
- raw command output, stack traces, environment dumps, logs, transcripts;
- personal facts about the user or third parties;
- sensitive health, finance, legal, relationship, address or identifier data;
- source code, config files, or operational details.

If sensitive material appears, skip the write or ask for a safe abstract wording.

## Allowed entry format

Append only short behavioral lessons to `.learnings/LEARNINGS.md`.

Use this format:

- ID: LRN-YYYYMMDD-NNN
- Timestamp UTC: YYYY-MM-DDTHH:MM:SSZ
- Status: active
- Area: communication | memory-routing | caution | formatting | workflow | user-preference-behavior | follow-up-required
- Trigger: user-correction | repeated-assistant-error | non-sensitive-operation-failure | capability-gap | outdated-answer | improved-recurring-method | approved-behavioral-lesson
- Summary: one safe sentence
- Lesson: what the assistant should do differently next time

Use `follow-up-required` only when the lesson is valid but needs later human classification. Do not use it to bypass scope boundaries.

Keep entries concise. Do not include raw user text if it contains sensitive, personal, operational, credential-like, or transcript-like material.

## Assistant Memory Stack coordination

- ontology remains the only typed graph / Archivist.
- memorySearch/memory-core remains enabled as shared search/index.
- total-recall, if installed later, owns automatic observations.
- memory-maintenance, if installed later, owns review/promotion/retention.
- 2nd-brain, if installed later, owns user-curated notes by explicit request.
- mindmap-generator, if installed later, is read-only visualization.
- this skill owns only behavioral lessons in `.learnings/LEARNINGS.md`.

If a correction is actually a stable fact, relationship, decision, task, place, person, or project structure, do not store it here. Route it to ontology or the proper future memory layer.

## Hooks and scripts

This assistant-base edition must not enable hooks or scripts automatically.

Do not install or run:

- `hooks/openclaw/*`
- `scripts/*`
- hook setup instructions
- auto-detectors
- session-history tools
- skill extraction tools

Future hook integration requires a separate audit and explicit human approval.

## Operational rule

This skill should be quiet but useful. In normal low-risk contexts, it may silently log high-signal behavioral events. In critical, sensitive, ambiguous, or operational contexts, it must ask for explicit approval before writing.
