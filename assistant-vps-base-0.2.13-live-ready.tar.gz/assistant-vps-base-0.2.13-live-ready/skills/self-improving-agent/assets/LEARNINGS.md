# Assistant Behavioral Learnings

Approved assistant-behavior lessons only.

Do not store:
- user facts;
- secrets;
- credentials;
- raw logs;
- transcripts;
- command output;
- VPS/WhatsApp/auth/session details;
- personal sensitive information;
- project facts that belong in ontology or another memory layer.
