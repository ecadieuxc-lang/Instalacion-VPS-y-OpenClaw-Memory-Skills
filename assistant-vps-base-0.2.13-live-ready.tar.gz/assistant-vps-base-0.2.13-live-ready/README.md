# Assistant VPS Base 0.2.13-live-ready

Instalador práctico por tramos para preparar un VPS limpio con OpenClaw, WhatsApp, personalidad nueva, credenciales nuevas, skills bundled limpias y memoria inicial vacía.

## Uso rápido

```bash
sudo AVB_LIVE=1 bash install.sh --resume
```

## Qué instala/configura

- Base de sistema y usuario runtime sin sudo permanente.
- SSH public key opcional del nuevo usuario.
- Tailscale y UFW con confirmación anti-corte de acceso.
- OpenClaw como usuario runtime.
- Autenticación OpenAI/Codex del nuevo usuario.
- Personalidad nueva para la IA.
- WhatsApp desde cero con QR nuevo, allowlist nueva y grupos deshabilitados.
- API keys nuevas para skills: Gemini/Google y OpenRouter cuando corresponda.
- Seis skills bundled como fuente local limpia.
- Memoria inicial vacía.
- Automatizaciones de skills si las fuentes instaladas existen.
- Healthcheck y reporte final.

## Reglas de seguridad

- No clona memoria previa.
- No empaqueta credenciales.
- No copia sesiones de WhatsApp.
- No copia llaves SSH privadas.
- No instala skills desde latest remoto.
- Instala las skills desde fuente local bundled usando OpenClaw.
- El usuario nuevo debe entregar sus propias credenciales/API keys.
- La identidad del agente se configura durante la instalación.

## Estados esperados

`PASS` significa instalación usable. `PARTIAL_PASS_*` significa que algo opcional o dependiente del usuario quedó pendiente y fue declarado. `BLOCKED_*` significa que el instalador se detuvo por seguridad.

## Modelo y OpenClaw

- Instala OpenClaw usando el instalador oficial y luego intenta `openclaw update` para quedar en la versión estable más reciente disponible.
- Configura `openai/gpt-5.5` como modelo principal.
- Autentica OpenAI/Codex por OAuth; no usa `OPENAI_API_KEY` como fallback silencioso.


## Hotfix 0.2.4

Ajustes finales:
- Las credenciales de skills se guardan también en el workspace OpenClaw como `.env` seguro, porque las skills cargan variables desde el workspace.
- La memoria inicial se crea en el workspace nativo de OpenClaw, no en una carpeta paralela.
- Las automatizaciones apuntan a las skills instaladas en el workspace de OpenClaw.
- El healthcheck valida memoria, skills y cron contra el workspace real.


## 0.2.5 hotfix

- Resume now advances after declared PARTIAL_PASS stages.
- Stage 12 uses total-recall observer cron plus watcher at reboot.
- Healthcheck verifies OpenAI OAuth runtime probe and cron command coverage.

## 0.2.7 hotfix

- Stage 03 UFW tightened to SSH-only on tailscale0 plus Tailscale UDP; it no longer opens all tailnet inbound traffic.
- Stage 10 now updates chatgpt-help-context.md after the skills stage.
- Added CHECKSUMS.sha256 and stage 00 checksum verification for static package files.

## 0.2.8 safety note

Core stages that must not be silently bypassed:
- OpenAI/Codex OAuth auth.
- Skills 6/6 local installation.

If these are skipped or incomplete, `--resume` repeats the same stage instead of advancing.
Stage 14 can still generate a report, but it cannot report full PASS if healthcheck was not run.


## 0.2.9 checksum/idempotence correction

- CHECKSUMS.sha256 now covers only static package files.
- Mutable runtime paths such as state/, evidence/ and logs/ are excluded from checksum verification.
- This prevents audit-package from failing later only because the installer updated its state or help context.


## 0.2.10 resume/audit correction

- Fresh packages now start with `AVB_CURRENT_STAGE=NONE`, so the first `--resume` executes stage 00 audit-package instead of skipping directly to preflight.
- `install.sh --help` version text is aligned with `VERSION`.
- Static checksums were regenerated after this correction.
