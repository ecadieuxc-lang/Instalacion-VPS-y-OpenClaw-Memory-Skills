# ChatGPT Help Context

Estado del paquete: FRESH_RELEASE
Versión: 0.2.10-live-ready
Siguiente acción recomendada:
- bash install.sh --resume

Recordatorio de seguridad:
- No pegar API keys, tokens, QR, .env, creds.json, secrets.json, cookies ni llaves privadas.
