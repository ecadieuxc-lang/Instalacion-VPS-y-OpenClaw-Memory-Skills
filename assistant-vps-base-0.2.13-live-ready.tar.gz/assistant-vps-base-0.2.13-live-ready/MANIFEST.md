# Manifest — Assistant VPS Base 0.2.13-live-ready

Tipo: LIVE_INSTALLER

Incluye:

- `install.sh` dispatcher con `--list`, `--status`, `--run` y `--resume`.
- Scripts `00` a `14`.
- Gates `AVB_LIVE` para tramos mutantes.
- OpenClaw.
- WhatsApp base.
- Tramo de credenciales nuevas.
- Seis skills bundled limpias.
- Memoria inicial vacía.
- Automatizaciones de skills.
- Healthcheck.
- Reporte final.

No incluye:

- Credenciales reales.
- Sesiones.
- QR.
- Memoria viva.
- Identidad de un asistente anterior.
- Datos personales del creador del pack.
- App móvil.
- Caddy, DuckDNS o API pública.

Skills bundled:

1. `ontology`
2. `total-recall`
3. `2nd-brain`
4. `mindmap-generator`
5. `memory-maintenance`
6. `self-improving-agent`

Política de skills:

- Fuente local bundled.
- Instalación oficial con `openclaw skills install <local_path> --as <slug>`.
- Sin fallback a ClawHub/latest/original.
- Sin memoria viva empaquetada.


Hotfix 0.2.4:
- Credenciales de skills: workspace `.env` seguro + copia administrativa en assistant/secrets.
- Memoria inicial: OpenClaw workspace.
- Automatizaciones: OpenClaw workspace skills.
- Healthcheck: valida workspace real.


## 0.2.5 hotfix

- Resume now advances after declared PARTIAL_PASS stages.
- Stage 12 uses total-recall observer cron plus watcher at reboot.
- Healthcheck verifies OpenAI OAuth runtime probe and cron command coverage.

## 0.2.7 hotfix

- UFW tailnet rule narrowed to SSH-only on tailscale0.
- Stage 10 writes ChatGPT help context.
- Root CHECKSUMS.sha256 added and verified by audit-package.

## 0.2.8 safety corrections

- OpenAI/Codex auth skip is not treated as completed.
- Skills skipped/incomplete is not treated as completed.
- Final report marks healthcheck-not-run as partial, not PASS.


## 0.2.9 checksum/idempotence correction

- CHECKSUMS.sha256 excludes mutable installer runtime paths: state/, evidence/ and logs/.
- Static package integrity remains verified by stage 00.


## 0.2.10 resume/audit correction

- First `--resume` starts at stage 00 audit-package.
- Dispatcher version text aligned with package version.
- CHECKSUMS.sha256 regenerated for static package files.
